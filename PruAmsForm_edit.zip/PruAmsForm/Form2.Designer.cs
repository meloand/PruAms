﻿namespace PruAmsForm
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlSPAJ = new System.Windows.Forms.TabControl();
            this.tabPageSPAJUpdate = new System.Windows.Forms.TabPage();
            this.buttonSPAJUpdateLoad = new System.Windows.Forms.Button();
            this.comboBoxSPAJUpdateType = new System.Windows.Forms.ComboBox();
            this.buttonSPAJUpdateClear = new System.Windows.Forms.Button();
            this.buttonSPAJUpdateUpdate = new System.Windows.Forms.Button();
            this.comboBoxSPAJUpdateStatus = new System.Windows.Forms.ComboBox();
            this.dateTimeSPAJUpdateInforce = new System.Windows.Forms.DateTimePicker();
            this.textBoxSPAJUpdateInsDOB = new System.Windows.Forms.TextBox();
            this.textBoxSPAJUpdateInfo = new System.Windows.Forms.TextBox();
            this.textBoxSPAJUpdatePolisNum = new System.Windows.Forms.TextBox();
            this.textBoxSPAJUpdateInsName = new System.Windows.Forms.TextBox();
            this.textBoxSPAJUpdateNumber = new System.Windows.Forms.TextBox();
            this.dataGridViewSPAJUpdate = new System.Windows.Forms.DataGridView();
            this.label148 = new System.Windows.Forms.Label();
            this.labelSPAJInforcePolis = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.labelSPAJInforce = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.tabPageSPAJAdd = new System.Windows.Forms.TabPage();
            this.textBoxSPAJInsType = new System.Windows.Forms.TextBox();
            this.buttonSPAJNewCreate = new System.Windows.Forms.Button();
            this.buttonSPAJNewClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJSubmit = new System.Windows.Forms.DateTimePicker();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.textBoxPRUFlyerNum = new System.Windows.Forms.TextBox();
            this.tabControlAddSPAJ = new System.Windows.Forms.TabControl();
            this.tabPageInsInfo = new System.Windows.Forms.TabPage();
            this.label150 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.buttonInsInfoAccept = new System.Windows.Forms.Button();
            this.buttonInsInfoClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJInsrDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJJobClass = new System.Windows.Forms.ComboBox();
            this.label88 = new System.Windows.Forms.Label();
            this.comboBoxSPAJInsrMarriage = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJInsrNextBday = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.comboBoxSPAJInsrGender = new System.Windows.Forms.ComboBox();
            this.label90 = new System.Windows.Forms.Label();
            this.radioButtonSPAJInsrSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJInsrWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJInsrName = new System.Windows.Forms.TextBox();
            this.textBoxSPAJInsrHeight = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.tabPagePolisHolder = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJPolisBack = new System.Windows.Forms.Button();
            this.buttonPolisHolderAccept = new System.Windows.Forms.Button();
            this.buttonPolisHolderClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJPolisDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJPolisRs = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJPolisMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJPolisGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJPolisName = new System.Windows.Forms.TextBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.tabPageSpouseInfo = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJSpouseBack = new System.Windows.Forms.Button();
            this.label152 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.buttonSpouseIgnore = new System.Windows.Forms.Button();
            this.buttonSpouseAccept = new System.Windows.Forms.Button();
            this.buttonSpouseClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJSpouseDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJSpouseMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJSpouseGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJSpouseNextBday = new System.Windows.Forms.TextBox();
            this.radioButtonSPAJSpouseSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJSpouseWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJSpouseHeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJSpouseName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPageParentInfo = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJParentBack = new System.Windows.Forms.Button();
            this.label154 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.buttonParentIgnore = new System.Windows.Forms.Button();
            this.buttonParentAccept = new System.Windows.Forms.Button();
            this.buttonParentClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJParentDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJParentMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJParentGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJParentNextBday = new System.Windows.Forms.TextBox();
            this.radioButtonSPAJParentSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJParentWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJParentHeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJParentName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tabPageAddressInfo = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJAddressBack = new System.Windows.Forms.Button();
            this.buttonAddressAccept = new System.Windows.Forms.Button();
            this.buttonAddressClear = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxSPAJAddrOP = new System.Windows.Forms.TextBox();
            this.textBoxSPAJAddrHP = new System.Windows.Forms.TextBox();
            this.textBoxSPAJAddrEmail = new System.Windows.Forms.TextBox();
            this.textBoxSPAJAddrZip = new System.Windows.Forms.TextBox();
            this.textBoxSPAJAddrCity = new System.Windows.Forms.TextBox();
            this.textBoxSPAJAddrAddress = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPagePengajuanInfo = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJPengajuanBack = new System.Windows.Forms.Button();
            this.label161 = new System.Windows.Forms.Label();
            this.textBoxSPAJPengajuanBasic = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruPPayor = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruMed = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruADD = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruCC = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruPayor = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruHosp = new System.Windows.Forms.TextBox();
            this.labelSPAJPengajuanPruHosp = new System.Windows.Forms.Label();
            this.buttonPengajuanAccept = new System.Windows.Forms.Button();
            this.buttonPengajuanClear = new System.Windows.Forms.Button();
            this.textBoxSPAJPengajuanPremiTotal = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.textBoxSPAJPengajuanPruSaver = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPremi = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPrtanggung = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanExchange = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanExpDate = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanCCBank = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruPPayorAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruMedAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruADDAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruCCAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJPengajuanPruPayorAmnt = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJPengajuanPruPPayor = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJPengajuanPruMed = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJPengajuanADD = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJPengajuanPruCC = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJPengajuanPruPayor = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJPengajuanPruHosp = new System.Windows.Forms.CheckBox();
            this.comboBoxSPAJPengajuanCurrency = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJPengajuanPay = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJPengajuanFreq = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.labelSPAJPengajuanExchRate = new System.Windows.Forms.Label();
            this.labelPengajuanCCExpDate = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.labelPengajuanCCBankOther = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPageBeneficiaryInfo = new System.Windows.Forms.TabPage();
            this.buttonAddSPAJBeneficiaryBack = new System.Windows.Forms.Button();
            this.buttonBeneficiaryAccept = new System.Windows.Forms.Button();
            this.buttonSPAJBeneficiaryClear = new System.Windows.Forms.Button();
            this.comboBoxSPAJBeneficiaryRs6 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJBeneficiaryRs5 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJBeneficiaryRs4 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJBeneficiaryRs3 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJBeneficiaryRs2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJBeneficiaryRs1 = new System.Windows.Forms.ComboBox();
            this.dateTimeSPAJBeneficiary6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJBeneficiary5 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJBeneficiary4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJBeneficiary3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJBeneficiary2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJBeneficiary1 = new System.Windows.Forms.DateTimePicker();
            this.textBoxSPAJBeneficiaryDetail6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryDetail5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryDetail4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryDetail3 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName3 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName3 = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJBeneficiary6 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJBeneficiary5 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJBeneficiary4 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJBeneficiary3 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJBeneficiary2 = new System.Windows.Forms.CheckBox();
            this.textBoxSPAJBeneficiaryDetail1 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryDetail2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryLName1 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJBeneficiaryFName1 = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJBeneficiary1 = new System.Windows.Forms.CheckBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.textBoxSPAJANum = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.textBoxSPAJAName = new System.Windows.Forms.TextBox();
            this.textBoxSPAJNum = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.tabPageSPAJEdit = new System.Windows.Forms.TabPage();
            this.textBoxSPAJEditType = new System.Windows.Forms.TextBox();
            this.buttonSPAJEditLoad = new System.Windows.Forms.Button();
            this.buttonSPAJEditUpdate = new System.Windows.Forms.Button();
            this.buttonSPAJEditClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJEditSubmit = new System.Windows.Forms.DateTimePicker();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBoxEditPruFlyerNum = new System.Windows.Forms.TextBox();
            this.tabControlEditSPAJ = new System.Windows.Forms.TabControl();
            this.tabPageEditInsInfo = new System.Windows.Forms.TabPage();
            this.label156 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.buttonInsInfoEdit = new System.Windows.Forms.Button();
            this.buttonSPAJEditInsrClear = new System.Windows.Forms.Button();
            this.dateTimeSPAJEditInsrDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJEditInsrJobClass = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.comboBoxSPAJEditInsrMarriage = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJEditInsrNextBday = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.comboBoxSPAJEditInsrGender = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.radioButtonSPAJEditInsrSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJEditInsrWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditInsrName = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditInsrHeight = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.tabPageEditPolisInfo = new System.Windows.Forms.TabPage();
            this.buttonPolisInfoEdit = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.dateTimeSPAJEditPolisDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJEditPolisRs = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditPolisMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditPolisGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJEditPolisName = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.tabPageEditSpouseInfo = new System.Windows.Forms.TabPage();
            this.label158 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.buttonSpouseEditIgnore = new System.Windows.Forms.Button();
            this.buttonSpouseEdit = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.dateTimeSPAJEditSpouseDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJEditSpouseMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditSpouseGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJEditSpouseNextBday = new System.Windows.Forms.TextBox();
            this.radioButtonSPAJEditSpouseSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJEditSpouseWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditSpouseHeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditSpouseName = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.tabPageEditParentInfo = new System.Windows.Forms.TabPage();
            this.label160 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.buttonParentEditIgnore = new System.Windows.Forms.Button();
            this.buttonParentEdit = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.dateTimeSPAJEditParentDOB = new System.Windows.Forms.DateTimePicker();
            this.comboBoxSPAJEditParentMarriage = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditParentGender = new System.Windows.Forms.ComboBox();
            this.textBoxSPAJEditParentNextBday = new System.Windows.Forms.TextBox();
            this.radioButtonSPAJEditParentSmoke = new System.Windows.Forms.RadioButton();
            this.textBoxSPAJEditParentWeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditParentHeight = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditParentName = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.tabPageEditAddrInfo = new System.Windows.Forms.TabPage();
            this.buttonAddressEdit = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.textBoxSPAJEditAddrOP = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditAddrHP = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditAddrEmail = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditAddrZip = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditAddrCity = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditAddrAddress = new System.Windows.Forms.TextBox();
            this.label115 = new System.Windows.Forms.Label();
            this.tabPageEditPengajuanInfo = new System.Windows.Forms.TabPage();
            this.textBoxSPAJEditPengajuanPruHosp = new System.Windows.Forms.TextBox();
            this.label162 = new System.Windows.Forms.Label();
            this.textBoxSPAJEditPengajuanPruPPayor = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPRUMed = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruADD = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruCC = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruPayor = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanBasic = new System.Windows.Forms.TextBox();
            this.labelEditPruHospitalandSurgical = new System.Windows.Forms.Label();
            this.buttonPengajuanEdit = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.textBoxSPAJEditPengajuanPremiTotal = new System.Windows.Forms.TextBox();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.textBoxSPAJEditPengajuanPruSaver = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPremi = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPrtanggung = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanExchange = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanExpDate = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanCCBank = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruPPayorAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPRUMedAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruADDAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruCCAmnt = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditPengajuanPruPayorAmnt = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJEditPengajuanPruPPayor = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditPengajuanPRUMed = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditPengajuanADD = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditPengajuanPruCC = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditPengajuanPruPayor = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditPengajuanPruHosp = new System.Windows.Forms.CheckBox();
            this.comboBoxSPAJEditPengajuanCurrency = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditPengajuanPay = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditPengajuanFreq = new System.Windows.Forms.ComboBox();
            this.label119 = new System.Windows.Forms.Label();
            this.labelSPAJEditPengajuanExRate = new System.Windows.Forms.Label();
            this.labelSPAJEditPengajuanCCExpDate = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.labelSPAJEditPengajuanCCBankOther = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.tabPageEditBeneficiaryInfo = new System.Windows.Forms.TabPage();
            this.buttonBeneficiaryEdit = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.comboBoxSPAJEditBeneficiaryRs6 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditBeneficiaryRs5 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditBeneficiaryRs4 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditBeneficiaryRs3 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditBeneficiaryRs2 = new System.Windows.Forms.ComboBox();
            this.comboBoxSPAJEditBeneficiaryRs1 = new System.Windows.Forms.ComboBox();
            this.dateTimeSPAJEditBeneficiary6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJEditBeneficiary5 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJEditBeneficiary4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJEditBeneficiary3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJEditBeneficiary2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimeSPAJEditBeneficiary1 = new System.Windows.Forms.DateTimePicker();
            this.textBoxSPAJEditBeneficiaryDetail6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryDetail5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryDetail4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryDetail3 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName3 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName6 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName5 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName4 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName3 = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJEditBeneficiary6 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditBeneficiary5 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditBeneficiary4 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditBeneficiary3 = new System.Windows.Forms.CheckBox();
            this.checkBoxSPAJEditBeneficiary2 = new System.Windows.Forms.CheckBox();
            this.textBoxSPAJEditBeneficiaryDetail1 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryDetail2 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryLName1 = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditBeneficiaryFName1 = new System.Windows.Forms.TextBox();
            this.checkBoxSPAJEditBeneficiary1 = new System.Windows.Forms.CheckBox();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.textBoxSPAJEditANumber = new System.Windows.Forms.TextBox();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.textBoxSPAJEditAName = new System.Windows.Forms.TextBox();
            this.textBoxSPAJEditNumber = new System.Windows.Forms.TextBox();
            this.label139 = new System.Windows.Forms.Label();
            this.tabPageSPAJDelete = new System.Windows.Forms.TabPage();
            this.label120 = new System.Windows.Forms.Label();
            this.buttonSPAJDeleteDelete = new System.Windows.Forms.Button();
            this.buttonSPAJDeleteClear = new System.Windows.Forms.Button();
            this.buttonSPAJDeleteCheck = new System.Windows.Forms.Button();
            this.textBoxSPAJDeleteNum = new System.Windows.Forms.TextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonSPAJClearBackMenu = new System.Windows.Forms.Button();
            this.buttonSPAJPengajuanNext = new System.Windows.Forms.Button();
            this.tabControlSPAJ.SuspendLayout();
            this.tabPageSPAJUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSPAJUpdate)).BeginInit();
            this.tabPageSPAJAdd.SuspendLayout();
            this.tabControlAddSPAJ.SuspendLayout();
            this.tabPageInsInfo.SuspendLayout();
            this.tabPagePolisHolder.SuspendLayout();
            this.tabPageSpouseInfo.SuspendLayout();
            this.tabPageParentInfo.SuspendLayout();
            this.tabPageAddressInfo.SuspendLayout();
            this.tabPagePengajuanInfo.SuspendLayout();
            this.tabPageBeneficiaryInfo.SuspendLayout();
            this.tabPageSPAJEdit.SuspendLayout();
            this.tabControlEditSPAJ.SuspendLayout();
            this.tabPageEditInsInfo.SuspendLayout();
            this.tabPageEditPolisInfo.SuspendLayout();
            this.tabPageEditSpouseInfo.SuspendLayout();
            this.tabPageEditParentInfo.SuspendLayout();
            this.tabPageEditAddrInfo.SuspendLayout();
            this.tabPageEditPengajuanInfo.SuspendLayout();
            this.tabPageEditBeneficiaryInfo.SuspendLayout();
            this.tabPageSPAJDelete.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControlSPAJ
            // 
            this.tabControlSPAJ.Controls.Add(this.tabPageSPAJUpdate);
            this.tabControlSPAJ.Controls.Add(this.tabPageSPAJAdd);
            this.tabControlSPAJ.Controls.Add(this.tabPageSPAJEdit);
            this.tabControlSPAJ.Controls.Add(this.tabPageSPAJDelete);
            this.tabControlSPAJ.Location = new System.Drawing.Point(2, 65);
            this.tabControlSPAJ.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlSPAJ.Name = "tabControlSPAJ";
            this.tabControlSPAJ.SelectedIndex = 0;
            this.tabControlSPAJ.Size = new System.Drawing.Size(1504, 725);
            this.tabControlSPAJ.TabIndex = 8;
            // 
            // tabPageSPAJUpdate
            // 
            this.tabPageSPAJUpdate.Controls.Add(this.buttonSPAJUpdateLoad);
            this.tabPageSPAJUpdate.Controls.Add(this.comboBoxSPAJUpdateType);
            this.tabPageSPAJUpdate.Controls.Add(this.buttonSPAJUpdateClear);
            this.tabPageSPAJUpdate.Controls.Add(this.buttonSPAJUpdateUpdate);
            this.tabPageSPAJUpdate.Controls.Add(this.comboBoxSPAJUpdateStatus);
            this.tabPageSPAJUpdate.Controls.Add(this.dateTimeSPAJUpdateInforce);
            this.tabPageSPAJUpdate.Controls.Add(this.textBoxSPAJUpdateInsDOB);
            this.tabPageSPAJUpdate.Controls.Add(this.textBoxSPAJUpdateInfo);
            this.tabPageSPAJUpdate.Controls.Add(this.textBoxSPAJUpdatePolisNum);
            this.tabPageSPAJUpdate.Controls.Add(this.textBoxSPAJUpdateInsName);
            this.tabPageSPAJUpdate.Controls.Add(this.textBoxSPAJUpdateNumber);
            this.tabPageSPAJUpdate.Controls.Add(this.dataGridViewSPAJUpdate);
            this.tabPageSPAJUpdate.Controls.Add(this.label148);
            this.tabPageSPAJUpdate.Controls.Add(this.labelSPAJInforcePolis);
            this.tabPageSPAJUpdate.Controls.Add(this.label146);
            this.tabPageSPAJUpdate.Controls.Add(this.labelSPAJInforce);
            this.tabPageSPAJUpdate.Controls.Add(this.label144);
            this.tabPageSPAJUpdate.Controls.Add(this.label143);
            this.tabPageSPAJUpdate.Controls.Add(this.label142);
            this.tabPageSPAJUpdate.Controls.Add(this.label141);
            this.tabPageSPAJUpdate.Controls.Add(this.label140);
            this.tabPageSPAJUpdate.Controls.Add(this.label50);
            this.tabPageSPAJUpdate.Location = new System.Drawing.Point(8, 39);
            this.tabPageSPAJUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJUpdate.Name = "tabPageSPAJUpdate";
            this.tabPageSPAJUpdate.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJUpdate.Size = new System.Drawing.Size(1488, 678);
            this.tabPageSPAJUpdate.TabIndex = 1;
            this.tabPageSPAJUpdate.Text = "Update Status";
            this.tabPageSPAJUpdate.UseVisualStyleBackColor = true;
            // 
            // buttonSPAJUpdateLoad
            // 
            this.buttonSPAJUpdateLoad.Location = new System.Drawing.Point(524, 92);
            this.buttonSPAJUpdateLoad.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJUpdateLoad.Name = "buttonSPAJUpdateLoad";
            this.buttonSPAJUpdateLoad.Size = new System.Drawing.Size(120, 44);
            this.buttonSPAJUpdateLoad.TabIndex = 30;
            this.buttonSPAJUpdateLoad.Text = "Load";
            this.buttonSPAJUpdateLoad.UseVisualStyleBackColor = true;
            this.buttonSPAJUpdateLoad.Click += new System.EventHandler(this.buttonSPAJUpdateLoad_Click);
            // 
            // comboBoxSPAJUpdateType
            // 
            this.comboBoxSPAJUpdateType.FormattingEnabled = true;
            this.comboBoxSPAJUpdateType.Items.AddRange(new object[] {
            "SPAJ",
            "Polis"});
            this.comboBoxSPAJUpdateType.Location = new System.Drawing.Point(170, 100);
            this.comboBoxSPAJUpdateType.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJUpdateType.Name = "comboBoxSPAJUpdateType";
            this.comboBoxSPAJUpdateType.Size = new System.Drawing.Size(126, 33);
            this.comboBoxSPAJUpdateType.TabIndex = 29;
            // 
            // buttonSPAJUpdateClear
            // 
            this.buttonSPAJUpdateClear.Location = new System.Drawing.Point(308, 596);
            this.buttonSPAJUpdateClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJUpdateClear.Name = "buttonSPAJUpdateClear";
            this.buttonSPAJUpdateClear.Size = new System.Drawing.Size(120, 44);
            this.buttonSPAJUpdateClear.TabIndex = 28;
            this.buttonSPAJUpdateClear.Text = "Clear";
            this.buttonSPAJUpdateClear.UseVisualStyleBackColor = true;
            this.buttonSPAJUpdateClear.Click += new System.EventHandler(this.buttonSPAJUpdateClear_Click);
            // 
            // buttonSPAJUpdateUpdate
            // 
            this.buttonSPAJUpdateUpdate.Location = new System.Drawing.Point(504, 596);
            this.buttonSPAJUpdateUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJUpdateUpdate.Name = "buttonSPAJUpdateUpdate";
            this.buttonSPAJUpdateUpdate.Size = new System.Drawing.Size(120, 44);
            this.buttonSPAJUpdateUpdate.TabIndex = 27;
            this.buttonSPAJUpdateUpdate.Text = "Update";
            this.buttonSPAJUpdateUpdate.UseVisualStyleBackColor = true;
            this.buttonSPAJUpdateUpdate.Click += new System.EventHandler(this.buttonSPAJUpdateUpdate_Click);
            // 
            // comboBoxSPAJUpdateStatus
            // 
            this.comboBoxSPAJUpdateStatus.FormattingEnabled = true;
            this.comboBoxSPAJUpdateStatus.Items.AddRange(new object[] {
            "Inforce",
            "Lapse",
            "Pending",
            "Surrender"});
            this.comboBoxSPAJUpdateStatus.Location = new System.Drawing.Point(308, 283);
            this.comboBoxSPAJUpdateStatus.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJUpdateStatus.Name = "comboBoxSPAJUpdateStatus";
            this.comboBoxSPAJUpdateStatus.Size = new System.Drawing.Size(190, 33);
            this.comboBoxSPAJUpdateStatus.TabIndex = 26;
            this.comboBoxSPAJUpdateStatus.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJUpdateStatus_SelectedIndexChanged);
            // 
            // dateTimeSPAJUpdateInforce
            // 
            this.dateTimeSPAJUpdateInforce.Enabled = false;
            this.dateTimeSPAJUpdateInforce.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJUpdateInforce.Location = new System.Drawing.Point(308, 331);
            this.dateTimeSPAJUpdateInforce.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJUpdateInforce.Name = "dateTimeSPAJUpdateInforce";
            this.dateTimeSPAJUpdateInforce.Size = new System.Drawing.Size(190, 31);
            this.dateTimeSPAJUpdateInforce.TabIndex = 25;
            // 
            // textBoxSPAJUpdateInsDOB
            // 
            this.textBoxSPAJUpdateInsDOB.Location = new System.Drawing.Point(308, 219);
            this.textBoxSPAJUpdateInsDOB.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJUpdateInsDOB.Name = "textBoxSPAJUpdateInsDOB";
            this.textBoxSPAJUpdateInsDOB.ReadOnly = true;
            this.textBoxSPAJUpdateInsDOB.Size = new System.Drawing.Size(262, 31);
            this.textBoxSPAJUpdateInsDOB.TabIndex = 24;
            // 
            // textBoxSPAJUpdateInfo
            // 
            this.textBoxSPAJUpdateInfo.Location = new System.Drawing.Point(308, 419);
            this.textBoxSPAJUpdateInfo.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJUpdateInfo.Multiline = true;
            this.textBoxSPAJUpdateInfo.Name = "textBoxSPAJUpdateInfo";
            this.textBoxSPAJUpdateInfo.Size = new System.Drawing.Size(334, 154);
            this.textBoxSPAJUpdateInfo.TabIndex = 23;
            // 
            // textBoxSPAJUpdatePolisNum
            // 
            this.textBoxSPAJUpdatePolisNum.Enabled = false;
            this.textBoxSPAJUpdatePolisNum.Location = new System.Drawing.Point(308, 379);
            this.textBoxSPAJUpdatePolisNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJUpdatePolisNum.Name = "textBoxSPAJUpdatePolisNum";
            this.textBoxSPAJUpdatePolisNum.Size = new System.Drawing.Size(190, 31);
            this.textBoxSPAJUpdatePolisNum.TabIndex = 22;
            // 
            // textBoxSPAJUpdateInsName
            // 
            this.textBoxSPAJUpdateInsName.Location = new System.Drawing.Point(308, 162);
            this.textBoxSPAJUpdateInsName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJUpdateInsName.Name = "textBoxSPAJUpdateInsName";
            this.textBoxSPAJUpdateInsName.ReadOnly = true;
            this.textBoxSPAJUpdateInsName.Size = new System.Drawing.Size(262, 31);
            this.textBoxSPAJUpdateInsName.TabIndex = 21;
            // 
            // textBoxSPAJUpdateNumber
            // 
            this.textBoxSPAJUpdateNumber.Location = new System.Drawing.Point(308, 100);
            this.textBoxSPAJUpdateNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJUpdateNumber.Name = "textBoxSPAJUpdateNumber";
            this.textBoxSPAJUpdateNumber.Size = new System.Drawing.Size(190, 31);
            this.textBoxSPAJUpdateNumber.TabIndex = 20;
            // 
            // dataGridViewSPAJUpdate
            // 
            this.dataGridViewSPAJUpdate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSPAJUpdate.Location = new System.Drawing.Point(676, 83);
            this.dataGridViewSPAJUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewSPAJUpdate.Name = "dataGridViewSPAJUpdate";
            this.dataGridViewSPAJUpdate.RowTemplate.Height = 33;
            this.dataGridViewSPAJUpdate.Size = new System.Drawing.Size(780, 521);
            this.dataGridViewSPAJUpdate.TabIndex = 19;
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(66, 419);
            this.label148.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(124, 25);
            this.label148.TabIndex = 18;
            this.label148.Text = "Information:";
            // 
            // labelSPAJInforcePolis
            // 
            this.labelSPAJInforcePolis.AutoSize = true;
            this.labelSPAJInforcePolis.Enabled = false;
            this.labelSPAJInforcePolis.Location = new System.Drawing.Point(150, 379);
            this.labelSPAJInforcePolis.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJInforcePolis.Name = "labelSPAJInforcePolis";
            this.labelSPAJInforcePolis.Size = new System.Drawing.Size(146, 25);
            this.labelSPAJInforcePolis.TabIndex = 17;
            this.labelSPAJInforcePolis.Text = "Polis Number:";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(66, 504);
            this.label146.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(0, 25);
            this.label146.TabIndex = 16;
            // 
            // labelSPAJInforce
            // 
            this.labelSPAJInforce.AutoSize = true;
            this.labelSPAJInforce.Enabled = false;
            this.labelSPAJInforce.Location = new System.Drawing.Point(150, 331);
            this.labelSPAJInforce.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJInforce.Name = "labelSPAJInforce";
            this.labelSPAJInforce.Size = new System.Drawing.Size(131, 25);
            this.labelSPAJInforce.TabIndex = 15;
            this.labelSPAJInforce.Text = "Inforce date:";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(66, 283);
            this.label144.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(156, 25);
            this.label144.TabIndex = 14;
            this.label144.Text = "Current Status:";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(66, 379);
            this.label143.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(0, 25);
            this.label143.TabIndex = 13;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(66, 219);
            this.label142.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(176, 25);
            this.label142.TabIndex = 12;
            this.label142.Text = "Insurer Birthdate:";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(66, 162);
            this.label141.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(146, 25);
            this.label141.TabIndex = 11;
            this.label141.Text = "Insurer Name:";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label140.Location = new System.Drawing.Point(574, 29);
            this.label140.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(327, 37);
            this.label140.TabIndex = 10;
            this.label140.Text = "Update Status SPAJ";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(66, 100);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(87, 25);
            this.label50.TabIndex = 0;
            this.label50.Text = "Number";
            // 
            // tabPageSPAJAdd
            // 
            this.tabPageSPAJAdd.Controls.Add(this.textBoxSPAJInsType);
            this.tabPageSPAJAdd.Controls.Add(this.buttonSPAJNewCreate);
            this.tabPageSPAJAdd.Controls.Add(this.buttonSPAJNewClear);
            this.tabPageSPAJAdd.Controls.Add(this.dateTimeSPAJSubmit);
            this.tabPageSPAJAdd.Controls.Add(this.label75);
            this.tabPageSPAJAdd.Controls.Add(this.label76);
            this.tabPageSPAJAdd.Controls.Add(this.textBoxPRUFlyerNum);
            this.tabPageSPAJAdd.Controls.Add(this.tabControlAddSPAJ);
            this.tabPageSPAJAdd.Controls.Add(this.label78);
            this.tabPageSPAJAdd.Controls.Add(this.textBoxSPAJANum);
            this.tabPageSPAJAdd.Controls.Add(this.label77);
            this.tabPageSPAJAdd.Controls.Add(this.label98);
            this.tabPageSPAJAdd.Controls.Add(this.label80);
            this.tabPageSPAJAdd.Controls.Add(this.textBoxSPAJAName);
            this.tabPageSPAJAdd.Controls.Add(this.textBoxSPAJNum);
            this.tabPageSPAJAdd.Controls.Add(this.label79);
            this.tabPageSPAJAdd.Location = new System.Drawing.Point(8, 39);
            this.tabPageSPAJAdd.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJAdd.Name = "tabPageSPAJAdd";
            this.tabPageSPAJAdd.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJAdd.Size = new System.Drawing.Size(1488, 678);
            this.tabPageSPAJAdd.TabIndex = 2;
            this.tabPageSPAJAdd.Text = "Add SPAJ";
            this.tabPageSPAJAdd.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJInsType
            // 
            this.textBoxSPAJInsType.Location = new System.Drawing.Point(204, 179);
            this.textBoxSPAJInsType.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJInsType.Name = "textBoxSPAJInsType";
            this.textBoxSPAJInsType.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJInsType.TabIndex = 18;
            // 
            // buttonSPAJNewCreate
            // 
            this.buttonSPAJNewCreate.Enabled = false;
            this.buttonSPAJNewCreate.Location = new System.Drawing.Point(272, 515);
            this.buttonSPAJNewCreate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJNewCreate.Name = "buttonSPAJNewCreate";
            this.buttonSPAJNewCreate.Size = new System.Drawing.Size(108, 38);
            this.buttonSPAJNewCreate.TabIndex = 16;
            this.buttonSPAJNewCreate.Text = "Create";
            this.buttonSPAJNewCreate.UseVisualStyleBackColor = true;
            this.buttonSPAJNewCreate.Click += new System.EventHandler(this.buttonSPAJNewCreate_Click);
            // 
            // buttonSPAJNewClear
            // 
            this.buttonSPAJNewClear.Location = new System.Drawing.Point(42, 515);
            this.buttonSPAJNewClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJNewClear.Name = "buttonSPAJNewClear";
            this.buttonSPAJNewClear.Size = new System.Drawing.Size(108, 38);
            this.buttonSPAJNewClear.TabIndex = 15;
            this.buttonSPAJNewClear.Text = "Clear All";
            this.buttonSPAJNewClear.UseVisualStyleBackColor = true;
            this.buttonSPAJNewClear.Click += new System.EventHandler(this.buttonSPAJNewClear_Click);
            // 
            // dateTimeSPAJSubmit
            // 
            this.dateTimeSPAJSubmit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJSubmit.Location = new System.Drawing.Point(204, 438);
            this.dateTimeSPAJSubmit.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJSubmit.Name = "dateTimeSPAJSubmit";
            this.dateTimeSPAJSubmit.Size = new System.Drawing.Size(186, 31);
            this.dateTimeSPAJSubmit.TabIndex = 12;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(36, 160);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(112, 50);
            this.label75.TabIndex = 2;
            this.label75.Text = "Type of \r\nInsurance:";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(32, 444);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(129, 50);
            this.label76.TabIndex = 7;
            this.label76.Text = "Submission \r\nDate:";
            // 
            // textBoxPRUFlyerNum
            // 
            this.textBoxPRUFlyerNum.Location = new System.Drawing.Point(204, 375);
            this.textBoxPRUFlyerNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPRUFlyerNum.Name = "textBoxPRUFlyerNum";
            this.textBoxPRUFlyerNum.Size = new System.Drawing.Size(186, 31);
            this.textBoxPRUFlyerNum.TabIndex = 11;
            this.textBoxPRUFlyerNum.Text = "0";
            // 
            // tabControlAddSPAJ
            // 
            this.tabControlAddSPAJ.Controls.Add(this.tabPageInsInfo);
            this.tabControlAddSPAJ.Controls.Add(this.tabPagePolisHolder);
            this.tabControlAddSPAJ.Controls.Add(this.tabPageSpouseInfo);
            this.tabControlAddSPAJ.Controls.Add(this.tabPageParentInfo);
            this.tabControlAddSPAJ.Controls.Add(this.tabPageAddressInfo);
            this.tabControlAddSPAJ.Controls.Add(this.tabPagePengajuanInfo);
            this.tabControlAddSPAJ.Controls.Add(this.tabPageBeneficiaryInfo);
            this.tabControlAddSPAJ.Location = new System.Drawing.Point(452, 0);
            this.tabControlAddSPAJ.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlAddSPAJ.Name = "tabControlAddSPAJ";
            this.tabControlAddSPAJ.SelectedIndex = 0;
            this.tabControlAddSPAJ.Size = new System.Drawing.Size(1052, 677);
            this.tabControlAddSPAJ.TabIndex = 14;
            this.tabControlAddSPAJ.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControlAddSPAJ_Selecting);
            // 
            // tabPageInsInfo
            // 
            this.tabPageInsInfo.Controls.Add(this.label150);
            this.tabPageInsInfo.Controls.Add(this.label121);
            this.tabPageInsInfo.Controls.Add(this.buttonInsInfoAccept);
            this.tabPageInsInfo.Controls.Add(this.buttonInsInfoClear);
            this.tabPageInsInfo.Controls.Add(this.dateTimeSPAJInsrDOB);
            this.tabPageInsInfo.Controls.Add(this.comboBoxSPAJJobClass);
            this.tabPageInsInfo.Controls.Add(this.label88);
            this.tabPageInsInfo.Controls.Add(this.comboBoxSPAJInsrMarriage);
            this.tabPageInsInfo.Controls.Add(this.textBoxSPAJInsrNextBday);
            this.tabPageInsInfo.Controls.Add(this.label89);
            this.tabPageInsInfo.Controls.Add(this.comboBoxSPAJInsrGender);
            this.tabPageInsInfo.Controls.Add(this.label90);
            this.tabPageInsInfo.Controls.Add(this.radioButtonSPAJInsrSmoke);
            this.tabPageInsInfo.Controls.Add(this.textBoxSPAJInsrWeight);
            this.tabPageInsInfo.Controls.Add(this.textBoxSPAJInsrName);
            this.tabPageInsInfo.Controls.Add(this.textBoxSPAJInsrHeight);
            this.tabPageInsInfo.Controls.Add(this.label81);
            this.tabPageInsInfo.Controls.Add(this.label82);
            this.tabPageInsInfo.Controls.Add(this.label83);
            this.tabPageInsInfo.Controls.Add(this.label84);
            this.tabPageInsInfo.Controls.Add(this.label85);
            this.tabPageInsInfo.Controls.Add(this.label86);
            this.tabPageInsInfo.Controls.Add(this.label87);
            this.tabPageInsInfo.Controls.Add(this.label91);
            this.tabPageInsInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageInsInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageInsInfo.Name = "tabPageInsInfo";
            this.tabPageInsInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageInsInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPageInsInfo.TabIndex = 1;
            this.tabPageInsInfo.Text = "Insurer Info";
            this.tabPageInsInfo.UseVisualStyleBackColor = true;
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(732, 154);
            this.label150.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(35, 25);
            this.label150.TabIndex = 24;
            this.label150.Text = "kg";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(732, 102);
            this.label121.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(40, 25);
            this.label121.TabIndex = 23;
            this.label121.Text = "cm";
            // 
            // buttonInsInfoAccept
            // 
            this.buttonInsInfoAccept.Location = new System.Drawing.Point(528, 477);
            this.buttonInsInfoAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonInsInfoAccept.Name = "buttonInsInfoAccept";
            this.buttonInsInfoAccept.Size = new System.Drawing.Size(144, 46);
            this.buttonInsInfoAccept.TabIndex = 22;
            this.buttonInsInfoAccept.Text = "Accept";
            this.buttonInsInfoAccept.UseVisualStyleBackColor = true;
            this.buttonInsInfoAccept.Click += new System.EventHandler(this.buttonInsInfoAccept_Click);
            // 
            // buttonInsInfoClear
            // 
            this.buttonInsInfoClear.Location = new System.Drawing.Point(328, 477);
            this.buttonInsInfoClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonInsInfoClear.Name = "buttonInsInfoClear";
            this.buttonInsInfoClear.Size = new System.Drawing.Size(144, 46);
            this.buttonInsInfoClear.TabIndex = 21;
            this.buttonInsInfoClear.Text = "Clear";
            this.buttonInsInfoClear.UseVisualStyleBackColor = true;
            this.buttonInsInfoClear.Click += new System.EventHandler(this.buttonInsInfoClear_Click);
            // 
            // dateTimeSPAJInsrDOB
            // 
            this.dateTimeSPAJInsrDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJInsrDOB.Location = new System.Drawing.Point(244, 202);
            this.dateTimeSPAJInsrDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJInsrDOB.Name = "dateTimeSPAJInsrDOB";
            this.dateTimeSPAJInsrDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJInsrDOB.TabIndex = 20;
            // 
            // comboBoxSPAJJobClass
            // 
            this.comboBoxSPAJJobClass.FormattingEnabled = true;
            this.comboBoxSPAJJobClass.Items.AddRange(new object[] {
            "Class I ",
            "Class II ",
            "Class III"});
            this.comboBoxSPAJJobClass.Location = new System.Drawing.Point(636, 269);
            this.comboBoxSPAJJobClass.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJJobClass.Name = "comboBoxSPAJJobClass";
            this.comboBoxSPAJJobClass.Size = new System.Drawing.Size(120, 33);
            this.comboBoxSPAJJobClass.TabIndex = 19;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(62, 202);
            this.label88.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(104, 25);
            this.label88.TabIndex = 3;
            this.label88.Text = "Birthdate:";
            // 
            // comboBoxSPAJInsrMarriage
            // 
            this.comboBoxSPAJInsrMarriage.FormattingEnabled = true;
            this.comboBoxSPAJInsrMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJInsrMarriage.Location = new System.Drawing.Point(244, 262);
            this.comboBoxSPAJInsrMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJInsrMarriage.Name = "comboBoxSPAJInsrMarriage";
            this.comboBoxSPAJInsrMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJInsrMarriage.TabIndex = 18;
            // 
            // textBoxSPAJInsrNextBday
            // 
            this.textBoxSPAJInsrNextBday.Location = new System.Drawing.Point(244, 337);
            this.textBoxSPAJInsrNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJInsrNextBday.Name = "textBoxSPAJInsrNextBday";
            this.textBoxSPAJInsrNextBday.ReadOnly = true;
            this.textBoxSPAJInsrNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJInsrNextBday.TabIndex = 16;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(62, 154);
            this.label89.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(89, 25);
            this.label89.TabIndex = 2;
            this.label89.Text = "Gender:";
            // 
            // comboBoxSPAJInsrGender
            // 
            this.comboBoxSPAJInsrGender.FormattingEnabled = true;
            this.comboBoxSPAJInsrGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJInsrGender.Location = new System.Drawing.Point(244, 152);
            this.comboBoxSPAJInsrGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJInsrGender.Name = "comboBoxSPAJInsrGender";
            this.comboBoxSPAJInsrGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJInsrGender.TabIndex = 17;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(62, 98);
            this.label90.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(121, 25);
            this.label90.TabIndex = 1;
            this.label90.Text = "Full Name: ";
            // 
            // radioButtonSPAJInsrSmoke
            // 
            this.radioButtonSPAJInsrSmoke.AutoSize = true;
            this.radioButtonSPAJInsrSmoke.Location = new System.Drawing.Point(770, 223);
            this.radioButtonSPAJInsrSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJInsrSmoke.Name = "radioButtonSPAJInsrSmoke";
            this.radioButtonSPAJInsrSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJInsrSmoke.TabIndex = 15;
            this.radioButtonSPAJInsrSmoke.TabStop = true;
            this.radioButtonSPAJInsrSmoke.Text = "Yes";
            this.radioButtonSPAJInsrSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJInsrWeight
            // 
            this.textBoxSPAJInsrWeight.Location = new System.Drawing.Point(636, 148);
            this.textBoxSPAJInsrWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJInsrWeight.Name = "textBoxSPAJInsrWeight";
            this.textBoxSPAJInsrWeight.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJInsrWeight.TabIndex = 14;
            // 
            // textBoxSPAJInsrName
            // 
            this.textBoxSPAJInsrName.Location = new System.Drawing.Point(244, 98);
            this.textBoxSPAJInsrName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJInsrName.Name = "textBoxSPAJInsrName";
            this.textBoxSPAJInsrName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJInsrName.TabIndex = 12;
            // 
            // textBoxSPAJInsrHeight
            // 
            this.textBoxSPAJInsrHeight.Location = new System.Drawing.Point(636, 98);
            this.textBoxSPAJInsrHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJInsrHeight.Name = "textBoxSPAJInsrHeight";
            this.textBoxSPAJInsrHeight.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJInsrHeight.TabIndex = 13;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(512, 269);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(72, 50);
            this.label81.TabIndex = 11;
            this.label81.Text = "Job \r\nClass:";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(512, 202);
            this.label82.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(223, 50);
            this.label82.TabIndex = 10;
            this.label82.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(512, 154);
            this.label83.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(85, 25);
            this.label83.TabIndex = 9;
            this.label83.Text = "Weight:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(512, 104);
            this.label84.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(80, 25);
            this.label84.TabIndex = 8;
            this.label84.Text = "Height:";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(62, 337);
            this.label85.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(147, 50);
            this.label85.TabIndex = 6;
            this.label85.Text = "Age at the\r\nNext Birthday:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(62, 252);
            this.label86.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(103, 50);
            this.label86.TabIndex = 5;
            this.label86.Text = "Marriage \r\nStatus:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(50, 252);
            this.label87.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(0, 25);
            this.label87.TabIndex = 4;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label91.Location = new System.Drawing.Point(352, 33);
            this.label91.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(305, 37);
            this.label91.TabIndex = 0;
            this.label91.Text = "Insurer Information";
            // 
            // tabPagePolisHolder
            // 
            this.tabPagePolisHolder.Controls.Add(this.buttonAddSPAJPolisBack);
            this.tabPagePolisHolder.Controls.Add(this.buttonPolisHolderAccept);
            this.tabPagePolisHolder.Controls.Add(this.buttonPolisHolderClear);
            this.tabPagePolisHolder.Controls.Add(this.dateTimeSPAJPolisDOB);
            this.tabPagePolisHolder.Controls.Add(this.comboBoxSPAJPolisRs);
            this.tabPagePolisHolder.Controls.Add(this.comboBoxSPAJPolisMarriage);
            this.tabPagePolisHolder.Controls.Add(this.comboBoxSPAJPolisGender);
            this.tabPagePolisHolder.Controls.Add(this.textBoxSPAJPolisName);
            this.tabPagePolisHolder.Controls.Add(this.label92);
            this.tabPagePolisHolder.Controls.Add(this.label93);
            this.tabPagePolisHolder.Controls.Add(this.label94);
            this.tabPagePolisHolder.Controls.Add(this.label95);
            this.tabPagePolisHolder.Controls.Add(this.label96);
            this.tabPagePolisHolder.Controls.Add(this.label97);
            this.tabPagePolisHolder.Location = new System.Drawing.Point(8, 39);
            this.tabPagePolisHolder.Margin = new System.Windows.Forms.Padding(6);
            this.tabPagePolisHolder.Name = "tabPagePolisHolder";
            this.tabPagePolisHolder.Size = new System.Drawing.Size(1036, 630);
            this.tabPagePolisHolder.TabIndex = 2;
            this.tabPagePolisHolder.Text = "Polis Holder Info";
            this.tabPagePolisHolder.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJPolisBack
            // 
            this.buttonAddSPAJPolisBack.Location = new System.Drawing.Point(210, 463);
            this.buttonAddSPAJPolisBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJPolisBack.Name = "buttonAddSPAJPolisBack";
            this.buttonAddSPAJPolisBack.Size = new System.Drawing.Size(150, 44);
            this.buttonAddSPAJPolisBack.TabIndex = 15;
            this.buttonAddSPAJPolisBack.Text = "Back";
            this.buttonAddSPAJPolisBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJPolisBack.Click += new System.EventHandler(this.buttonAddSPAJPolisBack_Click);
            // 
            // buttonPolisHolderAccept
            // 
            this.buttonPolisHolderAccept.Location = new System.Drawing.Point(664, 463);
            this.buttonPolisHolderAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPolisHolderAccept.Name = "buttonPolisHolderAccept";
            this.buttonPolisHolderAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonPolisHolderAccept.TabIndex = 14;
            this.buttonPolisHolderAccept.Text = "Accept";
            this.buttonPolisHolderAccept.UseVisualStyleBackColor = true;
            this.buttonPolisHolderAccept.Click += new System.EventHandler(this.buttonPolisHolderAccept_Click);
            // 
            // buttonPolisHolderClear
            // 
            this.buttonPolisHolderClear.Location = new System.Drawing.Point(442, 463);
            this.buttonPolisHolderClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPolisHolderClear.Name = "buttonPolisHolderClear";
            this.buttonPolisHolderClear.Size = new System.Drawing.Size(120, 48);
            this.buttonPolisHolderClear.TabIndex = 13;
            this.buttonPolisHolderClear.Text = "Clear";
            this.buttonPolisHolderClear.UseVisualStyleBackColor = true;
            this.buttonPolisHolderClear.Click += new System.EventHandler(this.buttonPolisHolderClear_Click);
            // 
            // dateTimeSPAJPolisDOB
            // 
            this.dateTimeSPAJPolisDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJPolisDOB.Location = new System.Drawing.Point(392, 223);
            this.dateTimeSPAJPolisDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJPolisDOB.Name = "dateTimeSPAJPolisDOB";
            this.dateTimeSPAJPolisDOB.Size = new System.Drawing.Size(222, 31);
            this.dateTimeSPAJPolisDOB.TabIndex = 11;
            // 
            // comboBoxSPAJPolisRs
            // 
            this.comboBoxSPAJPolisRs.FormattingEnabled = true;
            this.comboBoxSPAJPolisRs.Items.AddRange(new object[] {
            "Self",
            "Parents",
            "Sibling",
            "Spouse",
            "Children",
            "Other"});
            this.comboBoxSPAJPolisRs.Location = new System.Drawing.Point(392, 367);
            this.comboBoxSPAJPolisRs.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJPolisRs.Name = "comboBoxSPAJPolisRs";
            this.comboBoxSPAJPolisRs.Size = new System.Drawing.Size(162, 33);
            this.comboBoxSPAJPolisRs.TabIndex = 10;
            // 
            // comboBoxSPAJPolisMarriage
            // 
            this.comboBoxSPAJPolisMarriage.FormattingEnabled = true;
            this.comboBoxSPAJPolisMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJPolisMarriage.Location = new System.Drawing.Point(392, 296);
            this.comboBoxSPAJPolisMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJPolisMarriage.Name = "comboBoxSPAJPolisMarriage";
            this.comboBoxSPAJPolisMarriage.Size = new System.Drawing.Size(162, 33);
            this.comboBoxSPAJPolisMarriage.TabIndex = 9;
            // 
            // comboBoxSPAJPolisGender
            // 
            this.comboBoxSPAJPolisGender.FormattingEnabled = true;
            this.comboBoxSPAJPolisGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJPolisGender.Location = new System.Drawing.Point(392, 144);
            this.comboBoxSPAJPolisGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJPolisGender.Name = "comboBoxSPAJPolisGender";
            this.comboBoxSPAJPolisGender.Size = new System.Drawing.Size(110, 33);
            this.comboBoxSPAJPolisGender.TabIndex = 8;
            // 
            // textBoxSPAJPolisName
            // 
            this.textBoxSPAJPolisName.Location = new System.Drawing.Point(392, 81);
            this.textBoxSPAJPolisName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJPolisName.Name = "textBoxSPAJPolisName";
            this.textBoxSPAJPolisName.Size = new System.Drawing.Size(248, 31);
            this.textBoxSPAJPolisName.TabIndex = 7;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(204, 350);
            this.label92.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(137, 50);
            this.label92.TabIndex = 6;
            this.label92.Text = "Relationship \r\nwith Insurer:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(204, 279);
            this.label93.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(103, 50);
            this.label93.TabIndex = 5;
            this.label93.Text = "Marriage \r\nStatus:";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(204, 231);
            this.label94.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(104, 25);
            this.label94.TabIndex = 4;
            this.label94.Text = "Birthdate:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(204, 154);
            this.label95.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(89, 25);
            this.label95.TabIndex = 3;
            this.label95.Text = "Gender:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(204, 81);
            this.label96.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(115, 25);
            this.label96.TabIndex = 2;
            this.label96.Text = "Full Name:";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label97.Location = new System.Drawing.Point(312, 31);
            this.label97.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(383, 37);
            this.label97.TabIndex = 1;
            this.label97.Text = "Polis Holder Information";
            // 
            // tabPageSpouseInfo
            // 
            this.tabPageSpouseInfo.Controls.Add(this.buttonAddSPAJSpouseBack);
            this.tabPageSpouseInfo.Controls.Add(this.label152);
            this.tabPageSpouseInfo.Controls.Add(this.label151);
            this.tabPageSpouseInfo.Controls.Add(this.buttonSpouseIgnore);
            this.tabPageSpouseInfo.Controls.Add(this.buttonSpouseAccept);
            this.tabPageSpouseInfo.Controls.Add(this.buttonSpouseClear);
            this.tabPageSpouseInfo.Controls.Add(this.dateTimeSPAJSpouseDOB);
            this.tabPageSpouseInfo.Controls.Add(this.comboBoxSPAJSpouseMarriage);
            this.tabPageSpouseInfo.Controls.Add(this.comboBoxSPAJSpouseGender);
            this.tabPageSpouseInfo.Controls.Add(this.textBoxSPAJSpouseNextBday);
            this.tabPageSpouseInfo.Controls.Add(this.radioButtonSPAJSpouseSmoke);
            this.tabPageSpouseInfo.Controls.Add(this.textBoxSPAJSpouseWeight);
            this.tabPageSpouseInfo.Controls.Add(this.textBoxSPAJSpouseHeight);
            this.tabPageSpouseInfo.Controls.Add(this.textBoxSPAJSpouseName);
            this.tabPageSpouseInfo.Controls.Add(this.label3);
            this.tabPageSpouseInfo.Controls.Add(this.label4);
            this.tabPageSpouseInfo.Controls.Add(this.label5);
            this.tabPageSpouseInfo.Controls.Add(this.label6);
            this.tabPageSpouseInfo.Controls.Add(this.label7);
            this.tabPageSpouseInfo.Controls.Add(this.label8);
            this.tabPageSpouseInfo.Controls.Add(this.label9);
            this.tabPageSpouseInfo.Controls.Add(this.label10);
            this.tabPageSpouseInfo.Controls.Add(this.label11);
            this.tabPageSpouseInfo.Controls.Add(this.label12);
            this.tabPageSpouseInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageSpouseInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageSpouseInfo.Name = "tabPageSpouseInfo";
            this.tabPageSpouseInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageSpouseInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPageSpouseInfo.TabIndex = 4;
            this.tabPageSpouseInfo.Text = "Spouse/Parent 1 Info";
            this.tabPageSpouseInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJSpouseBack
            // 
            this.buttonAddSPAJSpouseBack.Location = new System.Drawing.Point(114, 473);
            this.buttonAddSPAJSpouseBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJSpouseBack.Name = "buttonAddSPAJSpouseBack";
            this.buttonAddSPAJSpouseBack.Size = new System.Drawing.Size(150, 44);
            this.buttonAddSPAJSpouseBack.TabIndex = 28;
            this.buttonAddSPAJSpouseBack.Text = "Back";
            this.buttonAddSPAJSpouseBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJSpouseBack.Click += new System.EventHandler(this.buttonAddSPAJSpouseBack_Click);
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(696, 156);
            this.label152.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(35, 25);
            this.label152.TabIndex = 27;
            this.label152.Text = "kg";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(696, 104);
            this.label151.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(40, 25);
            this.label151.TabIndex = 26;
            this.label151.Text = "cm";
            // 
            // buttonSpouseIgnore
            // 
            this.buttonSpouseIgnore.Location = new System.Drawing.Point(346, 473);
            this.buttonSpouseIgnore.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSpouseIgnore.Name = "buttonSpouseIgnore";
            this.buttonSpouseIgnore.Size = new System.Drawing.Size(120, 48);
            this.buttonSpouseIgnore.TabIndex = 25;
            this.buttonSpouseIgnore.Text = "Ignore";
            this.buttonSpouseIgnore.UseVisualStyleBackColor = true;
            this.buttonSpouseIgnore.Click += new System.EventHandler(this.buttonSpouseIgnore_Click);
            // 
            // buttonSpouseAccept
            // 
            this.buttonSpouseAccept.Location = new System.Drawing.Point(764, 473);
            this.buttonSpouseAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSpouseAccept.Name = "buttonSpouseAccept";
            this.buttonSpouseAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonSpouseAccept.TabIndex = 24;
            this.buttonSpouseAccept.Text = "Accept";
            this.buttonSpouseAccept.UseVisualStyleBackColor = true;
            this.buttonSpouseAccept.Click += new System.EventHandler(this.buttonSpouseAccept_Click);
            // 
            // buttonSpouseClear
            // 
            this.buttonSpouseClear.Location = new System.Drawing.Point(548, 473);
            this.buttonSpouseClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSpouseClear.Name = "buttonSpouseClear";
            this.buttonSpouseClear.Size = new System.Drawing.Size(128, 48);
            this.buttonSpouseClear.TabIndex = 23;
            this.buttonSpouseClear.Text = "Clear";
            this.buttonSpouseClear.UseVisualStyleBackColor = true;
            this.buttonSpouseClear.Click += new System.EventHandler(this.buttonSpouseClear_Click);
            // 
            // dateTimeSPAJSpouseDOB
            // 
            this.dateTimeSPAJSpouseDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJSpouseDOB.Location = new System.Drawing.Point(200, 196);
            this.dateTimeSPAJSpouseDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJSpouseDOB.Name = "dateTimeSPAJSpouseDOB";
            this.dateTimeSPAJSpouseDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJSpouseDOB.TabIndex = 20;
            // 
            // comboBoxSPAJSpouseMarriage
            // 
            this.comboBoxSPAJSpouseMarriage.FormattingEnabled = true;
            this.comboBoxSPAJSpouseMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJSpouseMarriage.Location = new System.Drawing.Point(200, 246);
            this.comboBoxSPAJSpouseMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJSpouseMarriage.Name = "comboBoxSPAJSpouseMarriage";
            this.comboBoxSPAJSpouseMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJSpouseMarriage.TabIndex = 18;
            // 
            // comboBoxSPAJSpouseGender
            // 
            this.comboBoxSPAJSpouseGender.FormattingEnabled = true;
            this.comboBoxSPAJSpouseGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJSpouseGender.Location = new System.Drawing.Point(200, 148);
            this.comboBoxSPAJSpouseGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJSpouseGender.Name = "comboBoxSPAJSpouseGender";
            this.comboBoxSPAJSpouseGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJSpouseGender.TabIndex = 17;
            // 
            // textBoxSPAJSpouseNextBday
            // 
            this.textBoxSPAJSpouseNextBday.Location = new System.Drawing.Point(200, 312);
            this.textBoxSPAJSpouseNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJSpouseNextBday.Name = "textBoxSPAJSpouseNextBday";
            this.textBoxSPAJSpouseNextBday.ReadOnly = true;
            this.textBoxSPAJSpouseNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJSpouseNextBday.TabIndex = 16;
            // 
            // radioButtonSPAJSpouseSmoke
            // 
            this.radioButtonSPAJSpouseSmoke.AutoSize = true;
            this.radioButtonSPAJSpouseSmoke.Location = new System.Drawing.Point(676, 219);
            this.radioButtonSPAJSpouseSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJSpouseSmoke.Name = "radioButtonSPAJSpouseSmoke";
            this.radioButtonSPAJSpouseSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJSpouseSmoke.TabIndex = 15;
            this.radioButtonSPAJSpouseSmoke.TabStop = true;
            this.radioButtonSPAJSpouseSmoke.Text = "Yes";
            this.radioButtonSPAJSpouseSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJSpouseWeight
            // 
            this.textBoxSPAJSpouseWeight.Location = new System.Drawing.Point(568, 148);
            this.textBoxSPAJSpouseWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJSpouseWeight.Name = "textBoxSPAJSpouseWeight";
            this.textBoxSPAJSpouseWeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJSpouseWeight.TabIndex = 14;
            // 
            // textBoxSPAJSpouseHeight
            // 
            this.textBoxSPAJSpouseHeight.Location = new System.Drawing.Point(568, 98);
            this.textBoxSPAJSpouseHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJSpouseHeight.Name = "textBoxSPAJSpouseHeight";
            this.textBoxSPAJSpouseHeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJSpouseHeight.TabIndex = 13;
            // 
            // textBoxSPAJSpouseName
            // 
            this.textBoxSPAJSpouseName.Location = new System.Drawing.Point(200, 98);
            this.textBoxSPAJSpouseName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJSpouseName.Name = "textBoxSPAJSpouseName";
            this.textBoxSPAJSpouseName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJSpouseName.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(470, 202);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(223, 50);
            this.label3.TabIndex = 10;
            this.label3.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(470, 154);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 25);
            this.label4.TabIndex = 9;
            this.label4.Text = "Weight:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(470, 104);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Height:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(50, 294);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 50);
            this.label6.TabIndex = 6;
            this.label6.Text = "Age at the\r\nNext Birthday:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 242);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 50);
            this.label7.TabIndex = 5;
            this.label7.Text = "Marriage \r\nStatus:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(50, 252);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 25);
            this.label8.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 202);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(104, 25);
            this.label9.TabIndex = 3;
            this.label9.Text = "Birthdate:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(48, 154);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 25);
            this.label10.TabIndex = 2;
            this.label10.Text = "Gender:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(48, 104);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 25);
            this.label11.TabIndex = 1;
            this.label11.Text = "Full Name: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(262, 31);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(376, 37);
            this.label12.TabIndex = 0;
            this.label12.Text = "Spouse or Parent 1 Info";
            // 
            // tabPageParentInfo
            // 
            this.tabPageParentInfo.Controls.Add(this.buttonAddSPAJParentBack);
            this.tabPageParentInfo.Controls.Add(this.label154);
            this.tabPageParentInfo.Controls.Add(this.label153);
            this.tabPageParentInfo.Controls.Add(this.buttonParentIgnore);
            this.tabPageParentInfo.Controls.Add(this.buttonParentAccept);
            this.tabPageParentInfo.Controls.Add(this.buttonParentClear);
            this.tabPageParentInfo.Controls.Add(this.dateTimeSPAJParentDOB);
            this.tabPageParentInfo.Controls.Add(this.comboBoxSPAJParentMarriage);
            this.tabPageParentInfo.Controls.Add(this.comboBoxSPAJParentGender);
            this.tabPageParentInfo.Controls.Add(this.textBoxSPAJParentNextBday);
            this.tabPageParentInfo.Controls.Add(this.radioButtonSPAJParentSmoke);
            this.tabPageParentInfo.Controls.Add(this.textBoxSPAJParentWeight);
            this.tabPageParentInfo.Controls.Add(this.textBoxSPAJParentHeight);
            this.tabPageParentInfo.Controls.Add(this.textBoxSPAJParentName);
            this.tabPageParentInfo.Controls.Add(this.label2);
            this.tabPageParentInfo.Controls.Add(this.label13);
            this.tabPageParentInfo.Controls.Add(this.label14);
            this.tabPageParentInfo.Controls.Add(this.label15);
            this.tabPageParentInfo.Controls.Add(this.label16);
            this.tabPageParentInfo.Controls.Add(this.label17);
            this.tabPageParentInfo.Controls.Add(this.label18);
            this.tabPageParentInfo.Controls.Add(this.label19);
            this.tabPageParentInfo.Controls.Add(this.label20);
            this.tabPageParentInfo.Controls.Add(this.label21);
            this.tabPageParentInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageParentInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageParentInfo.Name = "tabPageParentInfo";
            this.tabPageParentInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageParentInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPageParentInfo.TabIndex = 6;
            this.tabPageParentInfo.Text = "Parent 2 Info";
            this.tabPageParentInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJParentBack
            // 
            this.buttonAddSPAJParentBack.Location = new System.Drawing.Point(124, 475);
            this.buttonAddSPAJParentBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJParentBack.Name = "buttonAddSPAJParentBack";
            this.buttonAddSPAJParentBack.Size = new System.Drawing.Size(150, 44);
            this.buttonAddSPAJParentBack.TabIndex = 29;
            this.buttonAddSPAJParentBack.Text = "Back";
            this.buttonAddSPAJParentBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJParentBack.Click += new System.EventHandler(this.buttonAddSPAJParentBack_Click);
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(702, 156);
            this.label154.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(35, 25);
            this.label154.TabIndex = 25;
            this.label154.Text = "kg";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(696, 104);
            this.label153.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(40, 25);
            this.label153.TabIndex = 24;
            this.label153.Text = "cm";
            // 
            // buttonParentIgnore
            // 
            this.buttonParentIgnore.Location = new System.Drawing.Point(348, 473);
            this.buttonParentIgnore.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParentIgnore.Name = "buttonParentIgnore";
            this.buttonParentIgnore.Size = new System.Drawing.Size(120, 48);
            this.buttonParentIgnore.TabIndex = 23;
            this.buttonParentIgnore.Text = "Ignore";
            this.buttonParentIgnore.UseVisualStyleBackColor = true;
            this.buttonParentIgnore.Click += new System.EventHandler(this.buttonParentIgnore_Click);
            // 
            // buttonParentAccept
            // 
            this.buttonParentAccept.Location = new System.Drawing.Point(748, 473);
            this.buttonParentAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParentAccept.Name = "buttonParentAccept";
            this.buttonParentAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonParentAccept.TabIndex = 22;
            this.buttonParentAccept.Text = "Accept";
            this.buttonParentAccept.UseVisualStyleBackColor = true;
            this.buttonParentAccept.Click += new System.EventHandler(this.buttonParentAccept_Click);
            // 
            // buttonParentClear
            // 
            this.buttonParentClear.Location = new System.Drawing.Point(550, 473);
            this.buttonParentClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParentClear.Name = "buttonParentClear";
            this.buttonParentClear.Size = new System.Drawing.Size(120, 48);
            this.buttonParentClear.TabIndex = 21;
            this.buttonParentClear.Text = "Clear";
            this.buttonParentClear.UseVisualStyleBackColor = true;
            this.buttonParentClear.Click += new System.EventHandler(this.buttonParentClear_Click);
            // 
            // dateTimeSPAJParentDOB
            // 
            this.dateTimeSPAJParentDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJParentDOB.Location = new System.Drawing.Point(200, 196);
            this.dateTimeSPAJParentDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJParentDOB.Name = "dateTimeSPAJParentDOB";
            this.dateTimeSPAJParentDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJParentDOB.TabIndex = 20;
            // 
            // comboBoxSPAJParentMarriage
            // 
            this.comboBoxSPAJParentMarriage.FormattingEnabled = true;
            this.comboBoxSPAJParentMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJParentMarriage.Location = new System.Drawing.Point(200, 246);
            this.comboBoxSPAJParentMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJParentMarriage.Name = "comboBoxSPAJParentMarriage";
            this.comboBoxSPAJParentMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJParentMarriage.TabIndex = 18;
            // 
            // comboBoxSPAJParentGender
            // 
            this.comboBoxSPAJParentGender.FormattingEnabled = true;
            this.comboBoxSPAJParentGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJParentGender.Location = new System.Drawing.Point(200, 148);
            this.comboBoxSPAJParentGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJParentGender.Name = "comboBoxSPAJParentGender";
            this.comboBoxSPAJParentGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJParentGender.TabIndex = 17;
            // 
            // textBoxSPAJParentNextBday
            // 
            this.textBoxSPAJParentNextBday.Location = new System.Drawing.Point(200, 312);
            this.textBoxSPAJParentNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJParentNextBday.Name = "textBoxSPAJParentNextBday";
            this.textBoxSPAJParentNextBday.ReadOnly = true;
            this.textBoxSPAJParentNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJParentNextBday.TabIndex = 16;
            // 
            // radioButtonSPAJParentSmoke
            // 
            this.radioButtonSPAJParentSmoke.AutoSize = true;
            this.radioButtonSPAJParentSmoke.Location = new System.Drawing.Point(676, 219);
            this.radioButtonSPAJParentSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJParentSmoke.Name = "radioButtonSPAJParentSmoke";
            this.radioButtonSPAJParentSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJParentSmoke.TabIndex = 15;
            this.radioButtonSPAJParentSmoke.TabStop = true;
            this.radioButtonSPAJParentSmoke.Text = "Yes";
            this.radioButtonSPAJParentSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJParentWeight
            // 
            this.textBoxSPAJParentWeight.Location = new System.Drawing.Point(568, 148);
            this.textBoxSPAJParentWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJParentWeight.Name = "textBoxSPAJParentWeight";
            this.textBoxSPAJParentWeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJParentWeight.TabIndex = 14;
            // 
            // textBoxSPAJParentHeight
            // 
            this.textBoxSPAJParentHeight.Location = new System.Drawing.Point(568, 98);
            this.textBoxSPAJParentHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJParentHeight.Name = "textBoxSPAJParentHeight";
            this.textBoxSPAJParentHeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJParentHeight.TabIndex = 13;
            // 
            // textBoxSPAJParentName
            // 
            this.textBoxSPAJParentName.Location = new System.Drawing.Point(200, 98);
            this.textBoxSPAJParentName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJParentName.Name = "textBoxSPAJParentName";
            this.textBoxSPAJParentName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJParentName.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(470, 202);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 50);
            this.label2.TabIndex = 10;
            this.label2.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(470, 154);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 25);
            this.label13.TabIndex = 9;
            this.label13.Text = "Weight:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(470, 104);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 25);
            this.label14.TabIndex = 8;
            this.label14.Text = "Height:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(50, 294);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(147, 50);
            this.label15.TabIndex = 6;
            this.label15.Text = "Age at the\r\nNext Birthday:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(52, 242);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 50);
            this.label16.TabIndex = 5;
            this.label16.Text = "Marriage \r\nStatus:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(50, 252);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 25);
            this.label17.TabIndex = 4;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 202);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 25);
            this.label18.TabIndex = 3;
            this.label18.Text = "Birthdate:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(48, 154);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 25);
            this.label19.TabIndex = 2;
            this.label19.Text = "Gender:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(48, 104);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 25);
            this.label20.TabIndex = 1;
            this.label20.Text = "Full Name: ";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label21.Location = new System.Drawing.Point(354, 33);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(213, 37);
            this.label21.TabIndex = 0;
            this.label21.Text = "Parent 2 Info";
            // 
            // tabPageAddressInfo
            // 
            this.tabPageAddressInfo.Controls.Add(this.buttonAddSPAJAddressBack);
            this.tabPageAddressInfo.Controls.Add(this.buttonAddressAccept);
            this.tabPageAddressInfo.Controls.Add(this.buttonAddressClear);
            this.tabPageAddressInfo.Controls.Add(this.label28);
            this.tabPageAddressInfo.Controls.Add(this.label27);
            this.tabPageAddressInfo.Controls.Add(this.label26);
            this.tabPageAddressInfo.Controls.Add(this.label25);
            this.tabPageAddressInfo.Controls.Add(this.label24);
            this.tabPageAddressInfo.Controls.Add(this.label23);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrOP);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrHP);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrEmail);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrZip);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrCity);
            this.tabPageAddressInfo.Controls.Add(this.textBoxSPAJAddrAddress);
            this.tabPageAddressInfo.Controls.Add(this.label22);
            this.tabPageAddressInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageAddressInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageAddressInfo.Name = "tabPageAddressInfo";
            this.tabPageAddressInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPageAddressInfo.TabIndex = 5;
            this.tabPageAddressInfo.Text = "Address Info";
            this.tabPageAddressInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJAddressBack
            // 
            this.buttonAddSPAJAddressBack.Location = new System.Drawing.Point(240, 510);
            this.buttonAddSPAJAddressBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJAddressBack.Name = "buttonAddSPAJAddressBack";
            this.buttonAddSPAJAddressBack.Size = new System.Drawing.Size(150, 44);
            this.buttonAddSPAJAddressBack.TabIndex = 29;
            this.buttonAddSPAJAddressBack.Text = "Back";
            this.buttonAddSPAJAddressBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJAddressBack.Click += new System.EventHandler(this.buttonAddSPAJAddressBack_Click);
            // 
            // buttonAddressAccept
            // 
            this.buttonAddressAccept.Location = new System.Drawing.Point(682, 510);
            this.buttonAddressAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddressAccept.Name = "buttonAddressAccept";
            this.buttonAddressAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonAddressAccept.TabIndex = 17;
            this.buttonAddressAccept.Text = "Accept";
            this.buttonAddressAccept.UseVisualStyleBackColor = true;
            this.buttonAddressAccept.Click += new System.EventHandler(this.buttonAddressAccept_Click);
            // 
            // buttonAddressClear
            // 
            this.buttonAddressClear.Location = new System.Drawing.Point(482, 510);
            this.buttonAddressClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddressClear.Name = "buttonAddressClear";
            this.buttonAddressClear.Size = new System.Drawing.Size(120, 48);
            this.buttonAddressClear.TabIndex = 16;
            this.buttonAddressClear.Text = "Clear";
            this.buttonAddressClear.UseVisualStyleBackColor = true;
            this.buttonAddressClear.Click += new System.EventHandler(this.buttonAddressClear_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(212, 419);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(136, 50);
            this.label28.TabIndex = 15;
            this.label28.Text = "Office Phone\r\n Number:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(212, 351);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(131, 50);
            this.label27.TabIndex = 14;
            this.label27.Text = "HandPhone \r\nNumber:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(212, 301);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 25);
            this.label26.TabIndex = 13;
            this.label26.Text = "Email";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(212, 245);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(93, 25);
            this.label25.TabIndex = 12;
            this.label25.Text = "ZipCode";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(212, 183);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 25);
            this.label24.TabIndex = 11;
            this.label24.Text = "City ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(212, 106);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(91, 25);
            this.label23.TabIndex = 10;
            this.label23.Text = "Address";
            // 
            // textBoxSPAJAddrOP
            // 
            this.textBoxSPAJAddrOP.Location = new System.Drawing.Point(424, 438);
            this.textBoxSPAJAddrOP.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrOP.Name = "textBoxSPAJAddrOP";
            this.textBoxSPAJAddrOP.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJAddrOP.TabIndex = 8;
            this.textBoxSPAJAddrOP.Text = "082112345678";
            // 
            // textBoxSPAJAddrHP
            // 
            this.textBoxSPAJAddrHP.Location = new System.Drawing.Point(424, 370);
            this.textBoxSPAJAddrHP.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrHP.Name = "textBoxSPAJAddrHP";
            this.textBoxSPAJAddrHP.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJAddrHP.TabIndex = 7;
            this.textBoxSPAJAddrHP.Text = "082112345678";
            // 
            // textBoxSPAJAddrEmail
            // 
            this.textBoxSPAJAddrEmail.Location = new System.Drawing.Point(425, 301);
            this.textBoxSPAJAddrEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrEmail.Name = "textBoxSPAJAddrEmail";
            this.textBoxSPAJAddrEmail.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJAddrEmail.TabIndex = 6;
            // 
            // textBoxSPAJAddrZip
            // 
            this.textBoxSPAJAddrZip.Location = new System.Drawing.Point(424, 239);
            this.textBoxSPAJAddrZip.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrZip.Name = "textBoxSPAJAddrZip";
            this.textBoxSPAJAddrZip.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJAddrZip.TabIndex = 5;
            // 
            // textBoxSPAJAddrCity
            // 
            this.textBoxSPAJAddrCity.Location = new System.Drawing.Point(425, 180);
            this.textBoxSPAJAddrCity.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrCity.Name = "textBoxSPAJAddrCity";
            this.textBoxSPAJAddrCity.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJAddrCity.TabIndex = 4;
            // 
            // textBoxSPAJAddrAddress
            // 
            this.textBoxSPAJAddrAddress.Location = new System.Drawing.Point(422, 104);
            this.textBoxSPAJAddrAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAddrAddress.Multiline = true;
            this.textBoxSPAJAddrAddress.Name = "textBoxSPAJAddrAddress";
            this.textBoxSPAJAddrAddress.Size = new System.Drawing.Size(333, 65);
            this.textBoxSPAJAddrAddress.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label22.Location = new System.Drawing.Point(416, 42);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(209, 37);
            this.label22.TabIndex = 2;
            this.label22.Text = "Address Info";
            // 
            // tabPagePengajuanInfo
            // 
            this.tabPagePengajuanInfo.Controls.Add(this.buttonSPAJPengajuanNext);
            this.tabPagePengajuanInfo.Controls.Add(this.buttonAddSPAJPengajuanBack);
            this.tabPagePengajuanInfo.Controls.Add(this.label161);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanBasic);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruPPayor);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruMed);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruADD);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruCC);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruPayor);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruHosp);
            this.tabPagePengajuanInfo.Controls.Add(this.labelSPAJPengajuanPruHosp);
            this.tabPagePengajuanInfo.Controls.Add(this.buttonPengajuanAccept);
            this.tabPagePengajuanInfo.Controls.Add(this.buttonPengajuanClear);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPremiTotal);
            this.tabPagePengajuanInfo.Controls.Add(this.label38);
            this.tabPagePengajuanInfo.Controls.Add(this.label37);
            this.tabPagePengajuanInfo.Controls.Add(this.label36);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruSaver);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPremi);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPrtanggung);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanExchange);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanExpDate);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanCCBank);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruPPayorAmnt);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruMedAmnt);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruADDAmnt);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruCCAmnt);
            this.tabPagePengajuanInfo.Controls.Add(this.textBoxSPAJPengajuanPruPayorAmnt);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanPruPPayor);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanPruMed);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanADD);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanPruCC);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanPruPayor);
            this.tabPagePengajuanInfo.Controls.Add(this.checkBoxSPAJPengajuanPruHosp);
            this.tabPagePengajuanInfo.Controls.Add(this.comboBoxSPAJPengajuanCurrency);
            this.tabPagePengajuanInfo.Controls.Add(this.comboBoxSPAJPengajuanPay);
            this.tabPagePengajuanInfo.Controls.Add(this.comboBoxSPAJPengajuanFreq);
            this.tabPagePengajuanInfo.Controls.Add(this.label31);
            this.tabPagePengajuanInfo.Controls.Add(this.labelSPAJPengajuanExchRate);
            this.tabPagePengajuanInfo.Controls.Add(this.labelPengajuanCCExpDate);
            this.tabPagePengajuanInfo.Controls.Add(this.label35);
            this.tabPagePengajuanInfo.Controls.Add(this.label34);
            this.tabPagePengajuanInfo.Controls.Add(this.label33);
            this.tabPagePengajuanInfo.Controls.Add(this.label32);
            this.tabPagePengajuanInfo.Controls.Add(this.labelPengajuanCCBankOther);
            this.tabPagePengajuanInfo.Controls.Add(this.label30);
            this.tabPagePengajuanInfo.Controls.Add(this.label29);
            this.tabPagePengajuanInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPagePengajuanInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPagePengajuanInfo.Name = "tabPagePengajuanInfo";
            this.tabPagePengajuanInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPagePengajuanInfo.TabIndex = 7;
            this.tabPagePengajuanInfo.Text = "Pengajuan";
            this.tabPagePengajuanInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJPengajuanBack
            // 
            this.buttonAddSPAJPengajuanBack.Location = new System.Drawing.Point(106, 540);
            this.buttonAddSPAJPengajuanBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJPengajuanBack.Name = "buttonAddSPAJPengajuanBack";
            this.buttonAddSPAJPengajuanBack.Size = new System.Drawing.Size(132, 48);
            this.buttonAddSPAJPengajuanBack.TabIndex = 53;
            this.buttonAddSPAJPengajuanBack.Text = "Back";
            this.buttonAddSPAJPengajuanBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJPengajuanBack.Click += new System.EventHandler(this.buttonAddSPAJPengajuanBack_Click);
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(800, 29);
            this.label161.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(135, 25);
            this.label161.TabIndex = 52;
            this.label161.Text = "diisi per thn. ";
            // 
            // textBoxSPAJPengajuanBasic
            // 
            this.textBoxSPAJPengajuanBasic.Location = new System.Drawing.Point(68, 427);
            this.textBoxSPAJPengajuanBasic.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanBasic.Name = "textBoxSPAJPengajuanBasic";
            this.textBoxSPAJPengajuanBasic.Size = new System.Drawing.Size(198, 31);
            this.textBoxSPAJPengajuanBasic.TabIndex = 51;
            this.textBoxSPAJPengajuanBasic.Text = "isi nama produk";
            // 
            // textBoxSPAJPengajuanPruPPayor
            // 
            this.textBoxSPAJPengajuanPruPPayor.Enabled = false;
            this.textBoxSPAJPengajuanPruPPayor.Location = new System.Drawing.Point(584, 348);
            this.textBoxSPAJPengajuanPruPPayor.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruPPayor.Multiline = true;
            this.textBoxSPAJPengajuanPruPPayor.Name = "textBoxSPAJPengajuanPruPPayor";
            this.textBoxSPAJPengajuanPruPPayor.Size = new System.Drawing.Size(164, 50);
            this.textBoxSPAJPengajuanPruPPayor.TabIndex = 50;
            // 
            // textBoxSPAJPengajuanPruMed
            // 
            this.textBoxSPAJPengajuanPruMed.Enabled = false;
            this.textBoxSPAJPengajuanPruMed.Location = new System.Drawing.Point(584, 292);
            this.textBoxSPAJPengajuanPruMed.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruMed.Multiline = true;
            this.textBoxSPAJPengajuanPruMed.Name = "textBoxSPAJPengajuanPruMed";
            this.textBoxSPAJPengajuanPruMed.Size = new System.Drawing.Size(164, 50);
            this.textBoxSPAJPengajuanPruMed.TabIndex = 49;
            // 
            // textBoxSPAJPengajuanPruADD
            // 
            this.textBoxSPAJPengajuanPruADD.Enabled = false;
            this.textBoxSPAJPengajuanPruADD.Location = new System.Drawing.Point(584, 237);
            this.textBoxSPAJPengajuanPruADD.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruADD.Multiline = true;
            this.textBoxSPAJPengajuanPruADD.Name = "textBoxSPAJPengajuanPruADD";
            this.textBoxSPAJPengajuanPruADD.Size = new System.Drawing.Size(164, 50);
            this.textBoxSPAJPengajuanPruADD.TabIndex = 48;
            // 
            // textBoxSPAJPengajuanPruCC
            // 
            this.textBoxSPAJPengajuanPruCC.Enabled = false;
            this.textBoxSPAJPengajuanPruCC.Location = new System.Drawing.Point(584, 181);
            this.textBoxSPAJPengajuanPruCC.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruCC.Multiline = true;
            this.textBoxSPAJPengajuanPruCC.Name = "textBoxSPAJPengajuanPruCC";
            this.textBoxSPAJPengajuanPruCC.Size = new System.Drawing.Size(164, 50);
            this.textBoxSPAJPengajuanPruCC.TabIndex = 47;
            // 
            // textBoxSPAJPengajuanPruPayor
            // 
            this.textBoxSPAJPengajuanPruPayor.Enabled = false;
            this.textBoxSPAJPengajuanPruPayor.Location = new System.Drawing.Point(584, 121);
            this.textBoxSPAJPengajuanPruPayor.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruPayor.Multiline = true;
            this.textBoxSPAJPengajuanPruPayor.Name = "textBoxSPAJPengajuanPruPayor";
            this.textBoxSPAJPengajuanPruPayor.Size = new System.Drawing.Size(164, 50);
            this.textBoxSPAJPengajuanPruPayor.TabIndex = 46;
            // 
            // textBoxSPAJPengajuanPruHosp
            // 
            this.textBoxSPAJPengajuanPruHosp.Enabled = false;
            this.textBoxSPAJPengajuanPruHosp.Location = new System.Drawing.Point(772, 71);
            this.textBoxSPAJPengajuanPruHosp.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruHosp.Name = "textBoxSPAJPengajuanPruHosp";
            this.textBoxSPAJPengajuanPruHosp.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruHosp.TabIndex = 45;
            this.textBoxSPAJPengajuanPruHosp.Text = "0,00";
            // 
            // labelSPAJPengajuanPruHosp
            // 
            this.labelSPAJPengajuanPruHosp.AutoSize = true;
            this.labelSPAJPengajuanPruHosp.Enabled = false;
            this.labelSPAJPengajuanPruHosp.Location = new System.Drawing.Point(586, 67);
            this.labelSPAJPengajuanPruHosp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJPengajuanPruHosp.Name = "labelSPAJPengajuanPruHosp";
            this.labelSPAJPengajuanPruHosp.Size = new System.Drawing.Size(132, 50);
            this.labelSPAJPengajuanPruHosp.TabIndex = 44;
            this.labelSPAJPengajuanPruHosp.Text = "PruHospital \r\nand Surgical";
            // 
            // buttonPengajuanAccept
            // 
            this.buttonPengajuanAccept.Location = new System.Drawing.Point(400, 473);
            this.buttonPengajuanAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPengajuanAccept.Name = "buttonPengajuanAccept";
            this.buttonPengajuanAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonPengajuanAccept.TabIndex = 43;
            this.buttonPengajuanAccept.Text = "Accept";
            this.buttonPengajuanAccept.UseVisualStyleBackColor = true;
            this.buttonPengajuanAccept.Click += new System.EventHandler(this.buttonPengajuanAccept_Click);
            // 
            // buttonPengajuanClear
            // 
            this.buttonPengajuanClear.Location = new System.Drawing.Point(260, 540);
            this.buttonPengajuanClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPengajuanClear.Name = "buttonPengajuanClear";
            this.buttonPengajuanClear.Size = new System.Drawing.Size(120, 48);
            this.buttonPengajuanClear.TabIndex = 42;
            this.buttonPengajuanClear.Text = "Clear";
            this.buttonPengajuanClear.UseVisualStyleBackColor = true;
            this.buttonPengajuanClear.Click += new System.EventHandler(this.buttonPengajuanClear_Click);
            // 
            // textBoxSPAJPengajuanPremiTotal
            // 
            this.textBoxSPAJPengajuanPremiTotal.Enabled = false;
            this.textBoxSPAJPengajuanPremiTotal.Location = new System.Drawing.Point(772, 571);
            this.textBoxSPAJPengajuanPremiTotal.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPremiTotal.Name = "textBoxSPAJPengajuanPremiTotal";
            this.textBoxSPAJPengajuanPremiTotal.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPremiTotal.TabIndex = 41;
            this.textBoxSPAJPengajuanPremiTotal.Text = "0,00";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(586, 477);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(155, 50);
            this.label38.TabIndex = 40;
            this.label38.Text = "PRU Saver \r\n(per periode):\r\n";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(586, 552);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(139, 50);
            this.label37.TabIndex = 39;
            this.label37.Text = "Premi Total \r\n(per thn.):\r\n";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(586, 404);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(164, 50);
            this.label36.TabIndex = 38;
            this.label36.Text = "Premi \r\n(per Periode) :";
            // 
            // textBoxSPAJPengajuanPruSaver
            // 
            this.textBoxSPAJPengajuanPruSaver.Location = new System.Drawing.Point(772, 494);
            this.textBoxSPAJPengajuanPruSaver.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruSaver.Name = "textBoxSPAJPengajuanPruSaver";
            this.textBoxSPAJPengajuanPruSaver.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruSaver.TabIndex = 37;
            this.textBoxSPAJPengajuanPruSaver.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPremi
            // 
            this.textBoxSPAJPengajuanPremi.Enabled = false;
            this.textBoxSPAJPengajuanPremi.Location = new System.Drawing.Point(772, 423);
            this.textBoxSPAJPengajuanPremi.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPremi.Name = "textBoxSPAJPengajuanPremi";
            this.textBoxSPAJPengajuanPremi.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPremi.TabIndex = 36;
            this.textBoxSPAJPengajuanPremi.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPrtanggung
            // 
            this.textBoxSPAJPengajuanPrtanggung.Location = new System.Drawing.Point(310, 427);
            this.textBoxSPAJPengajuanPrtanggung.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPrtanggung.Name = "textBoxSPAJPengajuanPrtanggung";
            this.textBoxSPAJPengajuanPrtanggung.Size = new System.Drawing.Size(208, 31);
            this.textBoxSPAJPengajuanPrtanggung.TabIndex = 35;
            this.textBoxSPAJPengajuanPrtanggung.Text = "0,00";
            this.textBoxSPAJPengajuanPrtanggung.TextChanged += new System.EventHandler(this.textBoxSPAJPengajuanPrtanggung_TextChanged);
            // 
            // textBoxSPAJPengajuanExchange
            // 
            this.textBoxSPAJPengajuanExchange.Enabled = false;
            this.textBoxSPAJPengajuanExchange.Location = new System.Drawing.Point(308, 337);
            this.textBoxSPAJPengajuanExchange.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanExchange.Name = "textBoxSPAJPengajuanExchange";
            this.textBoxSPAJPengajuanExchange.Size = new System.Drawing.Size(212, 31);
            this.textBoxSPAJPengajuanExchange.TabIndex = 34;
            this.textBoxSPAJPengajuanExchange.Text = "0.00";
            // 
            // textBoxSPAJPengajuanExpDate
            // 
            this.textBoxSPAJPengajuanExpDate.Enabled = false;
            this.textBoxSPAJPengajuanExpDate.Location = new System.Drawing.Point(275, 227);
            this.textBoxSPAJPengajuanExpDate.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanExpDate.Name = "textBoxSPAJPengajuanExpDate";
            this.textBoxSPAJPengajuanExpDate.Size = new System.Drawing.Size(243, 31);
            this.textBoxSPAJPengajuanExpDate.TabIndex = 33;
            this.textBoxSPAJPengajuanExpDate.Text = "MM/YY";
            // 
            // textBoxSPAJPengajuanCCBank
            // 
            this.textBoxSPAJPengajuanCCBank.Enabled = false;
            this.textBoxSPAJPengajuanCCBank.Location = new System.Drawing.Point(275, 188);
            this.textBoxSPAJPengajuanCCBank.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanCCBank.Name = "textBoxSPAJPengajuanCCBank";
            this.textBoxSPAJPengajuanCCBank.Size = new System.Drawing.Size(241, 31);
            this.textBoxSPAJPengajuanCCBank.TabIndex = 32;
            this.textBoxSPAJPengajuanCCBank.Text = "1234-5678-9101-1121";
            // 
            // textBoxSPAJPengajuanPruPPayorAmnt
            // 
            this.textBoxSPAJPengajuanPruPPayorAmnt.Enabled = false;
            this.textBoxSPAJPengajuanPruPPayorAmnt.Location = new System.Drawing.Point(772, 348);
            this.textBoxSPAJPengajuanPruPPayorAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruPPayorAmnt.Name = "textBoxSPAJPengajuanPruPPayorAmnt";
            this.textBoxSPAJPengajuanPruPPayorAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruPPayorAmnt.TabIndex = 31;
            this.textBoxSPAJPengajuanPruPPayorAmnt.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPruMedAmnt
            // 
            this.textBoxSPAJPengajuanPruMedAmnt.Enabled = false;
            this.textBoxSPAJPengajuanPruMedAmnt.Location = new System.Drawing.Point(772, 292);
            this.textBoxSPAJPengajuanPruMedAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruMedAmnt.Name = "textBoxSPAJPengajuanPruMedAmnt";
            this.textBoxSPAJPengajuanPruMedAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruMedAmnt.TabIndex = 30;
            this.textBoxSPAJPengajuanPruMedAmnt.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPruADDAmnt
            // 
            this.textBoxSPAJPengajuanPruADDAmnt.Enabled = false;
            this.textBoxSPAJPengajuanPruADDAmnt.Location = new System.Drawing.Point(772, 240);
            this.textBoxSPAJPengajuanPruADDAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruADDAmnt.Name = "textBoxSPAJPengajuanPruADDAmnt";
            this.textBoxSPAJPengajuanPruADDAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruADDAmnt.TabIndex = 29;
            this.textBoxSPAJPengajuanPruADDAmnt.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPruCCAmnt
            // 
            this.textBoxSPAJPengajuanPruCCAmnt.Enabled = false;
            this.textBoxSPAJPengajuanPruCCAmnt.Location = new System.Drawing.Point(772, 181);
            this.textBoxSPAJPengajuanPruCCAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruCCAmnt.Name = "textBoxSPAJPengajuanPruCCAmnt";
            this.textBoxSPAJPengajuanPruCCAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruCCAmnt.TabIndex = 28;
            this.textBoxSPAJPengajuanPruCCAmnt.Text = "0,00";
            // 
            // textBoxSPAJPengajuanPruPayorAmnt
            // 
            this.textBoxSPAJPengajuanPruPayorAmnt.Enabled = false;
            this.textBoxSPAJPengajuanPruPayorAmnt.Location = new System.Drawing.Point(772, 127);
            this.textBoxSPAJPengajuanPruPayorAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJPengajuanPruPayorAmnt.Name = "textBoxSPAJPengajuanPruPayorAmnt";
            this.textBoxSPAJPengajuanPruPayorAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJPengajuanPruPayorAmnt.TabIndex = 27;
            this.textBoxSPAJPengajuanPruPayorAmnt.Text = "0,00";
            // 
            // checkBoxSPAJPengajuanPruPPayor
            // 
            this.checkBoxSPAJPengajuanPruPPayor.AutoSize = true;
            this.checkBoxSPAJPengajuanPruPPayor.Location = new System.Drawing.Point(550, 340);
            this.checkBoxSPAJPengajuanPruPPayor.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanPruPPayor.Name = "checkBoxSPAJPengajuanPruPPayor";
            this.checkBoxSPAJPengajuanPruPPayor.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanPruPPayor.TabIndex = 22;
            this.checkBoxSPAJPengajuanPruPPayor.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanPruPPayor.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanPruPPayor_CheckedChanged);
            // 
            // checkBoxSPAJPengajuanPruMed
            // 
            this.checkBoxSPAJPengajuanPruMed.AutoSize = true;
            this.checkBoxSPAJPengajuanPruMed.Location = new System.Drawing.Point(550, 287);
            this.checkBoxSPAJPengajuanPruMed.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanPruMed.Name = "checkBoxSPAJPengajuanPruMed";
            this.checkBoxSPAJPengajuanPruMed.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanPruMed.TabIndex = 21;
            this.checkBoxSPAJPengajuanPruMed.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanPruMed.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanPruMed_CheckedChanged);
            // 
            // checkBoxSPAJPengajuanADD
            // 
            this.checkBoxSPAJPengajuanADD.AutoSize = true;
            this.checkBoxSPAJPengajuanADD.Location = new System.Drawing.Point(550, 240);
            this.checkBoxSPAJPengajuanADD.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanADD.Name = "checkBoxSPAJPengajuanADD";
            this.checkBoxSPAJPengajuanADD.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanADD.TabIndex = 20;
            this.checkBoxSPAJPengajuanADD.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanADD.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanADD_CheckedChanged);
            // 
            // checkBoxSPAJPengajuanPruCC
            // 
            this.checkBoxSPAJPengajuanPruCC.AutoSize = true;
            this.checkBoxSPAJPengajuanPruCC.Location = new System.Drawing.Point(550, 188);
            this.checkBoxSPAJPengajuanPruCC.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanPruCC.Name = "checkBoxSPAJPengajuanPruCC";
            this.checkBoxSPAJPengajuanPruCC.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanPruCC.TabIndex = 19;
            this.checkBoxSPAJPengajuanPruCC.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanPruCC.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanPruCC_CheckedChanged);
            // 
            // checkBoxSPAJPengajuanPruPayor
            // 
            this.checkBoxSPAJPengajuanPruPayor.AutoSize = true;
            this.checkBoxSPAJPengajuanPruPayor.Location = new System.Drawing.Point(550, 133);
            this.checkBoxSPAJPengajuanPruPayor.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanPruPayor.Name = "checkBoxSPAJPengajuanPruPayor";
            this.checkBoxSPAJPengajuanPruPayor.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanPruPayor.TabIndex = 17;
            this.checkBoxSPAJPengajuanPruPayor.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanPruPayor.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanPruPayor_CheckedChanged);
            // 
            // checkBoxSPAJPengajuanPruHosp
            // 
            this.checkBoxSPAJPengajuanPruHosp.AutoSize = true;
            this.checkBoxSPAJPengajuanPruHosp.Location = new System.Drawing.Point(550, 71);
            this.checkBoxSPAJPengajuanPruHosp.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJPengajuanPruHosp.Name = "checkBoxSPAJPengajuanPruHosp";
            this.checkBoxSPAJPengajuanPruHosp.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJPengajuanPruHosp.TabIndex = 16;
            this.checkBoxSPAJPengajuanPruHosp.UseVisualStyleBackColor = true;
            this.checkBoxSPAJPengajuanPruHosp.CheckedChanged += new System.EventHandler(this.checkBoxSPAJPengajuanPruHosp_CheckedChanged);
            // 
            // comboBoxSPAJPengajuanCurrency
            // 
            this.comboBoxSPAJPengajuanCurrency.FormattingEnabled = true;
            this.comboBoxSPAJPengajuanCurrency.Items.AddRange(new object[] {
            "Rupiah",
            "USD"});
            this.comboBoxSPAJPengajuanCurrency.Location = new System.Drawing.Point(310, 287);
            this.comboBoxSPAJPengajuanCurrency.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJPengajuanCurrency.Name = "comboBoxSPAJPengajuanCurrency";
            this.comboBoxSPAJPengajuanCurrency.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJPengajuanCurrency.TabIndex = 12;
            this.comboBoxSPAJPengajuanCurrency.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJPengajuanCurrency_SelectedIndexChanged);
            // 
            // comboBoxSPAJPengajuanPay
            // 
            this.comboBoxSPAJPengajuanPay.FormattingEnabled = true;
            this.comboBoxSPAJPengajuanPay.Items.AddRange(new object[] {
            "Credit Card",
            "Bank Transfer",
            "Other"});
            this.comboBoxSPAJPengajuanPay.Location = new System.Drawing.Point(308, 144);
            this.comboBoxSPAJPengajuanPay.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJPengajuanPay.Name = "comboBoxSPAJPengajuanPay";
            this.comboBoxSPAJPengajuanPay.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJPengajuanPay.TabIndex = 11;
            this.comboBoxSPAJPengajuanPay.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJPengajuanPay_SelectedIndexChanged);
            // 
            // comboBoxSPAJPengajuanFreq
            // 
            this.comboBoxSPAJPengajuanFreq.FormattingEnabled = true;
            this.comboBoxSPAJPengajuanFreq.Items.AddRange(new object[] {
            "Yearly (Tahunan)",
            "Half Yearly (Semesteran)",
            "Quarterly (3 Bulan)",
            "Monthly (Bulanan)",
            "Berkala",
            "Tunggal"});
            this.comboBoxSPAJPengajuanFreq.Location = new System.Drawing.Point(308, 102);
            this.comboBoxSPAJPengajuanFreq.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJPengajuanFreq.Name = "comboBoxSPAJPengajuanFreq";
            this.comboBoxSPAJPengajuanFreq.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJPengajuanFreq.TabIndex = 10;
            this.comboBoxSPAJPengajuanFreq.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJPengajuanFreq_SelectedIndexChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(162, 385);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(309, 25);
            this.label31.TabIndex = 9;
            this.label31.Text = "Uang Pertanggungan (per thn.)";
            // 
            // labelSPAJPengajuanExchRate
            // 
            this.labelSPAJPengajuanExchRate.AutoSize = true;
            this.labelSPAJPengajuanExchRate.Enabled = false;
            this.labelSPAJPengajuanExchRate.Location = new System.Drawing.Point(100, 342);
            this.labelSPAJPengajuanExchRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJPengajuanExchRate.Name = "labelSPAJPengajuanExchRate";
            this.labelSPAJPengajuanExchRate.Size = new System.Drawing.Size(165, 25);
            this.labelSPAJPengajuanExchRate.TabIndex = 8;
            this.labelSPAJPengajuanExchRate.Text = "Exchange Rate:";
            // 
            // labelPengajuanCCExpDate
            // 
            this.labelPengajuanCCExpDate.AutoSize = true;
            this.labelPengajuanCCExpDate.Enabled = false;
            this.labelPengajuanCCExpDate.Location = new System.Drawing.Point(36, 230);
            this.labelPengajuanCCExpDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPengajuanCCExpDate.Name = "labelPengajuanCCExpDate";
            this.labelPengajuanCCExpDate.Size = new System.Drawing.Size(112, 25);
            this.labelPengajuanCCExpDate.TabIndex = 7;
            this.labelPengajuanCCExpDate.Text = "Exp. Date:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(544, 38);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(153, 25);
            this.label35.TabIndex = 6;
            this.label35.Text = "E. Additional ";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(36, 385);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 25);
            this.label34.TabIndex = 5;
            this.label34.Text = "D. Basic";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(36, 288);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(137, 25);
            this.label33.TabIndex = 4;
            this.label33.Text = "C. Currency";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(36, 144);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(217, 25);
            this.label32.TabIndex = 3;
            this.label32.Text = "B. Payment Method";
            // 
            // labelPengajuanCCBankOther
            // 
            this.labelPengajuanCCBankOther.AutoSize = true;
            this.labelPengajuanCCBankOther.Enabled = false;
            this.labelPengajuanCCBankOther.Location = new System.Drawing.Point(36, 187);
            this.labelPengajuanCCBankOther.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPengajuanCCBankOther.Name = "labelPengajuanCCBankOther";
            this.labelPengajuanCCBankOther.Size = new System.Drawing.Size(177, 25);
            this.labelPengajuanCCBankOther.TabIndex = 2;
            this.labelPengajuanCCBankOther.Text = "Credit Card Num:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(36, 102);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(250, 25);
            this.label30.TabIndex = 1;
            this.label30.Text = "A. Payment Frequency";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label29.Location = new System.Drawing.Point(160, 38);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(256, 37);
            this.label29.TabIndex = 0;
            this.label29.Text = "Pengajuan Info ";
            // 
            // tabPageBeneficiaryInfo
            // 
            this.tabPageBeneficiaryInfo.Controls.Add(this.buttonAddSPAJBeneficiaryBack);
            this.tabPageBeneficiaryInfo.Controls.Add(this.buttonBeneficiaryAccept);
            this.tabPageBeneficiaryInfo.Controls.Add(this.buttonSPAJBeneficiaryClear);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.comboBoxSPAJBeneficiaryRs1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.dateTimeSPAJBeneficiary1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary6);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary5);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary4);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary3);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryDetail2);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryLName1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.textBoxSPAJBeneficiaryFName1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.checkBoxSPAJBeneficiary1);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label44);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label43);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label42);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label41);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label40);
            this.tabPageBeneficiaryInfo.Controls.Add(this.label39);
            this.tabPageBeneficiaryInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageBeneficiaryInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageBeneficiaryInfo.Name = "tabPageBeneficiaryInfo";
            this.tabPageBeneficiaryInfo.Size = new System.Drawing.Size(1036, 630);
            this.tabPageBeneficiaryInfo.TabIndex = 8;
            this.tabPageBeneficiaryInfo.Text = "Beneficiary";
            this.tabPageBeneficiaryInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddSPAJBeneficiaryBack
            // 
            this.buttonAddSPAJBeneficiaryBack.Location = new System.Drawing.Point(270, 552);
            this.buttonAddSPAJBeneficiaryBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttonAddSPAJBeneficiaryBack.Name = "buttonAddSPAJBeneficiaryBack";
            this.buttonAddSPAJBeneficiaryBack.Size = new System.Drawing.Size(136, 48);
            this.buttonAddSPAJBeneficiaryBack.TabIndex = 46;
            this.buttonAddSPAJBeneficiaryBack.Text = "Back";
            this.buttonAddSPAJBeneficiaryBack.UseVisualStyleBackColor = true;
            this.buttonAddSPAJBeneficiaryBack.Click += new System.EventHandler(this.buttonAddSPAJBeneficiaryBack_Click);
            // 
            // buttonBeneficiaryAccept
            // 
            this.buttonBeneficiaryAccept.Location = new System.Drawing.Point(682, 552);
            this.buttonBeneficiaryAccept.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBeneficiaryAccept.Name = "buttonBeneficiaryAccept";
            this.buttonBeneficiaryAccept.Size = new System.Drawing.Size(120, 48);
            this.buttonBeneficiaryAccept.TabIndex = 45;
            this.buttonBeneficiaryAccept.Text = "Accept";
            this.buttonBeneficiaryAccept.UseVisualStyleBackColor = true;
            this.buttonBeneficiaryAccept.Click += new System.EventHandler(this.buttonBeneficiaryAccept_Click);
            // 
            // buttonSPAJBeneficiaryClear
            // 
            this.buttonSPAJBeneficiaryClear.Location = new System.Drawing.Point(490, 552);
            this.buttonSPAJBeneficiaryClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJBeneficiaryClear.Name = "buttonSPAJBeneficiaryClear";
            this.buttonSPAJBeneficiaryClear.Size = new System.Drawing.Size(120, 48);
            this.buttonSPAJBeneficiaryClear.TabIndex = 44;
            this.buttonSPAJBeneficiaryClear.Text = "Clear";
            this.buttonSPAJBeneficiaryClear.UseVisualStyleBackColor = true;
            this.buttonSPAJBeneficiaryClear.Click += new System.EventHandler(this.buttonBeneficiaryClear_Click);
            // 
            // comboBoxSPAJBeneficiaryRs6
            // 
            this.comboBoxSPAJBeneficiaryRs6.Enabled = false;
            this.comboBoxSPAJBeneficiaryRs6.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs6.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs6.Location = new System.Drawing.Point(676, 477);
            this.comboBoxSPAJBeneficiaryRs6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs6.Name = "comboBoxSPAJBeneficiaryRs6";
            this.comboBoxSPAJBeneficiaryRs6.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs6.TabIndex = 43;
            this.comboBoxSPAJBeneficiaryRs6.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs6_SelectedIndexChanged);
            // 
            // comboBoxSPAJBeneficiaryRs5
            // 
            this.comboBoxSPAJBeneficiaryRs5.Enabled = false;
            this.comboBoxSPAJBeneficiaryRs5.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs5.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs5.Location = new System.Drawing.Point(676, 404);
            this.comboBoxSPAJBeneficiaryRs5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs5.Name = "comboBoxSPAJBeneficiaryRs5";
            this.comboBoxSPAJBeneficiaryRs5.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs5.TabIndex = 42;
            this.comboBoxSPAJBeneficiaryRs5.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs5_SelectedIndexChanged);
            // 
            // comboBoxSPAJBeneficiaryRs4
            // 
            this.comboBoxSPAJBeneficiaryRs4.Enabled = false;
            this.comboBoxSPAJBeneficiaryRs4.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs4.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs4.Location = new System.Drawing.Point(676, 340);
            this.comboBoxSPAJBeneficiaryRs4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs4.Name = "comboBoxSPAJBeneficiaryRs4";
            this.comboBoxSPAJBeneficiaryRs4.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs4.TabIndex = 41;
            this.comboBoxSPAJBeneficiaryRs4.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs4_SelectedIndexChanged);
            // 
            // comboBoxSPAJBeneficiaryRs3
            // 
            this.comboBoxSPAJBeneficiaryRs3.Enabled = false;
            this.comboBoxSPAJBeneficiaryRs3.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs3.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs3.Location = new System.Drawing.Point(676, 277);
            this.comboBoxSPAJBeneficiaryRs3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs3.Name = "comboBoxSPAJBeneficiaryRs3";
            this.comboBoxSPAJBeneficiaryRs3.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs3.TabIndex = 40;
            this.comboBoxSPAJBeneficiaryRs3.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs3_SelectedIndexChanged);
            // 
            // comboBoxSPAJBeneficiaryRs2
            // 
            this.comboBoxSPAJBeneficiaryRs2.Enabled = false;
            this.comboBoxSPAJBeneficiaryRs2.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs2.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs2.Location = new System.Drawing.Point(676, 204);
            this.comboBoxSPAJBeneficiaryRs2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs2.Name = "comboBoxSPAJBeneficiaryRs2";
            this.comboBoxSPAJBeneficiaryRs2.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs2.TabIndex = 39;
            this.comboBoxSPAJBeneficiaryRs2.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs2_SelectedIndexChanged);
            // 
            // comboBoxSPAJBeneficiaryRs1
            // 
            this.comboBoxSPAJBeneficiaryRs1.FormattingEnabled = true;
            this.comboBoxSPAJBeneficiaryRs1.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJBeneficiaryRs1.Location = new System.Drawing.Point(676, 133);
            this.comboBoxSPAJBeneficiaryRs1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJBeneficiaryRs1.Name = "comboBoxSPAJBeneficiaryRs1";
            this.comboBoxSPAJBeneficiaryRs1.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJBeneficiaryRs1.TabIndex = 38;
            this.comboBoxSPAJBeneficiaryRs1.SelectedValueChanged += new System.EventHandler(this.comboBoxSPAJBeneficiaryRs1_SelectedValueChanged);
            // 
            // dateTimeSPAJBeneficiary6
            // 
            this.dateTimeSPAJBeneficiary6.Enabled = false;
            this.dateTimeSPAJBeneficiary6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary6.Location = new System.Drawing.Point(468, 473);
            this.dateTimeSPAJBeneficiary6.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary6.Name = "dateTimeSPAJBeneficiary6";
            this.dateTimeSPAJBeneficiary6.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary6.TabIndex = 37;
            // 
            // dateTimeSPAJBeneficiary5
            // 
            this.dateTimeSPAJBeneficiary5.Enabled = false;
            this.dateTimeSPAJBeneficiary5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary5.Location = new System.Drawing.Point(468, 406);
            this.dateTimeSPAJBeneficiary5.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary5.Name = "dateTimeSPAJBeneficiary5";
            this.dateTimeSPAJBeneficiary5.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary5.TabIndex = 36;
            // 
            // dateTimeSPAJBeneficiary4
            // 
            this.dateTimeSPAJBeneficiary4.Enabled = false;
            this.dateTimeSPAJBeneficiary4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary4.Location = new System.Drawing.Point(468, 340);
            this.dateTimeSPAJBeneficiary4.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary4.Name = "dateTimeSPAJBeneficiary4";
            this.dateTimeSPAJBeneficiary4.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary4.TabIndex = 35;
            // 
            // dateTimeSPAJBeneficiary3
            // 
            this.dateTimeSPAJBeneficiary3.Enabled = false;
            this.dateTimeSPAJBeneficiary3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary3.Location = new System.Drawing.Point(468, 279);
            this.dateTimeSPAJBeneficiary3.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary3.Name = "dateTimeSPAJBeneficiary3";
            this.dateTimeSPAJBeneficiary3.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary3.TabIndex = 34;
            // 
            // dateTimeSPAJBeneficiary2
            // 
            this.dateTimeSPAJBeneficiary2.Enabled = false;
            this.dateTimeSPAJBeneficiary2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary2.Location = new System.Drawing.Point(468, 206);
            this.dateTimeSPAJBeneficiary2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary2.Name = "dateTimeSPAJBeneficiary2";
            this.dateTimeSPAJBeneficiary2.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary2.TabIndex = 33;
            // 
            // dateTimeSPAJBeneficiary1
            // 
            this.dateTimeSPAJBeneficiary1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJBeneficiary1.Location = new System.Drawing.Point(468, 129);
            this.dateTimeSPAJBeneficiary1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJBeneficiary1.Name = "dateTimeSPAJBeneficiary1";
            this.dateTimeSPAJBeneficiary1.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJBeneficiary1.TabIndex = 32;
            // 
            // textBoxSPAJBeneficiaryDetail6
            // 
            this.textBoxSPAJBeneficiaryDetail6.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail6.Location = new System.Drawing.Point(864, 477);
            this.textBoxSPAJBeneficiaryDetail6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail6.Name = "textBoxSPAJBeneficiaryDetail6";
            this.textBoxSPAJBeneficiaryDetail6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail6.TabIndex = 31;
            // 
            // textBoxSPAJBeneficiaryDetail5
            // 
            this.textBoxSPAJBeneficiaryDetail5.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail5.Location = new System.Drawing.Point(864, 408);
            this.textBoxSPAJBeneficiaryDetail5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail5.Name = "textBoxSPAJBeneficiaryDetail5";
            this.textBoxSPAJBeneficiaryDetail5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail5.TabIndex = 30;
            // 
            // textBoxSPAJBeneficiaryDetail4
            // 
            this.textBoxSPAJBeneficiaryDetail4.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail4.Location = new System.Drawing.Point(864, 342);
            this.textBoxSPAJBeneficiaryDetail4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail4.Name = "textBoxSPAJBeneficiaryDetail4";
            this.textBoxSPAJBeneficiaryDetail4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail4.TabIndex = 29;
            // 
            // textBoxSPAJBeneficiaryDetail3
            // 
            this.textBoxSPAJBeneficiaryDetail3.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail3.Location = new System.Drawing.Point(864, 277);
            this.textBoxSPAJBeneficiaryDetail3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail3.Name = "textBoxSPAJBeneficiaryDetail3";
            this.textBoxSPAJBeneficiaryDetail3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail3.TabIndex = 28;
            // 
            // textBoxSPAJBeneficiaryLName6
            // 
            this.textBoxSPAJBeneficiaryLName6.Enabled = false;
            this.textBoxSPAJBeneficiaryLName6.Location = new System.Drawing.Point(284, 473);
            this.textBoxSPAJBeneficiaryLName6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName6.Name = "textBoxSPAJBeneficiaryLName6";
            this.textBoxSPAJBeneficiaryLName6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName6.TabIndex = 27;
            // 
            // textBoxSPAJBeneficiaryLName5
            // 
            this.textBoxSPAJBeneficiaryLName5.Enabled = false;
            this.textBoxSPAJBeneficiaryLName5.Location = new System.Drawing.Point(284, 406);
            this.textBoxSPAJBeneficiaryLName5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName5.Name = "textBoxSPAJBeneficiaryLName5";
            this.textBoxSPAJBeneficiaryLName5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName5.TabIndex = 26;
            // 
            // textBoxSPAJBeneficiaryLName4
            // 
            this.textBoxSPAJBeneficiaryLName4.Enabled = false;
            this.textBoxSPAJBeneficiaryLName4.Location = new System.Drawing.Point(284, 340);
            this.textBoxSPAJBeneficiaryLName4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName4.Name = "textBoxSPAJBeneficiaryLName4";
            this.textBoxSPAJBeneficiaryLName4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName4.TabIndex = 25;
            // 
            // textBoxSPAJBeneficiaryLName3
            // 
            this.textBoxSPAJBeneficiaryLName3.Enabled = false;
            this.textBoxSPAJBeneficiaryLName3.Location = new System.Drawing.Point(284, 279);
            this.textBoxSPAJBeneficiaryLName3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName3.Name = "textBoxSPAJBeneficiaryLName3";
            this.textBoxSPAJBeneficiaryLName3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName3.TabIndex = 24;
            // 
            // textBoxSPAJBeneficiaryLName2
            // 
            this.textBoxSPAJBeneficiaryLName2.Enabled = false;
            this.textBoxSPAJBeneficiaryLName2.Location = new System.Drawing.Point(284, 206);
            this.textBoxSPAJBeneficiaryLName2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName2.Name = "textBoxSPAJBeneficiaryLName2";
            this.textBoxSPAJBeneficiaryLName2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName2.TabIndex = 23;
            // 
            // textBoxSPAJBeneficiaryFName6
            // 
            this.textBoxSPAJBeneficiaryFName6.Enabled = false;
            this.textBoxSPAJBeneficiaryFName6.Location = new System.Drawing.Point(98, 473);
            this.textBoxSPAJBeneficiaryFName6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName6.Name = "textBoxSPAJBeneficiaryFName6";
            this.textBoxSPAJBeneficiaryFName6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName6.TabIndex = 22;
            // 
            // textBoxSPAJBeneficiaryFName5
            // 
            this.textBoxSPAJBeneficiaryFName5.Enabled = false;
            this.textBoxSPAJBeneficiaryFName5.Location = new System.Drawing.Point(98, 400);
            this.textBoxSPAJBeneficiaryFName5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName5.Name = "textBoxSPAJBeneficiaryFName5";
            this.textBoxSPAJBeneficiaryFName5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName5.TabIndex = 21;
            // 
            // textBoxSPAJBeneficiaryFName4
            // 
            this.textBoxSPAJBeneficiaryFName4.Enabled = false;
            this.textBoxSPAJBeneficiaryFName4.Location = new System.Drawing.Point(98, 340);
            this.textBoxSPAJBeneficiaryFName4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName4.Name = "textBoxSPAJBeneficiaryFName4";
            this.textBoxSPAJBeneficiaryFName4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName4.TabIndex = 20;
            // 
            // textBoxSPAJBeneficiaryFName3
            // 
            this.textBoxSPAJBeneficiaryFName3.Enabled = false;
            this.textBoxSPAJBeneficiaryFName3.Location = new System.Drawing.Point(98, 279);
            this.textBoxSPAJBeneficiaryFName3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName3.Name = "textBoxSPAJBeneficiaryFName3";
            this.textBoxSPAJBeneficiaryFName3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName3.TabIndex = 19;
            // 
            // checkBoxSPAJBeneficiary6
            // 
            this.checkBoxSPAJBeneficiary6.AutoSize = true;
            this.checkBoxSPAJBeneficiary6.Location = new System.Drawing.Point(46, 477);
            this.checkBoxSPAJBeneficiary6.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary6.Name = "checkBoxSPAJBeneficiary6";
            this.checkBoxSPAJBeneficiary6.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary6.TabIndex = 18;
            this.checkBoxSPAJBeneficiary6.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary6.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary6_CheckedChanged);
            // 
            // checkBoxSPAJBeneficiary5
            // 
            this.checkBoxSPAJBeneficiary5.AutoSize = true;
            this.checkBoxSPAJBeneficiary5.Location = new System.Drawing.Point(46, 406);
            this.checkBoxSPAJBeneficiary5.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary5.Name = "checkBoxSPAJBeneficiary5";
            this.checkBoxSPAJBeneficiary5.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary5.TabIndex = 17;
            this.checkBoxSPAJBeneficiary5.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary5.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary5_CheckedChanged);
            // 
            // checkBoxSPAJBeneficiary4
            // 
            this.checkBoxSPAJBeneficiary4.AutoSize = true;
            this.checkBoxSPAJBeneficiary4.Location = new System.Drawing.Point(46, 340);
            this.checkBoxSPAJBeneficiary4.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary4.Name = "checkBoxSPAJBeneficiary4";
            this.checkBoxSPAJBeneficiary4.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary4.TabIndex = 16;
            this.checkBoxSPAJBeneficiary4.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary4.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary4_CheckedChanged);
            // 
            // checkBoxSPAJBeneficiary3
            // 
            this.checkBoxSPAJBeneficiary3.AutoSize = true;
            this.checkBoxSPAJBeneficiary3.Location = new System.Drawing.Point(46, 279);
            this.checkBoxSPAJBeneficiary3.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary3.Name = "checkBoxSPAJBeneficiary3";
            this.checkBoxSPAJBeneficiary3.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary3.TabIndex = 15;
            this.checkBoxSPAJBeneficiary3.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary3.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary3_CheckedChanged);
            // 
            // checkBoxSPAJBeneficiary2
            // 
            this.checkBoxSPAJBeneficiary2.AutoSize = true;
            this.checkBoxSPAJBeneficiary2.Location = new System.Drawing.Point(46, 204);
            this.checkBoxSPAJBeneficiary2.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary2.Name = "checkBoxSPAJBeneficiary2";
            this.checkBoxSPAJBeneficiary2.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary2.TabIndex = 14;
            this.checkBoxSPAJBeneficiary2.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary2.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary2_CheckedChanged);
            // 
            // textBoxSPAJBeneficiaryDetail1
            // 
            this.textBoxSPAJBeneficiaryDetail1.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail1.Location = new System.Drawing.Point(864, 129);
            this.textBoxSPAJBeneficiaryDetail1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail1.Name = "textBoxSPAJBeneficiaryDetail1";
            this.textBoxSPAJBeneficiaryDetail1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail1.TabIndex = 13;
            // 
            // textBoxSPAJBeneficiaryFName2
            // 
            this.textBoxSPAJBeneficiaryFName2.Enabled = false;
            this.textBoxSPAJBeneficiaryFName2.Location = new System.Drawing.Point(98, 204);
            this.textBoxSPAJBeneficiaryFName2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName2.Name = "textBoxSPAJBeneficiaryFName2";
            this.textBoxSPAJBeneficiaryFName2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName2.TabIndex = 12;
            // 
            // textBoxSPAJBeneficiaryDetail2
            // 
            this.textBoxSPAJBeneficiaryDetail2.Enabled = false;
            this.textBoxSPAJBeneficiaryDetail2.Location = new System.Drawing.Point(864, 206);
            this.textBoxSPAJBeneficiaryDetail2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryDetail2.Name = "textBoxSPAJBeneficiaryDetail2";
            this.textBoxSPAJBeneficiaryDetail2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryDetail2.TabIndex = 11;
            // 
            // textBoxSPAJBeneficiaryLName1
            // 
            this.textBoxSPAJBeneficiaryLName1.Location = new System.Drawing.Point(284, 129);
            this.textBoxSPAJBeneficiaryLName1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryLName1.Name = "textBoxSPAJBeneficiaryLName1";
            this.textBoxSPAJBeneficiaryLName1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryLName1.TabIndex = 10;
            // 
            // textBoxSPAJBeneficiaryFName1
            // 
            this.textBoxSPAJBeneficiaryFName1.Location = new System.Drawing.Point(98, 129);
            this.textBoxSPAJBeneficiaryFName1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJBeneficiaryFName1.Name = "textBoxSPAJBeneficiaryFName1";
            this.textBoxSPAJBeneficiaryFName1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJBeneficiaryFName1.TabIndex = 9;
            // 
            // checkBoxSPAJBeneficiary1
            // 
            this.checkBoxSPAJBeneficiary1.AutoSize = true;
            this.checkBoxSPAJBeneficiary1.Checked = true;
            this.checkBoxSPAJBeneficiary1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxSPAJBeneficiary1.Location = new System.Drawing.Point(46, 133);
            this.checkBoxSPAJBeneficiary1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJBeneficiary1.Name = "checkBoxSPAJBeneficiary1";
            this.checkBoxSPAJBeneficiary1.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJBeneficiary1.TabIndex = 8;
            this.checkBoxSPAJBeneficiary1.UseVisualStyleBackColor = true;
            this.checkBoxSPAJBeneficiary1.CheckedChanged += new System.EventHandler(this.checkBoxSPAJBeneficiary1_CheckedChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(888, 77);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(78, 25);
            this.label44.TabIndex = 7;
            this.label44.Text = "Details";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(672, 77);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(131, 25);
            this.label43.TabIndex = 6;
            this.label43.Text = "Relationship";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(490, 77);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(98, 25);
            this.label42.TabIndex = 5;
            this.label42.Text = "Birthdate";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(290, 77);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(115, 25);
            this.label41.TabIndex = 4;
            this.label41.Text = "Last Name";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(104, 77);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(116, 25);
            this.label40.TabIndex = 3;
            this.label40.Text = "First Name";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label39.Location = new System.Drawing.Point(404, 19);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(184, 37);
            this.label39.TabIndex = 2;
            this.label39.Text = "Beneficiary";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(32, 375);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(116, 50);
            this.label78.TabIndex = 6;
            this.label78.Text = "PRU Flyer \r\nNumber:";
            // 
            // textBoxSPAJANum
            // 
            this.textBoxSPAJANum.Location = new System.Drawing.Point(204, 313);
            this.textBoxSPAJANum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJANum.Name = "textBoxSPAJANum";
            this.textBoxSPAJANum.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJANum.TabIndex = 10;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(32, 112);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(158, 25);
            this.label77.TabIndex = 3;
            this.label77.Text = "SPAJ Number: ";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label98.Location = new System.Drawing.Point(88, 33);
            this.label98.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(249, 37);
            this.label98.TabIndex = 1;
            this.label98.Text = "Add New SPAJ";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(32, 315);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(155, 25);
            this.label80.TabIndex = 5;
            this.label80.Text = "Agent Number:";
            // 
            // textBoxSPAJAName
            // 
            this.textBoxSPAJAName.Location = new System.Drawing.Point(204, 238);
            this.textBoxSPAJAName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJAName.Name = "textBoxSPAJAName";
            this.textBoxSPAJAName.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJAName.TabIndex = 9;
            // 
            // textBoxSPAJNum
            // 
            this.textBoxSPAJNum.Location = new System.Drawing.Point(204, 112);
            this.textBoxSPAJNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJNum.Name = "textBoxSPAJNum";
            this.textBoxSPAJNum.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJNum.TabIndex = 8;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(32, 244);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(136, 25);
            this.label79.TabIndex = 4;
            this.label79.Text = "Agent Name:";
            // 
            // tabPageSPAJEdit
            // 
            this.tabPageSPAJEdit.Controls.Add(this.textBoxSPAJEditType);
            this.tabPageSPAJEdit.Controls.Add(this.buttonSPAJEditLoad);
            this.tabPageSPAJEdit.Controls.Add(this.buttonSPAJEditUpdate);
            this.tabPageSPAJEdit.Controls.Add(this.buttonSPAJEditClear);
            this.tabPageSPAJEdit.Controls.Add(this.dateTimeSPAJEditSubmit);
            this.tabPageSPAJEdit.Controls.Add(this.label45);
            this.tabPageSPAJEdit.Controls.Add(this.label46);
            this.tabPageSPAJEdit.Controls.Add(this.textBoxEditPruFlyerNum);
            this.tabPageSPAJEdit.Controls.Add(this.tabControlEditSPAJ);
            this.tabPageSPAJEdit.Controls.Add(this.label135);
            this.tabPageSPAJEdit.Controls.Add(this.textBoxSPAJEditANumber);
            this.tabPageSPAJEdit.Controls.Add(this.label136);
            this.tabPageSPAJEdit.Controls.Add(this.label137);
            this.tabPageSPAJEdit.Controls.Add(this.label138);
            this.tabPageSPAJEdit.Controls.Add(this.textBoxSPAJEditAName);
            this.tabPageSPAJEdit.Controls.Add(this.textBoxSPAJEditNumber);
            this.tabPageSPAJEdit.Controls.Add(this.label139);
            this.tabPageSPAJEdit.Location = new System.Drawing.Point(8, 39);
            this.tabPageSPAJEdit.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJEdit.Name = "tabPageSPAJEdit";
            this.tabPageSPAJEdit.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJEdit.Size = new System.Drawing.Size(1488, 678);
            this.tabPageSPAJEdit.TabIndex = 3;
            this.tabPageSPAJEdit.Text = "Edit SPAJ";
            this.tabPageSPAJEdit.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJEditType
            // 
            this.textBoxSPAJEditType.Location = new System.Drawing.Point(204, 177);
            this.textBoxSPAJEditType.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditType.Name = "textBoxSPAJEditType";
            this.textBoxSPAJEditType.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJEditType.TabIndex = 19;
            // 
            // buttonSPAJEditLoad
            // 
            this.buttonSPAJEditLoad.Location = new System.Drawing.Point(356, 102);
            this.buttonSPAJEditLoad.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJEditLoad.Name = "buttonSPAJEditLoad";
            this.buttonSPAJEditLoad.Size = new System.Drawing.Size(108, 38);
            this.buttonSPAJEditLoad.TabIndex = 18;
            this.buttonSPAJEditLoad.Text = "Load";
            this.buttonSPAJEditLoad.UseVisualStyleBackColor = true;
            this.buttonSPAJEditLoad.Click += new System.EventHandler(this.buttonSPAJEditLoad_Click);
            // 
            // buttonSPAJEditUpdate
            // 
            this.buttonSPAJEditUpdate.Enabled = false;
            this.buttonSPAJEditUpdate.Location = new System.Drawing.Point(272, 515);
            this.buttonSPAJEditUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJEditUpdate.Name = "buttonSPAJEditUpdate";
            this.buttonSPAJEditUpdate.Size = new System.Drawing.Size(108, 38);
            this.buttonSPAJEditUpdate.TabIndex = 16;
            this.buttonSPAJEditUpdate.Text = "Update";
            this.buttonSPAJEditUpdate.UseVisualStyleBackColor = true;
            this.buttonSPAJEditUpdate.Click += new System.EventHandler(this.buttonSPAJEditUpdate_Click);
            // 
            // buttonSPAJEditClear
            // 
            this.buttonSPAJEditClear.Enabled = false;
            this.buttonSPAJEditClear.Location = new System.Drawing.Point(42, 515);
            this.buttonSPAJEditClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJEditClear.Name = "buttonSPAJEditClear";
            this.buttonSPAJEditClear.Size = new System.Drawing.Size(108, 38);
            this.buttonSPAJEditClear.TabIndex = 15;
            this.buttonSPAJEditClear.Text = "Clear All";
            this.buttonSPAJEditClear.UseVisualStyleBackColor = true;
            // 
            // dateTimeSPAJEditSubmit
            // 
            this.dateTimeSPAJEditSubmit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditSubmit.Location = new System.Drawing.Point(204, 438);
            this.dateTimeSPAJEditSubmit.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditSubmit.Name = "dateTimeSPAJEditSubmit";
            this.dateTimeSPAJEditSubmit.Size = new System.Drawing.Size(186, 31);
            this.dateTimeSPAJEditSubmit.TabIndex = 12;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(36, 167);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(112, 50);
            this.label45.TabIndex = 2;
            this.label45.Text = "Type of \r\nInsurance:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(32, 444);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(129, 50);
            this.label46.TabIndex = 7;
            this.label46.Text = "Submission \r\nDate:";
            // 
            // textBoxEditPruFlyerNum
            // 
            this.textBoxEditPruFlyerNum.Location = new System.Drawing.Point(204, 375);
            this.textBoxEditPruFlyerNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxEditPruFlyerNum.Name = "textBoxEditPruFlyerNum";
            this.textBoxEditPruFlyerNum.Size = new System.Drawing.Size(186, 31);
            this.textBoxEditPruFlyerNum.TabIndex = 11;
            // 
            // tabControlEditSPAJ
            // 
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditInsInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditPolisInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditSpouseInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditParentInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditAddrInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditPengajuanInfo);
            this.tabControlEditSPAJ.Controls.Add(this.tabPageEditBeneficiaryInfo);
            this.tabControlEditSPAJ.Enabled = false;
            this.tabControlEditSPAJ.Location = new System.Drawing.Point(480, 0);
            this.tabControlEditSPAJ.Margin = new System.Windows.Forms.Padding(4);
            this.tabControlEditSPAJ.Name = "tabControlEditSPAJ";
            this.tabControlEditSPAJ.SelectedIndex = 0;
            this.tabControlEditSPAJ.Size = new System.Drawing.Size(1016, 677);
            this.tabControlEditSPAJ.TabIndex = 14;
            // 
            // tabPageEditInsInfo
            // 
            this.tabPageEditInsInfo.Controls.Add(this.label156);
            this.tabPageEditInsInfo.Controls.Add(this.label155);
            this.tabPageEditInsInfo.Controls.Add(this.buttonInsInfoEdit);
            this.tabPageEditInsInfo.Controls.Add(this.buttonSPAJEditInsrClear);
            this.tabPageEditInsInfo.Controls.Add(this.dateTimeSPAJEditInsrDOB);
            this.tabPageEditInsInfo.Controls.Add(this.comboBoxSPAJEditInsrJobClass);
            this.tabPageEditInsInfo.Controls.Add(this.label47);
            this.tabPageEditInsInfo.Controls.Add(this.comboBoxSPAJEditInsrMarriage);
            this.tabPageEditInsInfo.Controls.Add(this.textBoxSPAJEditInsrNextBday);
            this.tabPageEditInsInfo.Controls.Add(this.label48);
            this.tabPageEditInsInfo.Controls.Add(this.comboBoxSPAJEditInsrGender);
            this.tabPageEditInsInfo.Controls.Add(this.label49);
            this.tabPageEditInsInfo.Controls.Add(this.radioButtonSPAJEditInsrSmoke);
            this.tabPageEditInsInfo.Controls.Add(this.textBoxSPAJEditInsrWeight);
            this.tabPageEditInsInfo.Controls.Add(this.textBoxSPAJEditInsrName);
            this.tabPageEditInsInfo.Controls.Add(this.textBoxSPAJEditInsrHeight);
            this.tabPageEditInsInfo.Controls.Add(this.label51);
            this.tabPageEditInsInfo.Controls.Add(this.label52);
            this.tabPageEditInsInfo.Controls.Add(this.label53);
            this.tabPageEditInsInfo.Controls.Add(this.label54);
            this.tabPageEditInsInfo.Controls.Add(this.label55);
            this.tabPageEditInsInfo.Controls.Add(this.label56);
            this.tabPageEditInsInfo.Controls.Add(this.label57);
            this.tabPageEditInsInfo.Controls.Add(this.label58);
            this.tabPageEditInsInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditInsInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditInsInfo.Name = "tabPageEditInsInfo";
            this.tabPageEditInsInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageEditInsInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditInsInfo.TabIndex = 1;
            this.tabPageEditInsInfo.Text = "Insurer Info";
            this.tabPageEditInsInfo.UseVisualStyleBackColor = true;
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(764, 152);
            this.label156.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(35, 25);
            this.label156.TabIndex = 25;
            this.label156.Text = "kg";
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(764, 98);
            this.label155.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(40, 25);
            this.label155.TabIndex = 24;
            this.label155.Text = "cm";
            // 
            // buttonInsInfoEdit
            // 
            this.buttonInsInfoEdit.Location = new System.Drawing.Point(528, 477);
            this.buttonInsInfoEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonInsInfoEdit.Name = "buttonInsInfoEdit";
            this.buttonInsInfoEdit.Size = new System.Drawing.Size(144, 46);
            this.buttonInsInfoEdit.TabIndex = 22;
            this.buttonInsInfoEdit.Text = "Accept";
            this.buttonInsInfoEdit.UseVisualStyleBackColor = true;
            this.buttonInsInfoEdit.Click += new System.EventHandler(this.buttonInsInfoEdit_Click);
            // 
            // buttonSPAJEditInsrClear
            // 
            this.buttonSPAJEditInsrClear.Enabled = false;
            this.buttonSPAJEditInsrClear.Location = new System.Drawing.Point(328, 477);
            this.buttonSPAJEditInsrClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJEditInsrClear.Name = "buttonSPAJEditInsrClear";
            this.buttonSPAJEditInsrClear.Size = new System.Drawing.Size(144, 46);
            this.buttonSPAJEditInsrClear.TabIndex = 21;
            this.buttonSPAJEditInsrClear.Text = "Clear";
            this.buttonSPAJEditInsrClear.UseVisualStyleBackColor = true;
            this.buttonSPAJEditInsrClear.Click += new System.EventHandler(this.buttonSPAJEditInsrClear_Click);
            // 
            // dateTimeSPAJEditInsrDOB
            // 
            this.dateTimeSPAJEditInsrDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditInsrDOB.Location = new System.Drawing.Point(244, 202);
            this.dateTimeSPAJEditInsrDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJEditInsrDOB.Name = "dateTimeSPAJEditInsrDOB";
            this.dateTimeSPAJEditInsrDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJEditInsrDOB.TabIndex = 20;
            this.dateTimeSPAJEditInsrDOB.ValueChanged += new System.EventHandler(this.dateTimeSPAJEditInsrDOB_ValueChanged);
            // 
            // comboBoxSPAJEditInsrJobClass
            // 
            this.comboBoxSPAJEditInsrJobClass.FormattingEnabled = true;
            this.comboBoxSPAJEditInsrJobClass.Items.AddRange(new object[] {
            "Class I ",
            "Class II ",
            "Class III"});
            this.comboBoxSPAJEditInsrJobClass.Location = new System.Drawing.Point(636, 269);
            this.comboBoxSPAJEditInsrJobClass.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditInsrJobClass.Name = "comboBoxSPAJEditInsrJobClass";
            this.comboBoxSPAJEditInsrJobClass.Size = new System.Drawing.Size(120, 33);
            this.comboBoxSPAJEditInsrJobClass.TabIndex = 19;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(62, 202);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(104, 25);
            this.label47.TabIndex = 3;
            this.label47.Text = "Birthdate:";
            // 
            // comboBoxSPAJEditInsrMarriage
            // 
            this.comboBoxSPAJEditInsrMarriage.FormattingEnabled = true;
            this.comboBoxSPAJEditInsrMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJEditInsrMarriage.Location = new System.Drawing.Point(244, 262);
            this.comboBoxSPAJEditInsrMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditInsrMarriage.Name = "comboBoxSPAJEditInsrMarriage";
            this.comboBoxSPAJEditInsrMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditInsrMarriage.TabIndex = 18;
            // 
            // textBoxSPAJEditInsrNextBday
            // 
            this.textBoxSPAJEditInsrNextBday.Location = new System.Drawing.Point(244, 337);
            this.textBoxSPAJEditInsrNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditInsrNextBday.Name = "textBoxSPAJEditInsrNextBday";
            this.textBoxSPAJEditInsrNextBday.ReadOnly = true;
            this.textBoxSPAJEditInsrNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJEditInsrNextBday.TabIndex = 16;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(62, 154);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(89, 25);
            this.label48.TabIndex = 2;
            this.label48.Text = "Gender:";
            // 
            // comboBoxSPAJEditInsrGender
            // 
            this.comboBoxSPAJEditInsrGender.FormattingEnabled = true;
            this.comboBoxSPAJEditInsrGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJEditInsrGender.Location = new System.Drawing.Point(244, 152);
            this.comboBoxSPAJEditInsrGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditInsrGender.Name = "comboBoxSPAJEditInsrGender";
            this.comboBoxSPAJEditInsrGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditInsrGender.TabIndex = 17;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(62, 98);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(121, 25);
            this.label49.TabIndex = 1;
            this.label49.Text = "Full Name: ";
            // 
            // radioButtonSPAJEditInsrSmoke
            // 
            this.radioButtonSPAJEditInsrSmoke.AutoSize = true;
            this.radioButtonSPAJEditInsrSmoke.Location = new System.Drawing.Point(770, 223);
            this.radioButtonSPAJEditInsrSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJEditInsrSmoke.Name = "radioButtonSPAJEditInsrSmoke";
            this.radioButtonSPAJEditInsrSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJEditInsrSmoke.TabIndex = 15;
            this.radioButtonSPAJEditInsrSmoke.TabStop = true;
            this.radioButtonSPAJEditInsrSmoke.Text = "Yes";
            this.radioButtonSPAJEditInsrSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJEditInsrWeight
            // 
            this.textBoxSPAJEditInsrWeight.Location = new System.Drawing.Point(636, 148);
            this.textBoxSPAJEditInsrWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditInsrWeight.Name = "textBoxSPAJEditInsrWeight";
            this.textBoxSPAJEditInsrWeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditInsrWeight.TabIndex = 14;
            // 
            // textBoxSPAJEditInsrName
            // 
            this.textBoxSPAJEditInsrName.Location = new System.Drawing.Point(244, 98);
            this.textBoxSPAJEditInsrName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditInsrName.Name = "textBoxSPAJEditInsrName";
            this.textBoxSPAJEditInsrName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJEditInsrName.TabIndex = 12;
            // 
            // textBoxSPAJEditInsrHeight
            // 
            this.textBoxSPAJEditInsrHeight.Location = new System.Drawing.Point(636, 98);
            this.textBoxSPAJEditInsrHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditInsrHeight.Name = "textBoxSPAJEditInsrHeight";
            this.textBoxSPAJEditInsrHeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditInsrHeight.TabIndex = 13;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(512, 269);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(72, 50);
            this.label51.TabIndex = 11;
            this.label51.Text = "Job \r\nClass:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(512, 202);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(223, 50);
            this.label52.TabIndex = 10;
            this.label52.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(512, 154);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(85, 25);
            this.label53.TabIndex = 9;
            this.label53.Text = "Weight:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(512, 104);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(80, 25);
            this.label54.TabIndex = 8;
            this.label54.Text = "Height:";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(62, 337);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(147, 50);
            this.label55.TabIndex = 6;
            this.label55.Text = "Age at the\r\nNext Birthday:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(62, 252);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(103, 50);
            this.label56.TabIndex = 5;
            this.label56.Text = "Marriage \r\nStatus:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(50, 252);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(0, 25);
            this.label57.TabIndex = 4;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label58.Location = new System.Drawing.Point(60, 31);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(305, 37);
            this.label58.TabIndex = 0;
            this.label58.Text = "Insurer Information";
            // 
            // tabPageEditPolisInfo
            // 
            this.tabPageEditPolisInfo.Controls.Add(this.buttonPolisInfoEdit);
            this.tabPageEditPolisInfo.Controls.Add(this.button9);
            this.tabPageEditPolisInfo.Controls.Add(this.dateTimeSPAJEditPolisDOB);
            this.tabPageEditPolisInfo.Controls.Add(this.comboBoxSPAJEditPolisRs);
            this.tabPageEditPolisInfo.Controls.Add(this.comboBoxSPAJEditPolisMarriage);
            this.tabPageEditPolisInfo.Controls.Add(this.comboBoxSPAJEditPolisGender);
            this.tabPageEditPolisInfo.Controls.Add(this.textBoxSPAJEditPolisName);
            this.tabPageEditPolisInfo.Controls.Add(this.label59);
            this.tabPageEditPolisInfo.Controls.Add(this.label60);
            this.tabPageEditPolisInfo.Controls.Add(this.label61);
            this.tabPageEditPolisInfo.Controls.Add(this.label62);
            this.tabPageEditPolisInfo.Controls.Add(this.label63);
            this.tabPageEditPolisInfo.Controls.Add(this.label64);
            this.tabPageEditPolisInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditPolisInfo.Margin = new System.Windows.Forms.Padding(6);
            this.tabPageEditPolisInfo.Name = "tabPageEditPolisInfo";
            this.tabPageEditPolisInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditPolisInfo.TabIndex = 2;
            this.tabPageEditPolisInfo.Text = "Polis Holder Info";
            this.tabPageEditPolisInfo.UseVisualStyleBackColor = true;
            // 
            // buttonPolisInfoEdit
            // 
            this.buttonPolisInfoEdit.Location = new System.Drawing.Point(532, 467);
            this.buttonPolisInfoEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPolisInfoEdit.Name = "buttonPolisInfoEdit";
            this.buttonPolisInfoEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonPolisInfoEdit.TabIndex = 14;
            this.buttonPolisInfoEdit.Text = "Accept";
            this.buttonPolisInfoEdit.UseVisualStyleBackColor = true;
            this.buttonPolisInfoEdit.Click += new System.EventHandler(this.buttonPolisInfoEdit_Click);
            // 
            // button9
            // 
            this.button9.Enabled = false;
            this.button9.Location = new System.Drawing.Point(320, 467);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 48);
            this.button9.TabIndex = 13;
            this.button9.Text = "Clear";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // dateTimeSPAJEditPolisDOB
            // 
            this.dateTimeSPAJEditPolisDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditPolisDOB.Location = new System.Drawing.Point(392, 223);
            this.dateTimeSPAJEditPolisDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJEditPolisDOB.Name = "dateTimeSPAJEditPolisDOB";
            this.dateTimeSPAJEditPolisDOB.Size = new System.Drawing.Size(222, 31);
            this.dateTimeSPAJEditPolisDOB.TabIndex = 11;
            // 
            // comboBoxSPAJEditPolisRs
            // 
            this.comboBoxSPAJEditPolisRs.FormattingEnabled = true;
            this.comboBoxSPAJEditPolisRs.Items.AddRange(new object[] {
            "Self",
            "Parents",
            "Sibling",
            "Spouse",
            "Children",
            "Other"});
            this.comboBoxSPAJEditPolisRs.Location = new System.Drawing.Point(392, 367);
            this.comboBoxSPAJEditPolisRs.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditPolisRs.Name = "comboBoxSPAJEditPolisRs";
            this.comboBoxSPAJEditPolisRs.Size = new System.Drawing.Size(162, 33);
            this.comboBoxSPAJEditPolisRs.TabIndex = 10;
            // 
            // comboBoxSPAJEditPolisMarriage
            // 
            this.comboBoxSPAJEditPolisMarriage.FormattingEnabled = true;
            this.comboBoxSPAJEditPolisMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJEditPolisMarriage.Location = new System.Drawing.Point(392, 296);
            this.comboBoxSPAJEditPolisMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditPolisMarriage.Name = "comboBoxSPAJEditPolisMarriage";
            this.comboBoxSPAJEditPolisMarriage.Size = new System.Drawing.Size(162, 33);
            this.comboBoxSPAJEditPolisMarriage.TabIndex = 9;
            // 
            // comboBoxSPAJEditPolisGender
            // 
            this.comboBoxSPAJEditPolisGender.FormattingEnabled = true;
            this.comboBoxSPAJEditPolisGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJEditPolisGender.Location = new System.Drawing.Point(392, 144);
            this.comboBoxSPAJEditPolisGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditPolisGender.Name = "comboBoxSPAJEditPolisGender";
            this.comboBoxSPAJEditPolisGender.Size = new System.Drawing.Size(110, 33);
            this.comboBoxSPAJEditPolisGender.TabIndex = 8;
            // 
            // textBoxSPAJEditPolisName
            // 
            this.textBoxSPAJEditPolisName.Location = new System.Drawing.Point(392, 81);
            this.textBoxSPAJEditPolisName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditPolisName.Name = "textBoxSPAJEditPolisName";
            this.textBoxSPAJEditPolisName.Size = new System.Drawing.Size(222, 31);
            this.textBoxSPAJEditPolisName.TabIndex = 7;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(204, 350);
            this.label59.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(137, 50);
            this.label59.TabIndex = 6;
            this.label59.Text = "Relationship \r\nwith Insurer:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(204, 279);
            this.label60.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(103, 50);
            this.label60.TabIndex = 5;
            this.label60.Text = "Marriage \r\nStatus:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(204, 231);
            this.label61.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(104, 25);
            this.label61.TabIndex = 4;
            this.label61.Text = "Birthdate:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(204, 154);
            this.label62.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(89, 25);
            this.label62.TabIndex = 3;
            this.label62.Text = "Gender:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(204, 81);
            this.label63.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(115, 25);
            this.label63.TabIndex = 2;
            this.label63.Text = "Full Name:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label64.Location = new System.Drawing.Point(312, 31);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(383, 37);
            this.label64.TabIndex = 1;
            this.label64.Text = "Polis Holder Information";
            // 
            // tabPageEditSpouseInfo
            // 
            this.tabPageEditSpouseInfo.Controls.Add(this.label158);
            this.tabPageEditSpouseInfo.Controls.Add(this.label157);
            this.tabPageEditSpouseInfo.Controls.Add(this.buttonSpouseEditIgnore);
            this.tabPageEditSpouseInfo.Controls.Add(this.buttonSpouseEdit);
            this.tabPageEditSpouseInfo.Controls.Add(this.button12);
            this.tabPageEditSpouseInfo.Controls.Add(this.dateTimeSPAJEditSpouseDOB);
            this.tabPageEditSpouseInfo.Controls.Add(this.comboBoxSPAJEditSpouseMarriage);
            this.tabPageEditSpouseInfo.Controls.Add(this.comboBoxSPAJEditSpouseGender);
            this.tabPageEditSpouseInfo.Controls.Add(this.textBoxSPAJEditSpouseNextBday);
            this.tabPageEditSpouseInfo.Controls.Add(this.radioButtonSPAJEditSpouseSmoke);
            this.tabPageEditSpouseInfo.Controls.Add(this.textBoxSPAJEditSpouseWeight);
            this.tabPageEditSpouseInfo.Controls.Add(this.textBoxSPAJEditSpouseHeight);
            this.tabPageEditSpouseInfo.Controls.Add(this.textBoxSPAJEditSpouseName);
            this.tabPageEditSpouseInfo.Controls.Add(this.label65);
            this.tabPageEditSpouseInfo.Controls.Add(this.label66);
            this.tabPageEditSpouseInfo.Controls.Add(this.label67);
            this.tabPageEditSpouseInfo.Controls.Add(this.label68);
            this.tabPageEditSpouseInfo.Controls.Add(this.label69);
            this.tabPageEditSpouseInfo.Controls.Add(this.label70);
            this.tabPageEditSpouseInfo.Controls.Add(this.label71);
            this.tabPageEditSpouseInfo.Controls.Add(this.label72);
            this.tabPageEditSpouseInfo.Controls.Add(this.label73);
            this.tabPageEditSpouseInfo.Controls.Add(this.label74);
            this.tabPageEditSpouseInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditSpouseInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditSpouseInfo.Name = "tabPageEditSpouseInfo";
            this.tabPageEditSpouseInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageEditSpouseInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditSpouseInfo.TabIndex = 4;
            this.tabPageEditSpouseInfo.Text = "Spouse/Parent 1 Info";
            this.tabPageEditSpouseInfo.UseVisualStyleBackColor = true;
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(716, 156);
            this.label158.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(35, 25);
            this.label158.TabIndex = 27;
            this.label158.Text = "kg";
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(716, 98);
            this.label157.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(40, 25);
            this.label157.TabIndex = 26;
            this.label157.Text = "cm";
            // 
            // buttonSpouseEditIgnore
            // 
            this.buttonSpouseEditIgnore.Enabled = false;
            this.buttonSpouseEditIgnore.Location = new System.Drawing.Point(178, 467);
            this.buttonSpouseEditIgnore.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSpouseEditIgnore.Name = "buttonSpouseEditIgnore";
            this.buttonSpouseEditIgnore.Size = new System.Drawing.Size(120, 48);
            this.buttonSpouseEditIgnore.TabIndex = 25;
            this.buttonSpouseEditIgnore.Text = "Ignore";
            this.buttonSpouseEditIgnore.UseVisualStyleBackColor = true;
            this.buttonSpouseEditIgnore.Click += new System.EventHandler(this.buttonSpouseEditIgnore_Click);
            // 
            // buttonSpouseEdit
            // 
            this.buttonSpouseEdit.Location = new System.Drawing.Point(596, 467);
            this.buttonSpouseEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSpouseEdit.Name = "buttonSpouseEdit";
            this.buttonSpouseEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonSpouseEdit.TabIndex = 24;
            this.buttonSpouseEdit.Text = "Accept";
            this.buttonSpouseEdit.UseVisualStyleBackColor = true;
            this.buttonSpouseEdit.Click += new System.EventHandler(this.buttonSpouseEdit_Click);
            // 
            // button12
            // 
            this.button12.Enabled = false;
            this.button12.Location = new System.Drawing.Point(380, 467);
            this.button12.Margin = new System.Windows.Forms.Padding(4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(128, 48);
            this.button12.TabIndex = 23;
            this.button12.Text = "Clear";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // dateTimeSPAJEditSpouseDOB
            // 
            this.dateTimeSPAJEditSpouseDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditSpouseDOB.Location = new System.Drawing.Point(200, 196);
            this.dateTimeSPAJEditSpouseDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJEditSpouseDOB.Name = "dateTimeSPAJEditSpouseDOB";
            this.dateTimeSPAJEditSpouseDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJEditSpouseDOB.TabIndex = 20;
            this.dateTimeSPAJEditSpouseDOB.ValueChanged += new System.EventHandler(this.dateTimeSPAJEditSpouseDOB_ValueChanged);
            // 
            // comboBoxSPAJEditSpouseMarriage
            // 
            this.comboBoxSPAJEditSpouseMarriage.FormattingEnabled = true;
            this.comboBoxSPAJEditSpouseMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJEditSpouseMarriage.Location = new System.Drawing.Point(200, 246);
            this.comboBoxSPAJEditSpouseMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditSpouseMarriage.Name = "comboBoxSPAJEditSpouseMarriage";
            this.comboBoxSPAJEditSpouseMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditSpouseMarriage.TabIndex = 18;
            // 
            // comboBoxSPAJEditSpouseGender
            // 
            this.comboBoxSPAJEditSpouseGender.FormattingEnabled = true;
            this.comboBoxSPAJEditSpouseGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJEditSpouseGender.Location = new System.Drawing.Point(200, 148);
            this.comboBoxSPAJEditSpouseGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditSpouseGender.Name = "comboBoxSPAJEditSpouseGender";
            this.comboBoxSPAJEditSpouseGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditSpouseGender.TabIndex = 17;
            // 
            // textBoxSPAJEditSpouseNextBday
            // 
            this.textBoxSPAJEditSpouseNextBday.Location = new System.Drawing.Point(200, 312);
            this.textBoxSPAJEditSpouseNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditSpouseNextBday.Name = "textBoxSPAJEditSpouseNextBday";
            this.textBoxSPAJEditSpouseNextBday.ReadOnly = true;
            this.textBoxSPAJEditSpouseNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJEditSpouseNextBday.TabIndex = 16;
            // 
            // radioButtonSPAJEditSpouseSmoke
            // 
            this.radioButtonSPAJEditSpouseSmoke.AutoSize = true;
            this.radioButtonSPAJEditSpouseSmoke.Location = new System.Drawing.Point(676, 219);
            this.radioButtonSPAJEditSpouseSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJEditSpouseSmoke.Name = "radioButtonSPAJEditSpouseSmoke";
            this.radioButtonSPAJEditSpouseSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJEditSpouseSmoke.TabIndex = 15;
            this.radioButtonSPAJEditSpouseSmoke.TabStop = true;
            this.radioButtonSPAJEditSpouseSmoke.Text = "Yes";
            this.radioButtonSPAJEditSpouseSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJEditSpouseWeight
            // 
            this.textBoxSPAJEditSpouseWeight.Location = new System.Drawing.Point(568, 148);
            this.textBoxSPAJEditSpouseWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditSpouseWeight.Name = "textBoxSPAJEditSpouseWeight";
            this.textBoxSPAJEditSpouseWeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditSpouseWeight.TabIndex = 14;
            // 
            // textBoxSPAJEditSpouseHeight
            // 
            this.textBoxSPAJEditSpouseHeight.Location = new System.Drawing.Point(568, 98);
            this.textBoxSPAJEditSpouseHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditSpouseHeight.Name = "textBoxSPAJEditSpouseHeight";
            this.textBoxSPAJEditSpouseHeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditSpouseHeight.TabIndex = 13;
            // 
            // textBoxSPAJEditSpouseName
            // 
            this.textBoxSPAJEditSpouseName.Location = new System.Drawing.Point(200, 98);
            this.textBoxSPAJEditSpouseName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditSpouseName.Name = "textBoxSPAJEditSpouseName";
            this.textBoxSPAJEditSpouseName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJEditSpouseName.TabIndex = 12;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(470, 202);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(223, 50);
            this.label65.TabIndex = 10;
            this.label65.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(470, 154);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(85, 25);
            this.label66.TabIndex = 9;
            this.label66.Text = "Weight:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(470, 104);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(80, 25);
            this.label67.TabIndex = 8;
            this.label67.Text = "Height:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(50, 294);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(147, 50);
            this.label68.TabIndex = 6;
            this.label68.Text = "Age at the\r\nNext Birthday:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(52, 242);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(103, 50);
            this.label69.TabIndex = 5;
            this.label69.Text = "Marriage \r\nStatus:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(50, 252);
            this.label70.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(0, 25);
            this.label70.TabIndex = 4;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(50, 202);
            this.label71.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(104, 25);
            this.label71.TabIndex = 3;
            this.label71.Text = "Birthdate:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(48, 154);
            this.label72.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(89, 25);
            this.label72.TabIndex = 2;
            this.label72.Text = "Gender:";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(48, 104);
            this.label73.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(121, 25);
            this.label73.TabIndex = 1;
            this.label73.Text = "Full Name: ";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label74.Location = new System.Drawing.Point(284, 33);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(376, 37);
            this.label74.TabIndex = 0;
            this.label74.Text = "Spouse or Parent 1 Info";
            // 
            // tabPageEditParentInfo
            // 
            this.tabPageEditParentInfo.Controls.Add(this.label160);
            this.tabPageEditParentInfo.Controls.Add(this.label159);
            this.tabPageEditParentInfo.Controls.Add(this.buttonParentEditIgnore);
            this.tabPageEditParentInfo.Controls.Add(this.buttonParentEdit);
            this.tabPageEditParentInfo.Controls.Add(this.button15);
            this.tabPageEditParentInfo.Controls.Add(this.dateTimeSPAJEditParentDOB);
            this.tabPageEditParentInfo.Controls.Add(this.comboBoxSPAJEditParentMarriage);
            this.tabPageEditParentInfo.Controls.Add(this.comboBoxSPAJEditParentGender);
            this.tabPageEditParentInfo.Controls.Add(this.textBoxSPAJEditParentNextBday);
            this.tabPageEditParentInfo.Controls.Add(this.radioButtonSPAJEditParentSmoke);
            this.tabPageEditParentInfo.Controls.Add(this.textBoxSPAJEditParentWeight);
            this.tabPageEditParentInfo.Controls.Add(this.textBoxSPAJEditParentHeight);
            this.tabPageEditParentInfo.Controls.Add(this.textBoxSPAJEditParentName);
            this.tabPageEditParentInfo.Controls.Add(this.label99);
            this.tabPageEditParentInfo.Controls.Add(this.label100);
            this.tabPageEditParentInfo.Controls.Add(this.label101);
            this.tabPageEditParentInfo.Controls.Add(this.label102);
            this.tabPageEditParentInfo.Controls.Add(this.label103);
            this.tabPageEditParentInfo.Controls.Add(this.label104);
            this.tabPageEditParentInfo.Controls.Add(this.label105);
            this.tabPageEditParentInfo.Controls.Add(this.label106);
            this.tabPageEditParentInfo.Controls.Add(this.label107);
            this.tabPageEditParentInfo.Controls.Add(this.label108);
            this.tabPageEditParentInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditParentInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditParentInfo.Name = "tabPageEditParentInfo";
            this.tabPageEditParentInfo.Padding = new System.Windows.Forms.Padding(4);
            this.tabPageEditParentInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditParentInfo.TabIndex = 6;
            this.tabPageEditParentInfo.Text = "Parent 2 Info";
            this.tabPageEditParentInfo.UseVisualStyleBackColor = true;
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(706, 156);
            this.label160.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(35, 25);
            this.label160.TabIndex = 25;
            this.label160.Text = "kg";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(706, 104);
            this.label159.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(40, 25);
            this.label159.TabIndex = 24;
            this.label159.Text = "cm";
            // 
            // buttonParentEditIgnore
            // 
            this.buttonParentEditIgnore.Location = new System.Drawing.Point(200, 467);
            this.buttonParentEditIgnore.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParentEditIgnore.Name = "buttonParentEditIgnore";
            this.buttonParentEditIgnore.Size = new System.Drawing.Size(120, 48);
            this.buttonParentEditIgnore.TabIndex = 23;
            this.buttonParentEditIgnore.Text = "Ignore";
            this.buttonParentEditIgnore.UseVisualStyleBackColor = true;
            // 
            // buttonParentEdit
            // 
            this.buttonParentEdit.Location = new System.Drawing.Point(600, 467);
            this.buttonParentEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParentEdit.Name = "buttonParentEdit";
            this.buttonParentEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonParentEdit.TabIndex = 22;
            this.buttonParentEdit.Text = "Accept";
            this.buttonParentEdit.UseVisualStyleBackColor = true;
            this.buttonParentEdit.Click += new System.EventHandler(this.buttonParentEdit_Click);
            // 
            // button15
            // 
            this.button15.Enabled = false;
            this.button15.Location = new System.Drawing.Point(402, 467);
            this.button15.Margin = new System.Windows.Forms.Padding(4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(120, 48);
            this.button15.TabIndex = 21;
            this.button15.Text = "Clear";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // dateTimeSPAJEditParentDOB
            // 
            this.dateTimeSPAJEditParentDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditParentDOB.Location = new System.Drawing.Point(200, 196);
            this.dateTimeSPAJEditParentDOB.Margin = new System.Windows.Forms.Padding(6);
            this.dateTimeSPAJEditParentDOB.Name = "dateTimeSPAJEditParentDOB";
            this.dateTimeSPAJEditParentDOB.Size = new System.Drawing.Size(248, 31);
            this.dateTimeSPAJEditParentDOB.TabIndex = 20;
            this.dateTimeSPAJEditParentDOB.ValueChanged += new System.EventHandler(this.dateTimeSPAJEditParentDOB_ValueChanged);
            // 
            // comboBoxSPAJEditParentMarriage
            // 
            this.comboBoxSPAJEditParentMarriage.FormattingEnabled = true;
            this.comboBoxSPAJEditParentMarriage.Items.AddRange(new object[] {
            "Single",
            "Married"});
            this.comboBoxSPAJEditParentMarriage.Location = new System.Drawing.Point(200, 246);
            this.comboBoxSPAJEditParentMarriage.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditParentMarriage.Name = "comboBoxSPAJEditParentMarriage";
            this.comboBoxSPAJEditParentMarriage.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditParentMarriage.TabIndex = 18;
            // 
            // comboBoxSPAJEditParentGender
            // 
            this.comboBoxSPAJEditParentGender.FormattingEnabled = true;
            this.comboBoxSPAJEditParentGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxSPAJEditParentGender.Location = new System.Drawing.Point(200, 148);
            this.comboBoxSPAJEditParentGender.Margin = new System.Windows.Forms.Padding(6);
            this.comboBoxSPAJEditParentGender.Name = "comboBoxSPAJEditParentGender";
            this.comboBoxSPAJEditParentGender.Size = new System.Drawing.Size(140, 33);
            this.comboBoxSPAJEditParentGender.TabIndex = 17;
            // 
            // textBoxSPAJEditParentNextBday
            // 
            this.textBoxSPAJEditParentNextBday.Location = new System.Drawing.Point(200, 312);
            this.textBoxSPAJEditParentNextBday.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditParentNextBday.Name = "textBoxSPAJEditParentNextBday";
            this.textBoxSPAJEditParentNextBday.ReadOnly = true;
            this.textBoxSPAJEditParentNextBday.Size = new System.Drawing.Size(88, 31);
            this.textBoxSPAJEditParentNextBday.TabIndex = 16;
            // 
            // radioButtonSPAJEditParentSmoke
            // 
            this.radioButtonSPAJEditParentSmoke.AutoSize = true;
            this.radioButtonSPAJEditParentSmoke.Location = new System.Drawing.Point(676, 219);
            this.radioButtonSPAJEditParentSmoke.Margin = new System.Windows.Forms.Padding(6);
            this.radioButtonSPAJEditParentSmoke.Name = "radioButtonSPAJEditParentSmoke";
            this.radioButtonSPAJEditParentSmoke.Size = new System.Drawing.Size(81, 29);
            this.radioButtonSPAJEditParentSmoke.TabIndex = 15;
            this.radioButtonSPAJEditParentSmoke.TabStop = true;
            this.radioButtonSPAJEditParentSmoke.Text = "Yes";
            this.radioButtonSPAJEditParentSmoke.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJEditParentWeight
            // 
            this.textBoxSPAJEditParentWeight.Location = new System.Drawing.Point(568, 148);
            this.textBoxSPAJEditParentWeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditParentWeight.Name = "textBoxSPAJEditParentWeight";
            this.textBoxSPAJEditParentWeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditParentWeight.TabIndex = 14;
            // 
            // textBoxSPAJEditParentHeight
            // 
            this.textBoxSPAJEditParentHeight.Location = new System.Drawing.Point(568, 98);
            this.textBoxSPAJEditParentHeight.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditParentHeight.Name = "textBoxSPAJEditParentHeight";
            this.textBoxSPAJEditParentHeight.Size = new System.Drawing.Size(120, 31);
            this.textBoxSPAJEditParentHeight.TabIndex = 13;
            // 
            // textBoxSPAJEditParentName
            // 
            this.textBoxSPAJEditParentName.Location = new System.Drawing.Point(200, 98);
            this.textBoxSPAJEditParentName.Margin = new System.Windows.Forms.Padding(6);
            this.textBoxSPAJEditParentName.Name = "textBoxSPAJEditParentName";
            this.textBoxSPAJEditParentName.Size = new System.Drawing.Size(252, 31);
            this.textBoxSPAJEditParentName.TabIndex = 12;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(470, 202);
            this.label99.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(223, 50);
            this.label99.TabIndex = 10;
            this.label99.Text = "In the last 12 months, \r\ndid you smoke?";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(470, 154);
            this.label100.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(85, 25);
            this.label100.TabIndex = 9;
            this.label100.Text = "Weight:";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(470, 104);
            this.label101.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(80, 25);
            this.label101.TabIndex = 8;
            this.label101.Text = "Height:";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(50, 294);
            this.label102.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(147, 50);
            this.label102.TabIndex = 6;
            this.label102.Text = "Age at the\r\nNext Birthday:";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(52, 242);
            this.label103.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(103, 50);
            this.label103.TabIndex = 5;
            this.label103.Text = "Marriage \r\nStatus:";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(50, 252);
            this.label104.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(0, 25);
            this.label104.TabIndex = 4;
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(50, 202);
            this.label105.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(104, 25);
            this.label105.TabIndex = 3;
            this.label105.Text = "Birthdate:";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(48, 154);
            this.label106.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(89, 25);
            this.label106.TabIndex = 2;
            this.label106.Text = "Gender:";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(48, 104);
            this.label107.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(121, 25);
            this.label107.TabIndex = 1;
            this.label107.Text = "Full Name: ";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label108.Location = new System.Drawing.Point(380, 29);
            this.label108.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(213, 37);
            this.label108.TabIndex = 0;
            this.label108.Text = "Parent 2 Info";
            // 
            // tabPageEditAddrInfo
            // 
            this.tabPageEditAddrInfo.Controls.Add(this.buttonAddressEdit);
            this.tabPageEditAddrInfo.Controls.Add(this.button17);
            this.tabPageEditAddrInfo.Controls.Add(this.label109);
            this.tabPageEditAddrInfo.Controls.Add(this.label110);
            this.tabPageEditAddrInfo.Controls.Add(this.label111);
            this.tabPageEditAddrInfo.Controls.Add(this.label112);
            this.tabPageEditAddrInfo.Controls.Add(this.label113);
            this.tabPageEditAddrInfo.Controls.Add(this.label114);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrOP);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrHP);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrEmail);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrZip);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrCity);
            this.tabPageEditAddrInfo.Controls.Add(this.textBoxSPAJEditAddrAddress);
            this.tabPageEditAddrInfo.Controls.Add(this.label115);
            this.tabPageEditAddrInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditAddrInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditAddrInfo.Name = "tabPageEditAddrInfo";
            this.tabPageEditAddrInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditAddrInfo.TabIndex = 5;
            this.tabPageEditAddrInfo.Text = "Address Info";
            this.tabPageEditAddrInfo.UseVisualStyleBackColor = true;
            // 
            // buttonAddressEdit
            // 
            this.buttonAddressEdit.Location = new System.Drawing.Point(552, 506);
            this.buttonAddressEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAddressEdit.Name = "buttonAddressEdit";
            this.buttonAddressEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonAddressEdit.TabIndex = 17;
            this.buttonAddressEdit.Text = "Accept";
            this.buttonAddressEdit.UseVisualStyleBackColor = true;
            this.buttonAddressEdit.Click += new System.EventHandler(this.buttonAddressEdit_Click);
            // 
            // button17
            // 
            this.button17.Enabled = false;
            this.button17.Location = new System.Drawing.Point(348, 506);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(120, 48);
            this.button17.TabIndex = 16;
            this.button17.Text = "Clear";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(240, 381);
            this.label109.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(136, 50);
            this.label109.TabIndex = 15;
            this.label109.Text = "Office Phone\r\n Number:";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(240, 317);
            this.label110.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(131, 50);
            this.label110.TabIndex = 14;
            this.label110.Text = "HandPhone \r\nNumber:";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(240, 273);
            this.label111.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(65, 25);
            this.label111.TabIndex = 13;
            this.label111.Text = "Email";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(240, 221);
            this.label112.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(93, 25);
            this.label112.TabIndex = 12;
            this.label112.Text = "ZipCode";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(240, 162);
            this.label113.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(55, 25);
            this.label113.TabIndex = 11;
            this.label113.Text = "City ";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(240, 110);
            this.label114.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(91, 25);
            this.label114.TabIndex = 10;
            this.label114.Text = "Address";
            // 
            // textBoxSPAJEditAddrOP
            // 
            this.textBoxSPAJEditAddrOP.Location = new System.Drawing.Point(474, 400);
            this.textBoxSPAJEditAddrOP.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrOP.Name = "textBoxSPAJEditAddrOP";
            this.textBoxSPAJEditAddrOP.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrOP.TabIndex = 8;
            // 
            // textBoxSPAJEditAddrHP
            // 
            this.textBoxSPAJEditAddrHP.Location = new System.Drawing.Point(474, 337);
            this.textBoxSPAJEditAddrHP.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrHP.Name = "textBoxSPAJEditAddrHP";
            this.textBoxSPAJEditAddrHP.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrHP.TabIndex = 7;
            // 
            // textBoxSPAJEditAddrEmail
            // 
            this.textBoxSPAJEditAddrEmail.Location = new System.Drawing.Point(474, 277);
            this.textBoxSPAJEditAddrEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrEmail.Name = "textBoxSPAJEditAddrEmail";
            this.textBoxSPAJEditAddrEmail.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrEmail.TabIndex = 6;
            // 
            // textBoxSPAJEditAddrZip
            // 
            this.textBoxSPAJEditAddrZip.Location = new System.Drawing.Point(474, 221);
            this.textBoxSPAJEditAddrZip.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrZip.Name = "textBoxSPAJEditAddrZip";
            this.textBoxSPAJEditAddrZip.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrZip.TabIndex = 5;
            // 
            // textBoxSPAJEditAddrCity
            // 
            this.textBoxSPAJEditAddrCity.Location = new System.Drawing.Point(474, 162);
            this.textBoxSPAJEditAddrCity.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrCity.Name = "textBoxSPAJEditAddrCity";
            this.textBoxSPAJEditAddrCity.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrCity.TabIndex = 4;
            // 
            // textBoxSPAJEditAddrAddress
            // 
            this.textBoxSPAJEditAddrAddress.Location = new System.Drawing.Point(474, 104);
            this.textBoxSPAJEditAddrAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAddrAddress.Name = "textBoxSPAJEditAddrAddress";
            this.textBoxSPAJEditAddrAddress.Size = new System.Drawing.Size(200, 31);
            this.textBoxSPAJEditAddrAddress.TabIndex = 3;
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label115.Location = new System.Drawing.Point(376, 42);
            this.label115.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(209, 37);
            this.label115.TabIndex = 2;
            this.label115.Text = "Address Info";
            // 
            // tabPageEditPengajuanInfo
            // 
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruHosp);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label162);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruPPayor);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPRUMed);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruADD);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruCC);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruPayor);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanBasic);
            this.tabPageEditPengajuanInfo.Controls.Add(this.labelEditPruHospitalandSurgical);
            this.tabPageEditPengajuanInfo.Controls.Add(this.buttonPengajuanEdit);
            this.tabPageEditPengajuanInfo.Controls.Add(this.button19);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPremiTotal);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label116);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label117);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label118);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruSaver);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPremi);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPrtanggung);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanExchange);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanExpDate);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanCCBank);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruPPayorAmnt);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPRUMedAmnt);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruADDAmnt);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruCCAmnt);
            this.tabPageEditPengajuanInfo.Controls.Add(this.textBoxSPAJEditPengajuanPruPayorAmnt);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanPruPPayor);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanPRUMed);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanADD);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanPruCC);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanPruPayor);
            this.tabPageEditPengajuanInfo.Controls.Add(this.checkBoxSPAJEditPengajuanPruHosp);
            this.tabPageEditPengajuanInfo.Controls.Add(this.comboBoxSPAJEditPengajuanCurrency);
            this.tabPageEditPengajuanInfo.Controls.Add(this.comboBoxSPAJEditPengajuanPay);
            this.tabPageEditPengajuanInfo.Controls.Add(this.comboBoxSPAJEditPengajuanFreq);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label119);
            this.tabPageEditPengajuanInfo.Controls.Add(this.labelSPAJEditPengajuanExRate);
            this.tabPageEditPengajuanInfo.Controls.Add(this.labelSPAJEditPengajuanCCExpDate);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label122);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label123);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label124);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label125);
            this.tabPageEditPengajuanInfo.Controls.Add(this.labelSPAJEditPengajuanCCBankOther);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label127);
            this.tabPageEditPengajuanInfo.Controls.Add(this.label128);
            this.tabPageEditPengajuanInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditPengajuanInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditPengajuanInfo.Name = "tabPageEditPengajuanInfo";
            this.tabPageEditPengajuanInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditPengajuanInfo.TabIndex = 7;
            this.tabPageEditPengajuanInfo.Text = "Pengajuan";
            this.tabPageEditPengajuanInfo.UseVisualStyleBackColor = true;
            // 
            // textBoxSPAJEditPengajuanPruHosp
            // 
            this.textBoxSPAJEditPengajuanPruHosp.Enabled = false;
            this.textBoxSPAJEditPengajuanPruHosp.Location = new System.Drawing.Point(772, 71);
            this.textBoxSPAJEditPengajuanPruHosp.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruHosp.Name = "textBoxSPAJEditPengajuanPruHosp";
            this.textBoxSPAJEditPengajuanPruHosp.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruHosp.TabIndex = 52;
            this.textBoxSPAJEditPengajuanPruHosp.Text = "0.00";
            this.textBoxSPAJEditPengajuanPruHosp.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPruHosp_TextChanged);
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(792, 31);
            this.label162.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(129, 25);
            this.label162.TabIndex = 51;
            this.label162.Text = "diisi per thn.";
            // 
            // textBoxSPAJEditPengajuanPruPPayor
            // 
            this.textBoxSPAJEditPengajuanPruPPayor.Location = new System.Drawing.Point(588, 342);
            this.textBoxSPAJEditPengajuanPruPPayor.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruPPayor.Multiline = true;
            this.textBoxSPAJEditPengajuanPruPPayor.Name = "textBoxSPAJEditPengajuanPruPPayor";
            this.textBoxSPAJEditPengajuanPruPPayor.Size = new System.Drawing.Size(172, 44);
            this.textBoxSPAJEditPengajuanPruPPayor.TabIndex = 50;
            // 
            // textBoxSPAJEditPengajuanPRUMed
            // 
            this.textBoxSPAJEditPengajuanPRUMed.Location = new System.Drawing.Point(588, 290);
            this.textBoxSPAJEditPengajuanPRUMed.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPRUMed.Multiline = true;
            this.textBoxSPAJEditPengajuanPRUMed.Name = "textBoxSPAJEditPengajuanPRUMed";
            this.textBoxSPAJEditPengajuanPRUMed.Size = new System.Drawing.Size(172, 44);
            this.textBoxSPAJEditPengajuanPRUMed.TabIndex = 49;
            // 
            // textBoxSPAJEditPengajuanPruADD
            // 
            this.textBoxSPAJEditPengajuanPruADD.Location = new System.Drawing.Point(588, 237);
            this.textBoxSPAJEditPengajuanPruADD.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruADD.Multiline = true;
            this.textBoxSPAJEditPengajuanPruADD.Name = "textBoxSPAJEditPengajuanPruADD";
            this.textBoxSPAJEditPengajuanPruADD.Size = new System.Drawing.Size(172, 44);
            this.textBoxSPAJEditPengajuanPruADD.TabIndex = 48;
            // 
            // textBoxSPAJEditPengajuanPruCC
            // 
            this.textBoxSPAJEditPengajuanPruCC.Location = new System.Drawing.Point(588, 177);
            this.textBoxSPAJEditPengajuanPruCC.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruCC.Multiline = true;
            this.textBoxSPAJEditPengajuanPruCC.Name = "textBoxSPAJEditPengajuanPruCC";
            this.textBoxSPAJEditPengajuanPruCC.Size = new System.Drawing.Size(172, 44);
            this.textBoxSPAJEditPengajuanPruCC.TabIndex = 47;
            // 
            // textBoxSPAJEditPengajuanPruPayor
            // 
            this.textBoxSPAJEditPengajuanPruPayor.Location = new System.Drawing.Point(588, 125);
            this.textBoxSPAJEditPengajuanPruPayor.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruPayor.Multiline = true;
            this.textBoxSPAJEditPengajuanPruPayor.Name = "textBoxSPAJEditPengajuanPruPayor";
            this.textBoxSPAJEditPengajuanPruPayor.Size = new System.Drawing.Size(172, 44);
            this.textBoxSPAJEditPengajuanPruPayor.TabIndex = 46;
            // 
            // textBoxSPAJEditPengajuanBasic
            // 
            this.textBoxSPAJEditPengajuanBasic.Location = new System.Drawing.Point(60, 427);
            this.textBoxSPAJEditPengajuanBasic.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanBasic.Name = "textBoxSPAJEditPengajuanBasic";
            this.textBoxSPAJEditPengajuanBasic.Size = new System.Drawing.Size(206, 31);
            this.textBoxSPAJEditPengajuanBasic.TabIndex = 45;
            // 
            // labelEditPruHospitalandSurgical
            // 
            this.labelEditPruHospitalandSurgical.AutoSize = true;
            this.labelEditPruHospitalandSurgical.Enabled = false;
            this.labelEditPruHospitalandSurgical.Location = new System.Drawing.Point(584, 71);
            this.labelEditPruHospitalandSurgical.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelEditPruHospitalandSurgical.Name = "labelEditPruHospitalandSurgical";
            this.labelEditPruHospitalandSurgical.Size = new System.Drawing.Size(182, 50);
            this.labelEditPruHospitalandSurgical.TabIndex = 44;
            this.labelEditPruHospitalandSurgical.Text = "PRUHospital and \r\nSurgical";
            // 
            // buttonPengajuanEdit
            // 
            this.buttonPengajuanEdit.Location = new System.Drawing.Point(330, 540);
            this.buttonPengajuanEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonPengajuanEdit.Name = "buttonPengajuanEdit";
            this.buttonPengajuanEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonPengajuanEdit.TabIndex = 43;
            this.buttonPengajuanEdit.Text = "Accept";
            this.buttonPengajuanEdit.UseVisualStyleBackColor = true;
            this.buttonPengajuanEdit.Click += new System.EventHandler(this.buttonPengajuanEdit_Click);
            // 
            // button19
            // 
            this.button19.Enabled = false;
            this.button19.Location = new System.Drawing.Point(104, 540);
            this.button19.Margin = new System.Windows.Forms.Padding(4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(120, 48);
            this.button19.TabIndex = 42;
            this.button19.Text = "Clear";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // textBoxSPAJEditPengajuanPremiTotal
            // 
            this.textBoxSPAJEditPengajuanPremiTotal.Enabled = false;
            this.textBoxSPAJEditPengajuanPremiTotal.Location = new System.Drawing.Point(772, 540);
            this.textBoxSPAJEditPengajuanPremiTotal.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPremiTotal.Name = "textBoxSPAJEditPengajuanPremiTotal";
            this.textBoxSPAJEditPengajuanPremiTotal.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPremiTotal.TabIndex = 41;
            this.textBoxSPAJEditPengajuanPremiTotal.Text = "0.00";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(572, 463);
            this.label116.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(159, 50);
            this.label116.TabIndex = 40;
            this.label116.Text = "PRU Saver\r\n(Per Periode):";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(572, 523);
            this.label117.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(137, 50);
            this.label117.TabIndex = 39;
            this.label117.Text = "Premi Total\r\n(Per tahun):";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.Location = new System.Drawing.Point(572, 404);
            this.label118.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(173, 50);
            this.label118.TabIndex = 38;
            this.label118.Text = "Premi \r\n(Per Periode.) :";
            // 
            // textBoxSPAJEditPengajuanPruSaver
            // 
            this.textBoxSPAJEditPengajuanPruSaver.Location = new System.Drawing.Point(772, 483);
            this.textBoxSPAJEditPengajuanPruSaver.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruSaver.Name = "textBoxSPAJEditPengajuanPruSaver";
            this.textBoxSPAJEditPengajuanPruSaver.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruSaver.TabIndex = 37;
            this.textBoxSPAJEditPengajuanPruSaver.Text = "0.00";
            // 
            // textBoxSPAJEditPengajuanPremi
            // 
            this.textBoxSPAJEditPengajuanPremi.Enabled = false;
            this.textBoxSPAJEditPengajuanPremi.Location = new System.Drawing.Point(772, 423);
            this.textBoxSPAJEditPengajuanPremi.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPremi.Name = "textBoxSPAJEditPengajuanPremi";
            this.textBoxSPAJEditPengajuanPremi.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPremi.TabIndex = 36;
            this.textBoxSPAJEditPengajuanPremi.Text = "0.00";
            // 
            // textBoxSPAJEditPengajuanPrtanggung
            // 
            this.textBoxSPAJEditPengajuanPrtanggung.Location = new System.Drawing.Point(310, 427);
            this.textBoxSPAJEditPengajuanPrtanggung.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPrtanggung.Name = "textBoxSPAJEditPengajuanPrtanggung";
            this.textBoxSPAJEditPengajuanPrtanggung.Size = new System.Drawing.Size(208, 31);
            this.textBoxSPAJEditPengajuanPrtanggung.TabIndex = 35;
            this.textBoxSPAJEditPengajuanPrtanggung.Text = "0.00";
            this.textBoxSPAJEditPengajuanPrtanggung.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPrtanggung_TextChanged);
            // 
            // textBoxSPAJEditPengajuanExchange
            // 
            this.textBoxSPAJEditPengajuanExchange.Enabled = false;
            this.textBoxSPAJEditPengajuanExchange.Location = new System.Drawing.Point(308, 337);
            this.textBoxSPAJEditPengajuanExchange.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanExchange.Name = "textBoxSPAJEditPengajuanExchange";
            this.textBoxSPAJEditPengajuanExchange.Size = new System.Drawing.Size(208, 31);
            this.textBoxSPAJEditPengajuanExchange.TabIndex = 34;
            this.textBoxSPAJEditPengajuanExchange.Text = "0.00";
            // 
            // textBoxSPAJEditPengajuanExpDate
            // 
            this.textBoxSPAJEditPengajuanExpDate.Enabled = false;
            this.textBoxSPAJEditPengajuanExpDate.Location = new System.Drawing.Point(310, 227);
            this.textBoxSPAJEditPengajuanExpDate.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanExpDate.Name = "textBoxSPAJEditPengajuanExpDate";
            this.textBoxSPAJEditPengajuanExpDate.Size = new System.Drawing.Size(208, 31);
            this.textBoxSPAJEditPengajuanExpDate.TabIndex = 33;
            this.textBoxSPAJEditPengajuanExpDate.Text = "MM/YY";
            // 
            // textBoxSPAJEditPengajuanCCBank
            // 
            this.textBoxSPAJEditPengajuanCCBank.Enabled = false;
            this.textBoxSPAJEditPengajuanCCBank.Location = new System.Drawing.Point(310, 190);
            this.textBoxSPAJEditPengajuanCCBank.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanCCBank.Name = "textBoxSPAJEditPengajuanCCBank";
            this.textBoxSPAJEditPengajuanCCBank.Size = new System.Drawing.Size(208, 31);
            this.textBoxSPAJEditPengajuanCCBank.TabIndex = 32;
            this.textBoxSPAJEditPengajuanCCBank.Text = "1234-5678-9000";
            // 
            // textBoxSPAJEditPengajuanPruPPayorAmnt
            // 
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Enabled = false;
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Location = new System.Drawing.Point(772, 356);
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Name = "textBoxSPAJEditPengajuanPruPPayorAmnt";
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.TabIndex = 31;
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.Text = "0.00";
            this.textBoxSPAJEditPengajuanPruPPayorAmnt.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPruPPayorAmnt_TextChanged);
            // 
            // textBoxSPAJEditPengajuanPRUMedAmnt
            // 
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Enabled = false;
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Location = new System.Drawing.Point(772, 304);
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Name = "textBoxSPAJEditPengajuanPRUMedAmnt";
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPRUMedAmnt.TabIndex = 30;
            this.textBoxSPAJEditPengajuanPRUMedAmnt.Text = "0.00";
            this.textBoxSPAJEditPengajuanPRUMedAmnt.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPRUMedAmnt_TextChanged);
            // 
            // textBoxSPAJEditPengajuanPruADDAmnt
            // 
            this.textBoxSPAJEditPengajuanPruADDAmnt.Enabled = false;
            this.textBoxSPAJEditPengajuanPruADDAmnt.Location = new System.Drawing.Point(772, 244);
            this.textBoxSPAJEditPengajuanPruADDAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruADDAmnt.Name = "textBoxSPAJEditPengajuanPruADDAmnt";
            this.textBoxSPAJEditPengajuanPruADDAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruADDAmnt.TabIndex = 29;
            this.textBoxSPAJEditPengajuanPruADDAmnt.Text = "0.00";
            this.textBoxSPAJEditPengajuanPruADDAmnt.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPruADDAmnt_TextChanged);
            // 
            // textBoxSPAJEditPengajuanPruCCAmnt
            // 
            this.textBoxSPAJEditPengajuanPruCCAmnt.Enabled = false;
            this.textBoxSPAJEditPengajuanPruCCAmnt.Location = new System.Drawing.Point(772, 183);
            this.textBoxSPAJEditPengajuanPruCCAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruCCAmnt.Name = "textBoxSPAJEditPengajuanPruCCAmnt";
            this.textBoxSPAJEditPengajuanPruCCAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruCCAmnt.TabIndex = 28;
            this.textBoxSPAJEditPengajuanPruCCAmnt.Text = "0.00";
            this.textBoxSPAJEditPengajuanPruCCAmnt.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPruCCAmnt_TextChanged);
            // 
            // textBoxSPAJEditPengajuanPruPayorAmnt
            // 
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Enabled = false;
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Location = new System.Drawing.Point(772, 127);
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Name = "textBoxSPAJEditPengajuanPruPayorAmnt";
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Size = new System.Drawing.Size(196, 31);
            this.textBoxSPAJEditPengajuanPruPayorAmnt.TabIndex = 27;
            this.textBoxSPAJEditPengajuanPruPayorAmnt.Text = "0.00";
            this.textBoxSPAJEditPengajuanPruPayorAmnt.TextChanged += new System.EventHandler(this.textBoxSPAJEditPengajuanPruPayorAmnt_TextChanged);
            // 
            // checkBoxSPAJEditPengajuanPruPPayor
            // 
            this.checkBoxSPAJEditPengajuanPruPPayor.AutoSize = true;
            this.checkBoxSPAJEditPengajuanPruPPayor.Location = new System.Drawing.Point(550, 340);
            this.checkBoxSPAJEditPengajuanPruPPayor.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanPruPPayor.Name = "checkBoxSPAJEditPengajuanPruPPayor";
            this.checkBoxSPAJEditPengajuanPruPPayor.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanPruPPayor.TabIndex = 22;
            this.checkBoxSPAJEditPengajuanPruPPayor.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanPruPPayor.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanPruPPayor_CheckedChanged);
            // 
            // checkBoxSPAJEditPengajuanPRUMed
            // 
            this.checkBoxSPAJEditPengajuanPRUMed.AutoSize = true;
            this.checkBoxSPAJEditPengajuanPRUMed.Location = new System.Drawing.Point(550, 287);
            this.checkBoxSPAJEditPengajuanPRUMed.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanPRUMed.Name = "checkBoxSPAJEditPengajuanPRUMed";
            this.checkBoxSPAJEditPengajuanPRUMed.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanPRUMed.TabIndex = 21;
            this.checkBoxSPAJEditPengajuanPRUMed.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanPRUMed.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanPRUMed_CheckedChanged);
            // 
            // checkBoxSPAJEditPengajuanADD
            // 
            this.checkBoxSPAJEditPengajuanADD.AutoSize = true;
            this.checkBoxSPAJEditPengajuanADD.Location = new System.Drawing.Point(550, 240);
            this.checkBoxSPAJEditPengajuanADD.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanADD.Name = "checkBoxSPAJEditPengajuanADD";
            this.checkBoxSPAJEditPengajuanADD.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanADD.TabIndex = 20;
            this.checkBoxSPAJEditPengajuanADD.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanADD.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanADD_CheckedChanged);
            // 
            // checkBoxSPAJEditPengajuanPruCC
            // 
            this.checkBoxSPAJEditPengajuanPruCC.AutoSize = true;
            this.checkBoxSPAJEditPengajuanPruCC.Location = new System.Drawing.Point(550, 188);
            this.checkBoxSPAJEditPengajuanPruCC.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanPruCC.Name = "checkBoxSPAJEditPengajuanPruCC";
            this.checkBoxSPAJEditPengajuanPruCC.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanPruCC.TabIndex = 19;
            this.checkBoxSPAJEditPengajuanPruCC.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanPruCC.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanPruCC_CheckedChanged);
            // 
            // checkBoxSPAJEditPengajuanPruPayor
            // 
            this.checkBoxSPAJEditPengajuanPruPayor.AutoSize = true;
            this.checkBoxSPAJEditPengajuanPruPayor.Location = new System.Drawing.Point(550, 133);
            this.checkBoxSPAJEditPengajuanPruPayor.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanPruPayor.Name = "checkBoxSPAJEditPengajuanPruPayor";
            this.checkBoxSPAJEditPengajuanPruPayor.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanPruPayor.TabIndex = 17;
            this.checkBoxSPAJEditPengajuanPruPayor.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanPruPayor.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanPruPayor_CheckedChanged);
            // 
            // checkBoxSPAJEditPengajuanPruHosp
            // 
            this.checkBoxSPAJEditPengajuanPruHosp.AutoSize = true;
            this.checkBoxSPAJEditPengajuanPruHosp.Location = new System.Drawing.Point(550, 71);
            this.checkBoxSPAJEditPengajuanPruHosp.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditPengajuanPruHosp.Name = "checkBoxSPAJEditPengajuanPruHosp";
            this.checkBoxSPAJEditPengajuanPruHosp.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditPengajuanPruHosp.TabIndex = 16;
            this.checkBoxSPAJEditPengajuanPruHosp.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditPengajuanPruHosp.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditPengajuanPruHosp_CheckedChanged);
            // 
            // comboBoxSPAJEditPengajuanCurrency
            // 
            this.comboBoxSPAJEditPengajuanCurrency.FormattingEnabled = true;
            this.comboBoxSPAJEditPengajuanCurrency.Items.AddRange(new object[] {
            "Rupiah",
            "USD"});
            this.comboBoxSPAJEditPengajuanCurrency.Location = new System.Drawing.Point(310, 277);
            this.comboBoxSPAJEditPengajuanCurrency.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditPengajuanCurrency.Name = "comboBoxSPAJEditPengajuanCurrency";
            this.comboBoxSPAJEditPengajuanCurrency.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJEditPengajuanCurrency.TabIndex = 12;
            this.comboBoxSPAJEditPengajuanCurrency.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJEditPengajuanCurrency_SelectedIndexChanged);
            // 
            // comboBoxSPAJEditPengajuanPay
            // 
            this.comboBoxSPAJEditPengajuanPay.FormattingEnabled = true;
            this.comboBoxSPAJEditPengajuanPay.Items.AddRange(new object[] {
            "Credit Card",
            "Bank Transfer",
            "Other"});
            this.comboBoxSPAJEditPengajuanPay.Location = new System.Drawing.Point(308, 144);
            this.comboBoxSPAJEditPengajuanPay.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditPengajuanPay.Name = "comboBoxSPAJEditPengajuanPay";
            this.comboBoxSPAJEditPengajuanPay.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJEditPengajuanPay.TabIndex = 11;
            this.comboBoxSPAJEditPengajuanPay.TextUpdate += new System.EventHandler(this.comboBoxSPAJEditPengajuanPay_TextUpdate);
            // 
            // comboBoxSPAJEditPengajuanFreq
            // 
            this.comboBoxSPAJEditPengajuanFreq.FormattingEnabled = true;
            this.comboBoxSPAJEditPengajuanFreq.Items.AddRange(new object[] {
            "Yearly (Tahunan)",
            "Half Yearly (Semesteran)",
            "Quarterly (3 Bulan)",
            "Monthly (Bulanan)",
            "Berkala",
            "Tunggal"});
            this.comboBoxSPAJEditPengajuanFreq.Location = new System.Drawing.Point(308, 102);
            this.comboBoxSPAJEditPengajuanFreq.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditPengajuanFreq.Name = "comboBoxSPAJEditPengajuanFreq";
            this.comboBoxSPAJEditPengajuanFreq.Size = new System.Drawing.Size(208, 33);
            this.comboBoxSPAJEditPengajuanFreq.TabIndex = 10;
            this.comboBoxSPAJEditPengajuanFreq.SelectedIndexChanged += new System.EventHandler(this.comboBoxSPAJEditPengajuanFreq_SelectedIndexChanged);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(304, 371);
            this.label119.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(216, 50);
            this.label119.TabIndex = 9;
            this.label119.Text = "Uang Pertanggungan\r\n (per thn.)";
            // 
            // labelSPAJEditPengajuanExRate
            // 
            this.labelSPAJEditPengajuanExRate.AutoSize = true;
            this.labelSPAJEditPengajuanExRate.Enabled = false;
            this.labelSPAJEditPengajuanExRate.Location = new System.Drawing.Point(100, 342);
            this.labelSPAJEditPengajuanExRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJEditPengajuanExRate.Name = "labelSPAJEditPengajuanExRate";
            this.labelSPAJEditPengajuanExRate.Size = new System.Drawing.Size(165, 25);
            this.labelSPAJEditPengajuanExRate.TabIndex = 8;
            this.labelSPAJEditPengajuanExRate.Text = "Exchange Rate:";
            // 
            // labelSPAJEditPengajuanCCExpDate
            // 
            this.labelSPAJEditPengajuanCCExpDate.AutoSize = true;
            this.labelSPAJEditPengajuanCCExpDate.Enabled = false;
            this.labelSPAJEditPengajuanCCExpDate.Location = new System.Drawing.Point(100, 240);
            this.labelSPAJEditPengajuanCCExpDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJEditPengajuanCCExpDate.Name = "labelSPAJEditPengajuanCCExpDate";
            this.labelSPAJEditPengajuanCCExpDate.Size = new System.Drawing.Size(112, 25);
            this.labelSPAJEditPengajuanCCExpDate.TabIndex = 7;
            this.labelSPAJEditPengajuanCCExpDate.Text = "Exp. Date:";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(544, 38);
            this.label122.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(153, 25);
            this.label122.TabIndex = 6;
            this.label122.Text = "E. Additional ";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(36, 385);
            this.label123.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(100, 25);
            this.label123.TabIndex = 5;
            this.label123.Text = "D. Basic";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(36, 288);
            this.label124.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(137, 25);
            this.label124.TabIndex = 4;
            this.label124.Text = "C. Currency";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(36, 144);
            this.label125.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(217, 25);
            this.label125.TabIndex = 3;
            this.label125.Text = "B. Payment Method";
            // 
            // labelSPAJEditPengajuanCCBankOther
            // 
            this.labelSPAJEditPengajuanCCBankOther.AutoSize = true;
            this.labelSPAJEditPengajuanCCBankOther.Enabled = false;
            this.labelSPAJEditPengajuanCCBankOther.Location = new System.Drawing.Point(100, 190);
            this.labelSPAJEditPengajuanCCBankOther.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSPAJEditPengajuanCCBankOther.Name = "labelSPAJEditPengajuanCCBankOther";
            this.labelSPAJEditPengajuanCCBankOther.Size = new System.Drawing.Size(177, 25);
            this.labelSPAJEditPengajuanCCBankOther.TabIndex = 2;
            this.labelSPAJEditPengajuanCCBankOther.Text = "Credit Card Num:";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(36, 102);
            this.label127.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(250, 25);
            this.label127.TabIndex = 1;
            this.label127.Text = "A. Payment Frequency";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label128.Location = new System.Drawing.Point(40, 31);
            this.label128.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(256, 37);
            this.label128.TabIndex = 0;
            this.label128.Text = "Pengajuan Info ";
            // 
            // tabPageEditBeneficiaryInfo
            // 
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.buttonBeneficiaryEdit);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.button21);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.comboBoxSPAJEditBeneficiaryRs1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.dateTimeSPAJEditBeneficiary1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary6);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary5);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary4);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary3);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryDetail2);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryLName1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.textBoxSPAJEditBeneficiaryFName1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.checkBoxSPAJEditBeneficiary1);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label129);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label130);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label131);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label132);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label133);
            this.tabPageEditBeneficiaryInfo.Controls.Add(this.label134);
            this.tabPageEditBeneficiaryInfo.Location = new System.Drawing.Point(8, 39);
            this.tabPageEditBeneficiaryInfo.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageEditBeneficiaryInfo.Name = "tabPageEditBeneficiaryInfo";
            this.tabPageEditBeneficiaryInfo.Size = new System.Drawing.Size(1000, 630);
            this.tabPageEditBeneficiaryInfo.TabIndex = 8;
            this.tabPageEditBeneficiaryInfo.Text = "Beneficiary";
            this.tabPageEditBeneficiaryInfo.UseVisualStyleBackColor = true;
            // 
            // buttonBeneficiaryEdit
            // 
            this.buttonBeneficiaryEdit.Location = new System.Drawing.Point(548, 546);
            this.buttonBeneficiaryEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBeneficiaryEdit.Name = "buttonBeneficiaryEdit";
            this.buttonBeneficiaryEdit.Size = new System.Drawing.Size(120, 48);
            this.buttonBeneficiaryEdit.TabIndex = 45;
            this.buttonBeneficiaryEdit.Text = "Accept";
            this.buttonBeneficiaryEdit.UseVisualStyleBackColor = true;
            this.buttonBeneficiaryEdit.Click += new System.EventHandler(this.buttonBeneficiaryEdit_Click);
            // 
            // button21
            // 
            this.button21.Enabled = false;
            this.button21.Location = new System.Drawing.Point(356, 546);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(120, 48);
            this.button21.TabIndex = 44;
            this.button21.Text = "Clear";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // comboBoxSPAJEditBeneficiaryRs6
            // 
            this.comboBoxSPAJEditBeneficiaryRs6.Enabled = false;
            this.comboBoxSPAJEditBeneficiaryRs6.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs6.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs6.Location = new System.Drawing.Point(676, 477);
            this.comboBoxSPAJEditBeneficiaryRs6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs6.Name = "comboBoxSPAJEditBeneficiaryRs6";
            this.comboBoxSPAJEditBeneficiaryRs6.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs6.TabIndex = 43;
            // 
            // comboBoxSPAJEditBeneficiaryRs5
            // 
            this.comboBoxSPAJEditBeneficiaryRs5.Enabled = false;
            this.comboBoxSPAJEditBeneficiaryRs5.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs5.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs5.Location = new System.Drawing.Point(676, 404);
            this.comboBoxSPAJEditBeneficiaryRs5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs5.Name = "comboBoxSPAJEditBeneficiaryRs5";
            this.comboBoxSPAJEditBeneficiaryRs5.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs5.TabIndex = 42;
            // 
            // comboBoxSPAJEditBeneficiaryRs4
            // 
            this.comboBoxSPAJEditBeneficiaryRs4.Enabled = false;
            this.comboBoxSPAJEditBeneficiaryRs4.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs4.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs4.Location = new System.Drawing.Point(676, 340);
            this.comboBoxSPAJEditBeneficiaryRs4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs4.Name = "comboBoxSPAJEditBeneficiaryRs4";
            this.comboBoxSPAJEditBeneficiaryRs4.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs4.TabIndex = 41;
            // 
            // comboBoxSPAJEditBeneficiaryRs3
            // 
            this.comboBoxSPAJEditBeneficiaryRs3.Enabled = false;
            this.comboBoxSPAJEditBeneficiaryRs3.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs3.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs3.Location = new System.Drawing.Point(676, 277);
            this.comboBoxSPAJEditBeneficiaryRs3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs3.Name = "comboBoxSPAJEditBeneficiaryRs3";
            this.comboBoxSPAJEditBeneficiaryRs3.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs3.TabIndex = 40;
            // 
            // comboBoxSPAJEditBeneficiaryRs2
            // 
            this.comboBoxSPAJEditBeneficiaryRs2.Enabled = false;
            this.comboBoxSPAJEditBeneficiaryRs2.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs2.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs2.Location = new System.Drawing.Point(676, 204);
            this.comboBoxSPAJEditBeneficiaryRs2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs2.Name = "comboBoxSPAJEditBeneficiaryRs2";
            this.comboBoxSPAJEditBeneficiaryRs2.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs2.TabIndex = 39;
            // 
            // comboBoxSPAJEditBeneficiaryRs1
            // 
            this.comboBoxSPAJEditBeneficiaryRs1.FormattingEnabled = true;
            this.comboBoxSPAJEditBeneficiaryRs1.Items.AddRange(new object[] {
            "Sibling ",
            "Child",
            "Father",
            "Mother",
            "Spouse",
            "Other"});
            this.comboBoxSPAJEditBeneficiaryRs1.Location = new System.Drawing.Point(676, 133);
            this.comboBoxSPAJEditBeneficiaryRs1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxSPAJEditBeneficiaryRs1.Name = "comboBoxSPAJEditBeneficiaryRs1";
            this.comboBoxSPAJEditBeneficiaryRs1.Size = new System.Drawing.Size(148, 33);
            this.comboBoxSPAJEditBeneficiaryRs1.TabIndex = 38;
            // 
            // dateTimeSPAJEditBeneficiary6
            // 
            this.dateTimeSPAJEditBeneficiary6.Enabled = false;
            this.dateTimeSPAJEditBeneficiary6.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary6.Location = new System.Drawing.Point(468, 473);
            this.dateTimeSPAJEditBeneficiary6.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary6.Name = "dateTimeSPAJEditBeneficiary6";
            this.dateTimeSPAJEditBeneficiary6.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary6.TabIndex = 37;
            // 
            // dateTimeSPAJEditBeneficiary5
            // 
            this.dateTimeSPAJEditBeneficiary5.Enabled = false;
            this.dateTimeSPAJEditBeneficiary5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary5.Location = new System.Drawing.Point(468, 406);
            this.dateTimeSPAJEditBeneficiary5.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary5.Name = "dateTimeSPAJEditBeneficiary5";
            this.dateTimeSPAJEditBeneficiary5.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary5.TabIndex = 36;
            // 
            // dateTimeSPAJEditBeneficiary4
            // 
            this.dateTimeSPAJEditBeneficiary4.Enabled = false;
            this.dateTimeSPAJEditBeneficiary4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary4.Location = new System.Drawing.Point(468, 340);
            this.dateTimeSPAJEditBeneficiary4.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary4.Name = "dateTimeSPAJEditBeneficiary4";
            this.dateTimeSPAJEditBeneficiary4.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary4.TabIndex = 35;
            // 
            // dateTimeSPAJEditBeneficiary3
            // 
            this.dateTimeSPAJEditBeneficiary3.Enabled = false;
            this.dateTimeSPAJEditBeneficiary3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary3.Location = new System.Drawing.Point(468, 279);
            this.dateTimeSPAJEditBeneficiary3.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary3.Name = "dateTimeSPAJEditBeneficiary3";
            this.dateTimeSPAJEditBeneficiary3.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary3.TabIndex = 34;
            // 
            // dateTimeSPAJEditBeneficiary2
            // 
            this.dateTimeSPAJEditBeneficiary2.Enabled = false;
            this.dateTimeSPAJEditBeneficiary2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary2.Location = new System.Drawing.Point(468, 206);
            this.dateTimeSPAJEditBeneficiary2.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary2.Name = "dateTimeSPAJEditBeneficiary2";
            this.dateTimeSPAJEditBeneficiary2.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary2.TabIndex = 33;
            // 
            // dateTimeSPAJEditBeneficiary1
            // 
            this.dateTimeSPAJEditBeneficiary1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeSPAJEditBeneficiary1.Location = new System.Drawing.Point(468, 129);
            this.dateTimeSPAJEditBeneficiary1.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimeSPAJEditBeneficiary1.Name = "dateTimeSPAJEditBeneficiary1";
            this.dateTimeSPAJEditBeneficiary1.Size = new System.Drawing.Size(172, 31);
            this.dateTimeSPAJEditBeneficiary1.TabIndex = 32;
            // 
            // textBoxSPAJEditBeneficiaryDetail6
            // 
            this.textBoxSPAJEditBeneficiaryDetail6.Enabled = false;
            this.textBoxSPAJEditBeneficiaryDetail6.Location = new System.Drawing.Point(864, 477);
            this.textBoxSPAJEditBeneficiaryDetail6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail6.Name = "textBoxSPAJEditBeneficiaryDetail6";
            this.textBoxSPAJEditBeneficiaryDetail6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail6.TabIndex = 31;
            // 
            // textBoxSPAJEditBeneficiaryDetail5
            // 
            this.textBoxSPAJEditBeneficiaryDetail5.Location = new System.Drawing.Point(864, 408);
            this.textBoxSPAJEditBeneficiaryDetail5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail5.Name = "textBoxSPAJEditBeneficiaryDetail5";
            this.textBoxSPAJEditBeneficiaryDetail5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail5.TabIndex = 30;
            // 
            // textBoxSPAJEditBeneficiaryDetail4
            // 
            this.textBoxSPAJEditBeneficiaryDetail4.Enabled = false;
            this.textBoxSPAJEditBeneficiaryDetail4.Location = new System.Drawing.Point(864, 342);
            this.textBoxSPAJEditBeneficiaryDetail4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail4.Name = "textBoxSPAJEditBeneficiaryDetail4";
            this.textBoxSPAJEditBeneficiaryDetail4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail4.TabIndex = 29;
            // 
            // textBoxSPAJEditBeneficiaryDetail3
            // 
            this.textBoxSPAJEditBeneficiaryDetail3.Enabled = false;
            this.textBoxSPAJEditBeneficiaryDetail3.Location = new System.Drawing.Point(864, 277);
            this.textBoxSPAJEditBeneficiaryDetail3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail3.Name = "textBoxSPAJEditBeneficiaryDetail3";
            this.textBoxSPAJEditBeneficiaryDetail3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail3.TabIndex = 28;
            // 
            // textBoxSPAJEditBeneficiaryLName6
            // 
            this.textBoxSPAJEditBeneficiaryLName6.Enabled = false;
            this.textBoxSPAJEditBeneficiaryLName6.Location = new System.Drawing.Point(284, 473);
            this.textBoxSPAJEditBeneficiaryLName6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName6.Name = "textBoxSPAJEditBeneficiaryLName6";
            this.textBoxSPAJEditBeneficiaryLName6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName6.TabIndex = 27;
            // 
            // textBoxSPAJEditBeneficiaryLName5
            // 
            this.textBoxSPAJEditBeneficiaryLName5.Enabled = false;
            this.textBoxSPAJEditBeneficiaryLName5.Location = new System.Drawing.Point(284, 406);
            this.textBoxSPAJEditBeneficiaryLName5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName5.Name = "textBoxSPAJEditBeneficiaryLName5";
            this.textBoxSPAJEditBeneficiaryLName5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName5.TabIndex = 26;
            // 
            // textBoxSPAJEditBeneficiaryLName4
            // 
            this.textBoxSPAJEditBeneficiaryLName4.Enabled = false;
            this.textBoxSPAJEditBeneficiaryLName4.Location = new System.Drawing.Point(284, 340);
            this.textBoxSPAJEditBeneficiaryLName4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName4.Name = "textBoxSPAJEditBeneficiaryLName4";
            this.textBoxSPAJEditBeneficiaryLName4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName4.TabIndex = 25;
            // 
            // textBoxSPAJEditBeneficiaryLName3
            // 
            this.textBoxSPAJEditBeneficiaryLName3.Enabled = false;
            this.textBoxSPAJEditBeneficiaryLName3.Location = new System.Drawing.Point(284, 279);
            this.textBoxSPAJEditBeneficiaryLName3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName3.Name = "textBoxSPAJEditBeneficiaryLName3";
            this.textBoxSPAJEditBeneficiaryLName3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName3.TabIndex = 24;
            // 
            // textBoxSPAJEditBeneficiaryLName2
            // 
            this.textBoxSPAJEditBeneficiaryLName2.Enabled = false;
            this.textBoxSPAJEditBeneficiaryLName2.Location = new System.Drawing.Point(284, 206);
            this.textBoxSPAJEditBeneficiaryLName2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName2.Name = "textBoxSPAJEditBeneficiaryLName2";
            this.textBoxSPAJEditBeneficiaryLName2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName2.TabIndex = 23;
            // 
            // textBoxSPAJEditBeneficiaryFName6
            // 
            this.textBoxSPAJEditBeneficiaryFName6.Enabled = false;
            this.textBoxSPAJEditBeneficiaryFName6.Location = new System.Drawing.Point(98, 473);
            this.textBoxSPAJEditBeneficiaryFName6.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName6.Name = "textBoxSPAJEditBeneficiaryFName6";
            this.textBoxSPAJEditBeneficiaryFName6.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName6.TabIndex = 22;
            // 
            // textBoxSPAJEditBeneficiaryFName5
            // 
            this.textBoxSPAJEditBeneficiaryFName5.Enabled = false;
            this.textBoxSPAJEditBeneficiaryFName5.Location = new System.Drawing.Point(98, 400);
            this.textBoxSPAJEditBeneficiaryFName5.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName5.Name = "textBoxSPAJEditBeneficiaryFName5";
            this.textBoxSPAJEditBeneficiaryFName5.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName5.TabIndex = 21;
            // 
            // textBoxSPAJEditBeneficiaryFName4
            // 
            this.textBoxSPAJEditBeneficiaryFName4.Enabled = false;
            this.textBoxSPAJEditBeneficiaryFName4.Location = new System.Drawing.Point(98, 340);
            this.textBoxSPAJEditBeneficiaryFName4.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName4.Name = "textBoxSPAJEditBeneficiaryFName4";
            this.textBoxSPAJEditBeneficiaryFName4.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName4.TabIndex = 20;
            // 
            // textBoxSPAJEditBeneficiaryFName3
            // 
            this.textBoxSPAJEditBeneficiaryFName3.Enabled = false;
            this.textBoxSPAJEditBeneficiaryFName3.Location = new System.Drawing.Point(98, 279);
            this.textBoxSPAJEditBeneficiaryFName3.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName3.Name = "textBoxSPAJEditBeneficiaryFName3";
            this.textBoxSPAJEditBeneficiaryFName3.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName3.TabIndex = 19;
            // 
            // checkBoxSPAJEditBeneficiary6
            // 
            this.checkBoxSPAJEditBeneficiary6.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary6.Location = new System.Drawing.Point(46, 477);
            this.checkBoxSPAJEditBeneficiary6.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary6.Name = "checkBoxSPAJEditBeneficiary6";
            this.checkBoxSPAJEditBeneficiary6.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary6.TabIndex = 18;
            this.checkBoxSPAJEditBeneficiary6.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary6.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary6_CheckedChanged);
            // 
            // checkBoxSPAJEditBeneficiary5
            // 
            this.checkBoxSPAJEditBeneficiary5.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary5.Location = new System.Drawing.Point(46, 406);
            this.checkBoxSPAJEditBeneficiary5.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary5.Name = "checkBoxSPAJEditBeneficiary5";
            this.checkBoxSPAJEditBeneficiary5.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary5.TabIndex = 17;
            this.checkBoxSPAJEditBeneficiary5.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary5.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary5_CheckedChanged);
            // 
            // checkBoxSPAJEditBeneficiary4
            // 
            this.checkBoxSPAJEditBeneficiary4.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary4.Location = new System.Drawing.Point(46, 340);
            this.checkBoxSPAJEditBeneficiary4.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary4.Name = "checkBoxSPAJEditBeneficiary4";
            this.checkBoxSPAJEditBeneficiary4.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary4.TabIndex = 16;
            this.checkBoxSPAJEditBeneficiary4.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary4.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary4_CheckedChanged);
            // 
            // checkBoxSPAJEditBeneficiary3
            // 
            this.checkBoxSPAJEditBeneficiary3.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary3.Location = new System.Drawing.Point(46, 279);
            this.checkBoxSPAJEditBeneficiary3.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary3.Name = "checkBoxSPAJEditBeneficiary3";
            this.checkBoxSPAJEditBeneficiary3.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary3.TabIndex = 15;
            this.checkBoxSPAJEditBeneficiary3.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary3.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary3_CheckedChanged);
            // 
            // checkBoxSPAJEditBeneficiary2
            // 
            this.checkBoxSPAJEditBeneficiary2.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary2.Location = new System.Drawing.Point(46, 204);
            this.checkBoxSPAJEditBeneficiary2.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary2.Name = "checkBoxSPAJEditBeneficiary2";
            this.checkBoxSPAJEditBeneficiary2.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary2.TabIndex = 14;
            this.checkBoxSPAJEditBeneficiary2.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary2.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary2_CheckedChanged);
            // 
            // textBoxSPAJEditBeneficiaryDetail1
            // 
            this.textBoxSPAJEditBeneficiaryDetail1.Location = new System.Drawing.Point(864, 129);
            this.textBoxSPAJEditBeneficiaryDetail1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail1.Name = "textBoxSPAJEditBeneficiaryDetail1";
            this.textBoxSPAJEditBeneficiaryDetail1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail1.TabIndex = 13;
            // 
            // textBoxSPAJEditBeneficiaryFName2
            // 
            this.textBoxSPAJEditBeneficiaryFName2.Enabled = false;
            this.textBoxSPAJEditBeneficiaryFName2.Location = new System.Drawing.Point(98, 204);
            this.textBoxSPAJEditBeneficiaryFName2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName2.Name = "textBoxSPAJEditBeneficiaryFName2";
            this.textBoxSPAJEditBeneficiaryFName2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName2.TabIndex = 12;
            // 
            // textBoxSPAJEditBeneficiaryDetail2
            // 
            this.textBoxSPAJEditBeneficiaryDetail2.Enabled = false;
            this.textBoxSPAJEditBeneficiaryDetail2.Location = new System.Drawing.Point(864, 206);
            this.textBoxSPAJEditBeneficiaryDetail2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryDetail2.Name = "textBoxSPAJEditBeneficiaryDetail2";
            this.textBoxSPAJEditBeneficiaryDetail2.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryDetail2.TabIndex = 11;
            // 
            // textBoxSPAJEditBeneficiaryLName1
            // 
            this.textBoxSPAJEditBeneficiaryLName1.Location = new System.Drawing.Point(284, 129);
            this.textBoxSPAJEditBeneficiaryLName1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryLName1.Name = "textBoxSPAJEditBeneficiaryLName1";
            this.textBoxSPAJEditBeneficiaryLName1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryLName1.TabIndex = 10;
            // 
            // textBoxSPAJEditBeneficiaryFName1
            // 
            this.textBoxSPAJEditBeneficiaryFName1.Location = new System.Drawing.Point(98, 129);
            this.textBoxSPAJEditBeneficiaryFName1.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditBeneficiaryFName1.Name = "textBoxSPAJEditBeneficiaryFName1";
            this.textBoxSPAJEditBeneficiaryFName1.Size = new System.Drawing.Size(132, 31);
            this.textBoxSPAJEditBeneficiaryFName1.TabIndex = 9;
            // 
            // checkBoxSPAJEditBeneficiary1
            // 
            this.checkBoxSPAJEditBeneficiary1.AutoSize = true;
            this.checkBoxSPAJEditBeneficiary1.Location = new System.Drawing.Point(46, 133);
            this.checkBoxSPAJEditBeneficiary1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSPAJEditBeneficiary1.Name = "checkBoxSPAJEditBeneficiary1";
            this.checkBoxSPAJEditBeneficiary1.Size = new System.Drawing.Size(28, 27);
            this.checkBoxSPAJEditBeneficiary1.TabIndex = 8;
            this.checkBoxSPAJEditBeneficiary1.UseVisualStyleBackColor = true;
            this.checkBoxSPAJEditBeneficiary1.CheckedChanged += new System.EventHandler(this.checkBoxSPAJEditBeneficiary1_CheckedChanged);
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(888, 77);
            this.label129.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(78, 25);
            this.label129.TabIndex = 7;
            this.label129.Text = "Details";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(672, 77);
            this.label130.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(131, 25);
            this.label130.TabIndex = 6;
            this.label130.Text = "Relationship";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(490, 77);
            this.label131.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(98, 25);
            this.label131.TabIndex = 5;
            this.label131.Text = "Birthdate";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(290, 77);
            this.label132.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(115, 25);
            this.label132.TabIndex = 4;
            this.label132.Text = "Last Name";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(104, 77);
            this.label133.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(116, 25);
            this.label133.TabIndex = 3;
            this.label133.Text = "First Name";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label134.Location = new System.Drawing.Point(60, 15);
            this.label134.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(184, 37);
            this.label134.TabIndex = 2;
            this.label134.Text = "Beneficiary";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(32, 375);
            this.label135.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(116, 50);
            this.label135.TabIndex = 6;
            this.label135.Text = "PRU Flyer \r\nNumber:";
            // 
            // textBoxSPAJEditANumber
            // 
            this.textBoxSPAJEditANumber.Location = new System.Drawing.Point(204, 313);
            this.textBoxSPAJEditANumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditANumber.Name = "textBoxSPAJEditANumber";
            this.textBoxSPAJEditANumber.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJEditANumber.TabIndex = 10;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(36, 90);
            this.label136.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(99, 50);
            this.label136.TabIndex = 3;
            this.label136.Text = "SPAJ \r\nNumber: ";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label137.Location = new System.Drawing.Point(106, 25);
            this.label137.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(170, 37);
            this.label137.TabIndex = 1;
            this.label137.Text = "Edit SPAJ";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(32, 315);
            this.label138.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(155, 25);
            this.label138.TabIndex = 5;
            this.label138.Text = "Agent Number:";
            // 
            // textBoxSPAJEditAName
            // 
            this.textBoxSPAJEditAName.Location = new System.Drawing.Point(204, 238);
            this.textBoxSPAJEditAName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditAName.Name = "textBoxSPAJEditAName";
            this.textBoxSPAJEditAName.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJEditAName.TabIndex = 9;
            // 
            // textBoxSPAJEditNumber
            // 
            this.textBoxSPAJEditNumber.Location = new System.Drawing.Point(144, 106);
            this.textBoxSPAJEditNumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJEditNumber.Name = "textBoxSPAJEditNumber";
            this.textBoxSPAJEditNumber.Size = new System.Drawing.Size(186, 31);
            this.textBoxSPAJEditNumber.TabIndex = 8;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(36, 244);
            this.label139.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(136, 25);
            this.label139.TabIndex = 4;
            this.label139.Text = "Agent Name:";
            // 
            // tabPageSPAJDelete
            // 
            this.tabPageSPAJDelete.Controls.Add(this.label120);
            this.tabPageSPAJDelete.Controls.Add(this.buttonSPAJDeleteDelete);
            this.tabPageSPAJDelete.Controls.Add(this.buttonSPAJDeleteClear);
            this.tabPageSPAJDelete.Controls.Add(this.buttonSPAJDeleteCheck);
            this.tabPageSPAJDelete.Controls.Add(this.textBoxSPAJDeleteNum);
            this.tabPageSPAJDelete.Controls.Add(this.label149);
            this.tabPageSPAJDelete.Location = new System.Drawing.Point(8, 39);
            this.tabPageSPAJDelete.Margin = new System.Windows.Forms.Padding(4);
            this.tabPageSPAJDelete.Name = "tabPageSPAJDelete";
            this.tabPageSPAJDelete.Size = new System.Drawing.Size(1488, 678);
            this.tabPageSPAJDelete.TabIndex = 4;
            this.tabPageSPAJDelete.Text = "Delete SPAJ";
            this.tabPageSPAJDelete.UseVisualStyleBackColor = true;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(547, 123);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(87, 25);
            this.label120.TabIndex = 16;
            this.label120.Text = "Number";
            // 
            // buttonSPAJDeleteDelete
            // 
            this.buttonSPAJDeleteDelete.Enabled = false;
            this.buttonSPAJDeleteDelete.Location = new System.Drawing.Point(810, 208);
            this.buttonSPAJDeleteDelete.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJDeleteDelete.Name = "buttonSPAJDeleteDelete";
            this.buttonSPAJDeleteDelete.Size = new System.Drawing.Size(124, 38);
            this.buttonSPAJDeleteDelete.TabIndex = 15;
            this.buttonSPAJDeleteDelete.Text = "Delete";
            this.buttonSPAJDeleteDelete.UseVisualStyleBackColor = true;
            this.buttonSPAJDeleteDelete.Click += new System.EventHandler(this.buttonSPAJDeleteDelete_Click);
            // 
            // buttonSPAJDeleteClear
            // 
            this.buttonSPAJDeleteClear.Location = new System.Drawing.Point(630, 208);
            this.buttonSPAJDeleteClear.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJDeleteClear.Name = "buttonSPAJDeleteClear";
            this.buttonSPAJDeleteClear.Size = new System.Drawing.Size(124, 38);
            this.buttonSPAJDeleteClear.TabIndex = 14;
            this.buttonSPAJDeleteClear.Text = "Clear";
            this.buttonSPAJDeleteClear.UseVisualStyleBackColor = true;
            // 
            // buttonSPAJDeleteCheck
            // 
            this.buttonSPAJDeleteCheck.Location = new System.Drawing.Point(940, 123);
            this.buttonSPAJDeleteCheck.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJDeleteCheck.Name = "buttonSPAJDeleteCheck";
            this.buttonSPAJDeleteCheck.Size = new System.Drawing.Size(116, 38);
            this.buttonSPAJDeleteCheck.TabIndex = 13;
            this.buttonSPAJDeleteCheck.Text = "Check";
            this.buttonSPAJDeleteCheck.UseVisualStyleBackColor = true;
            this.buttonSPAJDeleteCheck.Click += new System.EventHandler(this.buttonSPAJDeleteCheck_Click);
            // 
            // textBoxSPAJDeleteNum
            // 
            this.textBoxSPAJDeleteNum.Location = new System.Drawing.Point(688, 123);
            this.textBoxSPAJDeleteNum.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSPAJDeleteNum.Name = "textBoxSPAJDeleteNum";
            this.textBoxSPAJDeleteNum.Size = new System.Drawing.Size(216, 31);
            this.textBoxSPAJDeleteNum.TabIndex = 12;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label149.Location = new System.Drawing.Point(686, 46);
            this.label149.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(207, 37);
            this.label149.TabIndex = 10;
            this.label149.Text = "Delete SPAJ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(550, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(456, 37);
            this.label1.TabIndex = 9;
            this.label1.Text = "Agency Management System";
            // 
            // buttonSPAJClearBackMenu
            // 
            this.buttonSPAJClearBackMenu.Location = new System.Drawing.Point(2, -2);
            this.buttonSPAJClearBackMenu.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSPAJClearBackMenu.Name = "buttonSPAJClearBackMenu";
            this.buttonSPAJClearBackMenu.Size = new System.Drawing.Size(174, 44);
            this.buttonSPAJClearBackMenu.TabIndex = 10;
            this.buttonSPAJClearBackMenu.Text = "Back to Menu ";
            this.buttonSPAJClearBackMenu.UseVisualStyleBackColor = true;
            this.buttonSPAJClearBackMenu.Click += new System.EventHandler(this.buttonSPAJClearBackMenu_Click);
            // 
            // buttonSPAJPengajuanNext
            // 
            this.buttonSPAJPengajuanNext.Location = new System.Drawing.Point(400, 543);
            this.buttonSPAJPengajuanNext.Name = "buttonSPAJPengajuanNext";
            this.buttonSPAJPengajuanNext.Size = new System.Drawing.Size(120, 43);
            this.buttonSPAJPengajuanNext.TabIndex = 54;
            this.buttonSPAJPengajuanNext.Text = "Next";
            this.buttonSPAJPengajuanNext.UseVisualStyleBackColor = true;
            this.buttonSPAJPengajuanNext.Click += new System.EventHandler(this.buttonSPAJPengajuanSave_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1514, 790);
            this.Controls.Add(this.buttonSPAJClearBackMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControlSPAJ);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = " ";
            this.tabControlSPAJ.ResumeLayout(false);
            this.tabPageSPAJUpdate.ResumeLayout(false);
            this.tabPageSPAJUpdate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSPAJUpdate)).EndInit();
            this.tabPageSPAJAdd.ResumeLayout(false);
            this.tabPageSPAJAdd.PerformLayout();
            this.tabControlAddSPAJ.ResumeLayout(false);
            this.tabPageInsInfo.ResumeLayout(false);
            this.tabPageInsInfo.PerformLayout();
            this.tabPagePolisHolder.ResumeLayout(false);
            this.tabPagePolisHolder.PerformLayout();
            this.tabPageSpouseInfo.ResumeLayout(false);
            this.tabPageSpouseInfo.PerformLayout();
            this.tabPageParentInfo.ResumeLayout(false);
            this.tabPageParentInfo.PerformLayout();
            this.tabPageAddressInfo.ResumeLayout(false);
            this.tabPageAddressInfo.PerformLayout();
            this.tabPagePengajuanInfo.ResumeLayout(false);
            this.tabPagePengajuanInfo.PerformLayout();
            this.tabPageBeneficiaryInfo.ResumeLayout(false);
            this.tabPageBeneficiaryInfo.PerformLayout();
            this.tabPageSPAJEdit.ResumeLayout(false);
            this.tabPageSPAJEdit.PerformLayout();
            this.tabControlEditSPAJ.ResumeLayout(false);
            this.tabPageEditInsInfo.ResumeLayout(false);
            this.tabPageEditInsInfo.PerformLayout();
            this.tabPageEditPolisInfo.ResumeLayout(false);
            this.tabPageEditPolisInfo.PerformLayout();
            this.tabPageEditSpouseInfo.ResumeLayout(false);
            this.tabPageEditSpouseInfo.PerformLayout();
            this.tabPageEditParentInfo.ResumeLayout(false);
            this.tabPageEditParentInfo.PerformLayout();
            this.tabPageEditAddrInfo.ResumeLayout(false);
            this.tabPageEditAddrInfo.PerformLayout();
            this.tabPageEditPengajuanInfo.ResumeLayout(false);
            this.tabPageEditPengajuanInfo.PerformLayout();
            this.tabPageEditBeneficiaryInfo.ResumeLayout(false);
            this.tabPageEditBeneficiaryInfo.PerformLayout();
            this.tabPageSPAJDelete.ResumeLayout(false);
            this.tabPageSPAJDelete.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlSPAJ;
        private System.Windows.Forms.TabPage tabPageSPAJUpdate;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TabPage tabPageSPAJAdd;
        private System.Windows.Forms.TabControl tabControlAddSPAJ;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJSubmit;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox textBoxPRUFlyerNum;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textBoxSPAJANum;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBoxSPAJNum;
        private System.Windows.Forms.TextBox textBoxSPAJAName;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TabPage tabPageInsInfo;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJInsrDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJJobClass;
        private System.Windows.Forms.ComboBox comboBoxSPAJInsrMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJInsrGender;
        private System.Windows.Forms.TextBox textBoxSPAJInsrNextBday;
        private System.Windows.Forms.RadioButton radioButtonSPAJInsrSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJInsrWeight;
        private System.Windows.Forms.TextBox textBoxSPAJInsrHeight;
        private System.Windows.Forms.TextBox textBoxSPAJInsrName;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TabPage tabPagePolisHolder;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJPolisDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJPolisRs;
        private System.Windows.Forms.ComboBox comboBoxSPAJPolisMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJPolisGender;
        private System.Windows.Forms.TextBox textBoxSPAJPolisName;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonSPAJClearBackMenu;
        private System.Windows.Forms.TabPage tabPageSpouseInfo;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJSpouseDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJSpouseMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJSpouseGender;
        private System.Windows.Forms.TextBox textBoxSPAJSpouseNextBday;
        private System.Windows.Forms.RadioButton radioButtonSPAJSpouseSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJSpouseWeight;
        private System.Windows.Forms.TextBox textBoxSPAJSpouseHeight;
        private System.Windows.Forms.TextBox textBoxSPAJSpouseName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPageAddressInfo;
        private System.Windows.Forms.TabPage tabPageParentInfo;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJParentDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJParentMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJParentGender;
        private System.Windows.Forms.TextBox textBoxSPAJParentNextBday;
        private System.Windows.Forms.RadioButton radioButtonSPAJParentSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJParentWeight;
        private System.Windows.Forms.TextBox textBoxSPAJParentHeight;
        private System.Windows.Forms.TextBox textBoxSPAJParentName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxSPAJAddrZip;
        private System.Windows.Forms.TextBox textBoxSPAJAddrCity;
        private System.Windows.Forms.TextBox textBoxSPAJAddrAddress;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxSPAJAddrOP;
        private System.Windows.Forms.TextBox textBoxSPAJAddrHP;
        private System.Windows.Forms.TextBox textBoxSPAJAddrEmail;
        private System.Windows.Forms.Button buttonSPAJNewCreate;
        private System.Windows.Forms.Button buttonSPAJNewClear;
        private System.Windows.Forms.TabPage tabPagePengajuanInfo;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label labelPengajuanCCBankOther;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label labelPengajuanCCExpDate;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label labelSPAJPengajuanExchRate;
        private System.Windows.Forms.ComboBox comboBoxSPAJPengajuanCurrency;
        private System.Windows.Forms.ComboBox comboBoxSPAJPengajuanPay;
        private System.Windows.Forms.ComboBox comboBoxSPAJPengajuanFreq;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanPruMed;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanADD;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanPruCC;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanPruPayor;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanPruHosp;
        private System.Windows.Forms.CheckBox checkBoxSPAJPengajuanPruPPayor;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPremiTotal;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruSaver;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPremi;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPrtanggung;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanExchange;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanExpDate;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanCCBank;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruPPayorAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruMedAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruADDAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruCCAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruPayorAmnt;
        private System.Windows.Forms.Button buttonInsInfoClear;
        private System.Windows.Forms.TabPage tabPageBeneficiaryInfo;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs6;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs5;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs4;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs3;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs2;
        private System.Windows.Forms.ComboBox comboBoxSPAJBeneficiaryRs1;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary6;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary5;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary4;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary3;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary2;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJBeneficiary1;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail6;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail5;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail4;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail3;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName6;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName5;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName4;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName3;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName2;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName6;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName5;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName4;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName3;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary6;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary5;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary4;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary3;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary2;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail1;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName2;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryDetail2;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryLName1;
        private System.Windows.Forms.TextBox textBoxSPAJBeneficiaryFName1;
        private System.Windows.Forms.CheckBox checkBoxSPAJBeneficiary1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button buttonInsInfoAccept;
        private System.Windows.Forms.Button buttonPolisHolderAccept;
        private System.Windows.Forms.Button buttonPolisHolderClear;
        private System.Windows.Forms.Button buttonSpouseIgnore;
        private System.Windows.Forms.Button buttonSpouseAccept;
        private System.Windows.Forms.Button buttonSpouseClear;
        private System.Windows.Forms.Button buttonParentIgnore;
        private System.Windows.Forms.Button buttonParentAccept;
        private System.Windows.Forms.Button buttonParentClear;
        private System.Windows.Forms.Button buttonAddressAccept;
        private System.Windows.Forms.Button buttonAddressClear;
        private System.Windows.Forms.Button buttonPengajuanAccept;
        private System.Windows.Forms.Button buttonPengajuanClear;
        private System.Windows.Forms.Button buttonBeneficiaryAccept;
        private System.Windows.Forms.Button buttonSPAJBeneficiaryClear;
        private System.Windows.Forms.TabPage tabPageSPAJEdit;
        private System.Windows.Forms.Button buttonSPAJEditLoad;
        private System.Windows.Forms.Button buttonSPAJEditUpdate;
        private System.Windows.Forms.Button buttonSPAJEditClear;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditSubmit;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBoxEditPruFlyerNum;
        private System.Windows.Forms.TabControl tabControlEditSPAJ;
        private System.Windows.Forms.TabPage tabPageEditInsInfo;
        private System.Windows.Forms.Button buttonInsInfoEdit;
        private System.Windows.Forms.Button buttonSPAJEditInsrClear;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditInsrDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditInsrJobClass;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditInsrMarriage;
        private System.Windows.Forms.TextBox textBoxSPAJEditInsrNextBday;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditInsrGender;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RadioButton radioButtonSPAJEditInsrSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJEditInsrWeight;
        private System.Windows.Forms.TextBox textBoxSPAJEditInsrName;
        private System.Windows.Forms.TextBox textBoxSPAJEditInsrHeight;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TabPage tabPageEditPolisInfo;
        private System.Windows.Forms.Button buttonPolisInfoEdit;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditPolisDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPolisRs;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPolisMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPolisGender;
        private System.Windows.Forms.TextBox textBoxSPAJEditPolisName;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TabPage tabPageEditSpouseInfo;
        private System.Windows.Forms.Button buttonSpouseEditIgnore;
        private System.Windows.Forms.Button buttonSpouseEdit;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditSpouseDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditSpouseMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditSpouseGender;
        private System.Windows.Forms.TextBox textBoxSPAJEditSpouseNextBday;
        private System.Windows.Forms.RadioButton radioButtonSPAJEditSpouseSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJEditSpouseWeight;
        private System.Windows.Forms.TextBox textBoxSPAJEditSpouseHeight;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TabPage tabPageEditParentInfo;
        private System.Windows.Forms.Button buttonParentEditIgnore;
        private System.Windows.Forms.Button buttonParentEdit;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditParentDOB;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditParentMarriage;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditParentGender;
        private System.Windows.Forms.TextBox textBoxSPAJEditParentNextBday;
        private System.Windows.Forms.RadioButton radioButtonSPAJEditParentSmoke;
        private System.Windows.Forms.TextBox textBoxSPAJEditParentWeight;
        private System.Windows.Forms.TextBox textBoxSPAJEditParentHeight;
        private System.Windows.Forms.TextBox textBoxSPAJEditParentName;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TabPage tabPageEditAddrInfo;
        private System.Windows.Forms.Button buttonAddressEdit;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrOP;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrHP;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrEmail;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrZip;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrCity;
        private System.Windows.Forms.TextBox textBoxSPAJEditAddrAddress;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.TabPage tabPageEditPengajuanInfo;
        private System.Windows.Forms.Button buttonPengajuanEdit;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPremiTotal;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruSaver;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPremi;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPrtanggung;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanExchange;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanExpDate;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanCCBank;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruPPayorAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPRUMedAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruADDAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruCCAmnt;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruPayorAmnt;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanPruPPayor;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanPRUMed;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanADD;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanPruCC;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanPruPayor;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditPengajuanPruHosp;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPengajuanCurrency;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPengajuanPay;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditPengajuanFreq;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label labelSPAJEditPengajuanExRate;
        private System.Windows.Forms.Label labelSPAJEditPengajuanCCExpDate;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label labelSPAJEditPengajuanCCBankOther;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.TabPage tabPageEditBeneficiaryInfo;
        private System.Windows.Forms.Button buttonBeneficiaryEdit;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs6;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs5;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs4;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs3;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs2;
        private System.Windows.Forms.ComboBox comboBoxSPAJEditBeneficiaryRs1;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary6;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary5;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary4;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary3;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary2;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJEditBeneficiary1;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail6;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail5;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail4;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail3;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName6;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName5;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName4;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName3;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName2;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName6;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName5;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName4;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName3;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary6;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary5;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary4;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary3;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary2;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail1;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName2;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryDetail2;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryLName1;
        private System.Windows.Forms.TextBox textBoxSPAJEditBeneficiaryFName1;
        private System.Windows.Forms.CheckBox checkBoxSPAJEditBeneficiary1;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox textBoxSPAJEditANumber;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox textBoxSPAJEditAName;
        private System.Windows.Forms.TextBox textBoxSPAJEditNumber;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label labelSPAJPengajuanPruHosp;
        private System.Windows.Forms.Label labelEditPruHospitalandSurgical;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label labelSPAJInforce;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.TextBox textBoxSPAJUpdateNumber;
        private System.Windows.Forms.DataGridView dataGridViewSPAJUpdate;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label labelSPAJInforcePolis;
        private System.Windows.Forms.ComboBox comboBoxSPAJUpdateType;
        private System.Windows.Forms.Button buttonSPAJUpdateClear;
        private System.Windows.Forms.Button buttonSPAJUpdateUpdate;
        private System.Windows.Forms.ComboBox comboBoxSPAJUpdateStatus;
        private System.Windows.Forms.DateTimePicker dateTimeSPAJUpdateInforce;
        private System.Windows.Forms.TextBox textBoxSPAJUpdateInsDOB;
        private System.Windows.Forms.TextBox textBoxSPAJUpdateInfo;
        private System.Windows.Forms.TextBox textBoxSPAJUpdatePolisNum;
        private System.Windows.Forms.TextBox textBoxSPAJUpdateInsName;
        private System.Windows.Forms.Button buttonSPAJUpdateLoad;
        private System.Windows.Forms.TabPage tabPageSPAJDelete;
        private System.Windows.Forms.Button buttonSPAJDeleteDelete;
        private System.Windows.Forms.Button buttonSPAJDeleteClear;
        private System.Windows.Forms.Button buttonSPAJDeleteCheck;
        private System.Windows.Forms.TextBox textBoxSPAJDeleteNum;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruPPayor;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruMed;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruADD;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruCC;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruPayor;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanPruHosp;
        private System.Windows.Forms.TextBox textBoxSPAJPengajuanBasic;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.TextBox textBoxSPAJEditSpouseName;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruPayor;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanBasic;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruADD;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruCC;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPRUMed;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruPPayor;
        private System.Windows.Forms.TextBox textBoxSPAJEditPengajuanPruHosp;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.TextBox textBoxSPAJInsType;
        private System.Windows.Forms.TextBox textBoxSPAJEditType;
        private System.Windows.Forms.Button buttonAddSPAJPolisBack;
        private System.Windows.Forms.Button buttonAddSPAJSpouseBack;
        private System.Windows.Forms.Button buttonAddSPAJParentBack;
        private System.Windows.Forms.Button buttonAddSPAJAddressBack;
        private System.Windows.Forms.Button buttonAddSPAJPengajuanBack;
        private System.Windows.Forms.Button buttonAddSPAJBeneficiaryBack;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Button buttonSPAJPengajuanNext;
    }
}