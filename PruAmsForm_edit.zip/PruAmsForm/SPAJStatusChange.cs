﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruAmsForm
{
    class SPAJStatusChange
    {
        public int PolisNumber { get; set; }
        public string InsurerName { get; set; }
        public string StatusChangedTo { get; set; }
        public string DateTime { get; set; }


    }
}
