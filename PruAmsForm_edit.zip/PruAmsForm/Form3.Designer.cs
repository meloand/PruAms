﻿namespace PruAmsForm
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControlAgent = new System.Windows.Forms.TabControl();
            this.tabPageView = new System.Windows.Forms.TabPage();
            this.comboBoxViewAgentDateYear = new System.Windows.Forms.ComboBox();
            this.comboBoxViewAgentDateDay = new System.Windows.Forms.ComboBox();
            this.comboBoxViewAgentDateMonth = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonExportView = new System.Windows.Forms.Button();
            this.buttonClearView = new System.Windows.Forms.Button();
            this.buttonViewAgent = new System.Windows.Forms.Button();
            this.comboBoxViewAgentLeader = new System.Windows.Forms.ComboBox();
            this.agentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBoxViewAgentLevel = new System.Windows.Forms.ComboBox();
            this.textBoxViewAgentLastN = new System.Windows.Forms.TextBox();
            this.textBoxViewAgentFirstN = new System.Windows.Forms.TextBox();
            this.textBoxViewAgentNum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPageAdd = new System.Windows.Forms.TabPage();
            this.labelAddSuccess = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.textBoxAgentReligion = new System.Windows.Forms.TextBox();
            this.buttonClearAdd = new System.Windows.Forms.Button();
            this.buttonAddAgents = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.dateTimeAgentDOB = new System.Windows.Forms.DateTimePicker();
            this.textBoxAgentPOB = new System.Windows.Forms.TextBox();
            this.textBoxAgentOP = new System.Windows.Forms.TextBox();
            this.textBoxAgentHP = new System.Windows.Forms.TextBox();
            this.textBoxAgentZip = new System.Windows.Forms.TextBox();
            this.textBoxAgentAddr = new System.Windows.Forms.TextBox();
            this.textBoxAgentEmail = new System.Windows.Forms.TextBox();
            this.textBoxAgentLastN = new System.Windows.Forms.TextBox();
            this.textBoxAgentFirstN = new System.Windows.Forms.TextBox();
            this.textBoxAgentPass = new System.Windows.Forms.TextBox();
            this.textBoxAgentUser = new System.Windows.Forms.TextBox();
            this.textBoxAgentNum = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.dateTimeAgentJoin = new System.Windows.Forms.DateTimePicker();
            this.comboBoxAgentSex = new System.Windows.Forms.ComboBox();
            this.comboBoxAgentLeader = new System.Windows.Forms.ComboBox();
            this.comboBoxAgentLevel = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPageEdit = new System.Windows.Forms.TabPage();
            this.labelUpdateSuccess = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.textBoxAgentEditReligion = new System.Windows.Forms.TextBox();
            this.buttonAgentEditSearch = new System.Windows.Forms.Button();
            this.comboBoxAgentModify = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.buttonClearEdit = new System.Windows.Forms.Button();
            this.buttonEditAgents = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dateTimeAgentEditDOB = new System.Windows.Forms.DateTimePicker();
            this.textBoxAgentEditPOB = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditOP = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditHP = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditZip = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditAddr = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditEmail = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditLName = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditFName = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditPass = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditUser = new System.Windows.Forms.TextBox();
            this.textBoxAgentEditNum = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.dateTimeAgentEditJoin = new System.Windows.Forms.DateTimePicker();
            this.comboBoxAgentEditSex = new System.Windows.Forms.ComboBox();
            this.comboBoxAgentEditLeader = new System.Windows.Forms.ComboBox();
            this.comboBoxAgentEditLevel = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonAgentLevelHistory = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBoxAgentLevelHist = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonAgentBackMenu = new System.Windows.Forms.Button();
            this.tabControlAgent.SuspendLayout();
            this.tabPageView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentBindingSource)).BeginInit();
            this.tabPageAdd.SuspendLayout();
            this.tabPageEdit.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlAgent
            // 
            this.tabControlAgent.Controls.Add(this.tabPageView);
            this.tabControlAgent.Controls.Add(this.tabPageAdd);
            this.tabControlAgent.Controls.Add(this.tabPageEdit);
            this.tabControlAgent.Controls.Add(this.tabPage1);
            this.tabControlAgent.Location = new System.Drawing.Point(0, 42);
            this.tabControlAgent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabControlAgent.Name = "tabControlAgent";
            this.tabControlAgent.SelectedIndex = 0;
            this.tabControlAgent.Size = new System.Drawing.Size(760, 362);
            this.tabControlAgent.TabIndex = 7;
            // 
            // tabPageView
            // 
            this.tabPageView.Controls.Add(this.comboBoxViewAgentDateYear);
            this.tabPageView.Controls.Add(this.comboBoxViewAgentDateDay);
            this.tabPageView.Controls.Add(this.comboBoxViewAgentDateMonth);
            this.tabPageView.Controls.Add(this.dataGridView1);
            this.tabPageView.Controls.Add(this.buttonExportView);
            this.tabPageView.Controls.Add(this.buttonClearView);
            this.tabPageView.Controls.Add(this.buttonViewAgent);
            this.tabPageView.Controls.Add(this.comboBoxViewAgentLeader);
            this.tabPageView.Controls.Add(this.comboBoxViewAgentLevel);
            this.tabPageView.Controls.Add(this.textBoxViewAgentLastN);
            this.tabPageView.Controls.Add(this.textBoxViewAgentFirstN);
            this.tabPageView.Controls.Add(this.textBoxViewAgentNum);
            this.tabPageView.Controls.Add(this.label13);
            this.tabPageView.Controls.Add(this.label14);
            this.tabPageView.Controls.Add(this.label15);
            this.tabPageView.Controls.Add(this.label17);
            this.tabPageView.Controls.Add(this.label18);
            this.tabPageView.Controls.Add(this.label21);
            this.tabPageView.Controls.Add(this.label22);
            this.tabPageView.Location = new System.Drawing.Point(4, 22);
            this.tabPageView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageView.Name = "tabPageView";
            this.tabPageView.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageView.Size = new System.Drawing.Size(752, 336);
            this.tabPageView.TabIndex = 2;
            this.tabPageView.Text = "View Agents";
            this.tabPageView.UseVisualStyleBackColor = true;
            this.tabPageView.Enter += new System.EventHandler(this.tabPageView_Enter);
            // 
            // comboBoxViewAgentDateYear
            // 
            this.comboBoxViewAgentDateYear.FormattingEnabled = true;
            this.comboBoxViewAgentDateYear.Items.AddRange(new object[] {
            "2004",
            "2003",
            "2002",
            "2001",
            "2000",
            "1999",
            "1998",
            "1997",
            "1996",
            "1995",
            "1994",
            "1993",
            "1992",
            "1991",
            "1990",
            "1989",
            "1988",
            "1987",
            "1986",
            "1985",
            "1984",
            "1983",
            "1982",
            "1981",
            "1980",
            "1979",
            "1978",
            "1977",
            "1976",
            "1975",
            "1974",
            "1973",
            "1972",
            "1971",
            "1970",
            "1969",
            "1968",
            "1967",
            "1966",
            "1965",
            "1964",
            "1963",
            "1962",
            "1961",
            "1960",
            "1959",
            "1958",
            "1957",
            "1956",
            "1955",
            "1954",
            "1953",
            "1952",
            "1951",
            "1950",
            "1949",
            "1948",
            "1947",
            "1946",
            "1945",
            "1944",
            "1943",
            "1942",
            "1941",
            "1940"});
            this.comboBoxViewAgentDateYear.Location = new System.Drawing.Point(216, 147);
            this.comboBoxViewAgentDateYear.Name = "comboBoxViewAgentDateYear";
            this.comboBoxViewAgentDateYear.Size = new System.Drawing.Size(55, 21);
            this.comboBoxViewAgentDateYear.TabIndex = 42;
            // 
            // comboBoxViewAgentDateDay
            // 
            this.comboBoxViewAgentDateDay.FormattingEnabled = true;
            this.comboBoxViewAgentDateDay.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBoxViewAgentDateDay.Location = new System.Drawing.Point(176, 147);
            this.comboBoxViewAgentDateDay.Name = "comboBoxViewAgentDateDay";
            this.comboBoxViewAgentDateDay.Size = new System.Drawing.Size(34, 21);
            this.comboBoxViewAgentDateDay.TabIndex = 41;
            // 
            // comboBoxViewAgentDateMonth
            // 
            this.comboBoxViewAgentDateMonth.FormattingEnabled = true;
            this.comboBoxViewAgentDateMonth.Items.AddRange(new object[] {
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec"});
            this.comboBoxViewAgentDateMonth.Location = new System.Drawing.Point(130, 147);
            this.comboBoxViewAgentDateMonth.Name = "comboBoxViewAgentDateMonth";
            this.comboBoxViewAgentDateMonth.Size = new System.Drawing.Size(40, 21);
            this.comboBoxViewAgentDateMonth.TabIndex = 40;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(276, 18);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(467, 279);
            this.dataGridView1.TabIndex = 39;
            // 
            // buttonExportView
            // 
            this.buttonExportView.Location = new System.Drawing.Point(563, 308);
            this.buttonExportView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonExportView.Name = "buttonExportView";
            this.buttonExportView.Size = new System.Drawing.Size(78, 21);
            this.buttonExportView.TabIndex = 38;
            this.buttonExportView.Text = "Export View";
            this.buttonExportView.UseVisualStyleBackColor = true;
            // 
            // buttonClearView
            // 
            this.buttonClearView.Location = new System.Drawing.Point(372, 308);
            this.buttonClearView.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonClearView.Name = "buttonClearView";
            this.buttonClearView.Size = new System.Drawing.Size(78, 21);
            this.buttonClearView.TabIndex = 37;
            this.buttonClearView.Text = "Clear";
            this.buttonClearView.UseVisualStyleBackColor = true;
            this.buttonClearView.Click += new System.EventHandler(this.buttonClearView_Click);
            // 
            // buttonViewAgent
            // 
            this.buttonViewAgent.Location = new System.Drawing.Point(136, 292);
            this.buttonViewAgent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonViewAgent.Name = "buttonViewAgent";
            this.buttonViewAgent.Size = new System.Drawing.Size(78, 21);
            this.buttonViewAgent.TabIndex = 36;
            this.buttonViewAgent.Text = "View Agent";
            this.buttonViewAgent.UseVisualStyleBackColor = true;
            this.buttonViewAgent.Click += new System.EventHandler(this.buttonViewAgent_Click);
            // 
            // comboBoxViewAgentLeader
            // 
            this.comboBoxViewAgentLeader.DataSource = this.agentBindingSource;
            this.comboBoxViewAgentLeader.DisplayMember = "FullName";
            this.comboBoxViewAgentLeader.FormattingEnabled = true;
            this.comboBoxViewAgentLeader.Location = new System.Drawing.Point(130, 213);
            this.comboBoxViewAgentLeader.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxViewAgentLeader.Name = "comboBoxViewAgentLeader";
            this.comboBoxViewAgentLeader.Size = new System.Drawing.Size(141, 21);
            this.comboBoxViewAgentLeader.TabIndex = 20;
            // 
            // agentBindingSource
            // 
            this.agentBindingSource.DataSource = typeof(PruAmsForm.Agent);
            // 
            // comboBoxViewAgentLevel
            // 
            this.comboBoxViewAgentLevel.FormattingEnabled = true;
            this.comboBoxViewAgentLevel.Items.AddRange(new object[] {
            "Agent",
            "AAM",
            "AAD",
            "AD"});
            this.comboBoxViewAgentLevel.Location = new System.Drawing.Point(130, 181);
            this.comboBoxViewAgentLevel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxViewAgentLevel.Name = "comboBoxViewAgentLevel";
            this.comboBoxViewAgentLevel.Size = new System.Drawing.Size(141, 21);
            this.comboBoxViewAgentLevel.TabIndex = 19;
            // 
            // textBoxViewAgentLastN
            // 
            this.textBoxViewAgentLastN.Location = new System.Drawing.Point(130, 115);
            this.textBoxViewAgentLastN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxViewAgentLastN.Name = "textBoxViewAgentLastN";
            this.textBoxViewAgentLastN.Size = new System.Drawing.Size(141, 20);
            this.textBoxViewAgentLastN.TabIndex = 14;
            // 
            // textBoxViewAgentFirstN
            // 
            this.textBoxViewAgentFirstN.Location = new System.Drawing.Point(130, 90);
            this.textBoxViewAgentFirstN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxViewAgentFirstN.Name = "textBoxViewAgentFirstN";
            this.textBoxViewAgentFirstN.Size = new System.Drawing.Size(142, 20);
            this.textBoxViewAgentFirstN.TabIndex = 13;
            // 
            // textBoxViewAgentNum
            // 
            this.textBoxViewAgentNum.Location = new System.Drawing.Point(130, 64);
            this.textBoxViewAgentNum.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxViewAgentNum.Name = "textBoxViewAgentNum";
            this.textBoxViewAgentNum.Size = new System.Drawing.Size(141, 20);
            this.textBoxViewAgentNum.TabIndex = 10;
            this.textBoxViewAgentNum.TextChanged += new System.EventHandler(this.textBoxViewAgentNum_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(40, 213);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 13);
            this.label13.TabIndex = 9;
            this.label13.Text = "Direct Leader:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(40, 181);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "Level:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 150);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(58, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Join Date: ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(40, 115);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Last Name:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(40, 90);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "First Name:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(40, 64);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(81, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Agent Number: ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label22.Location = new System.Drawing.Point(38, 30);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(109, 20);
            this.label22.TabIndex = 0;
            this.label22.Text = "View Agents";
            // 
            // tabPageAdd
            // 
            this.tabPageAdd.Controls.Add(this.labelAddSuccess);
            this.tabPageAdd.Controls.Add(this.label49);
            this.tabPageAdd.Controls.Add(this.textBoxAgentReligion);
            this.tabPageAdd.Controls.Add(this.buttonClearAdd);
            this.tabPageAdd.Controls.Add(this.buttonAddAgents);
            this.tabPageAdd.Controls.Add(this.label30);
            this.tabPageAdd.Controls.Add(this.label29);
            this.tabPageAdd.Controls.Add(this.label28);
            this.tabPageAdd.Controls.Add(this.label27);
            this.tabPageAdd.Controls.Add(this.dateTimeAgentDOB);
            this.tabPageAdd.Controls.Add(this.textBoxAgentPOB);
            this.tabPageAdd.Controls.Add(this.textBoxAgentOP);
            this.tabPageAdd.Controls.Add(this.textBoxAgentHP);
            this.tabPageAdd.Controls.Add(this.textBoxAgentZip);
            this.tabPageAdd.Controls.Add(this.textBoxAgentAddr);
            this.tabPageAdd.Controls.Add(this.textBoxAgentEmail);
            this.tabPageAdd.Controls.Add(this.textBoxAgentLastN);
            this.tabPageAdd.Controls.Add(this.textBoxAgentFirstN);
            this.tabPageAdd.Controls.Add(this.textBoxAgentPass);
            this.tabPageAdd.Controls.Add(this.textBoxAgentUser);
            this.tabPageAdd.Controls.Add(this.textBoxAgentNum);
            this.tabPageAdd.Controls.Add(this.label26);
            this.tabPageAdd.Controls.Add(this.label25);
            this.tabPageAdd.Controls.Add(this.label24);
            this.tabPageAdd.Controls.Add(this.dateTimeAgentJoin);
            this.tabPageAdd.Controls.Add(this.comboBoxAgentSex);
            this.tabPageAdd.Controls.Add(this.comboBoxAgentLeader);
            this.tabPageAdd.Controls.Add(this.comboBoxAgentLevel);
            this.tabPageAdd.Controls.Add(this.label12);
            this.tabPageAdd.Controls.Add(this.label11);
            this.tabPageAdd.Controls.Add(this.label10);
            this.tabPageAdd.Controls.Add(this.label9);
            this.tabPageAdd.Controls.Add(this.label8);
            this.tabPageAdd.Controls.Add(this.label7);
            this.tabPageAdd.Controls.Add(this.label6);
            this.tabPageAdd.Controls.Add(this.label5);
            this.tabPageAdd.Controls.Add(this.label4);
            this.tabPageAdd.Controls.Add(this.label2);
            this.tabPageAdd.Location = new System.Drawing.Point(4, 22);
            this.tabPageAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageAdd.Name = "tabPageAdd";
            this.tabPageAdd.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageAdd.Size = new System.Drawing.Size(752, 336);
            this.tabPageAdd.TabIndex = 0;
            this.tabPageAdd.Text = "Add Agents";
            this.tabPageAdd.UseVisualStyleBackColor = true;
            // 
            // labelAddSuccess
            // 
            this.labelAddSuccess.AutoSize = true;
            this.labelAddSuccess.Location = new System.Drawing.Point(504, 285);
            this.labelAddSuccess.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelAddSuccess.Name = "labelAddSuccess";
            this.labelAddSuccess.Size = new System.Drawing.Size(134, 13);
            this.labelAddSuccess.TabIndex = 39;
            this.labelAddSuccess.Text = "Agent successfully added! ";
            this.labelAddSuccess.Visible = false;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(278, 63);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(48, 13);
            this.label49.TabIndex = 38;
            this.label49.Text = "Religion:";
            // 
            // textBoxAgentReligion
            // 
            this.textBoxAgentReligion.Location = new System.Drawing.Point(366, 64);
            this.textBoxAgentReligion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentReligion.Name = "textBoxAgentReligion";
            this.textBoxAgentReligion.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentReligion.TabIndex = 37;
            // 
            // buttonClearAdd
            // 
            this.buttonClearAdd.Location = new System.Drawing.Point(42, 285);
            this.buttonClearAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonClearAdd.Name = "buttonClearAdd";
            this.buttonClearAdd.Size = new System.Drawing.Size(78, 21);
            this.buttonClearAdd.TabIndex = 36;
            this.buttonClearAdd.Text = "Clear";
            this.buttonClearAdd.UseVisualStyleBackColor = true;
            this.buttonClearAdd.Click += new System.EventHandler(this.buttonClearAdd_Click);
            // 
            // buttonAddAgents
            // 
            this.buttonAddAgents.Location = new System.Drawing.Point(386, 285);
            this.buttonAddAgents.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonAddAgents.Name = "buttonAddAgents";
            this.buttonAddAgents.Size = new System.Drawing.Size(78, 21);
            this.buttonAddAgents.TabIndex = 35;
            this.buttonAddAgents.Text = "Add Agent";
            this.buttonAddAgents.UseVisualStyleBackColor = true;
            this.buttonAddAgents.Click += new System.EventHandler(this.buttonAddAgents_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(276, 262);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(69, 13);
            this.label30.TabIndex = 34;
            this.label30.Text = "Date of Birth:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(276, 235);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 13);
            this.label29.TabIndex = 33;
            this.label29.Text = "Place of Birth:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(276, 205);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(72, 26);
            this.label28.TabIndex = 32;
            this.label28.Text = "Office Phone \r\nNum:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(276, 176);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 26);
            this.label27.TabIndex = 31;
            this.label27.Text = "Hand Phone \r\nNum:";
            // 
            // dateTimeAgentDOB
            // 
            this.dateTimeAgentDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeAgentDOB.Location = new System.Drawing.Point(366, 259);
            this.dateTimeAgentDOB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimeAgentDOB.Name = "dateTimeAgentDOB";
            this.dateTimeAgentDOB.Size = new System.Drawing.Size(100, 20);
            this.dateTimeAgentDOB.TabIndex = 30;
            // 
            // textBoxAgentPOB
            // 
            this.textBoxAgentPOB.Location = new System.Drawing.Point(366, 232);
            this.textBoxAgentPOB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentPOB.Name = "textBoxAgentPOB";
            this.textBoxAgentPOB.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentPOB.TabIndex = 29;
            // 
            // textBoxAgentOP
            // 
            this.textBoxAgentOP.Location = new System.Drawing.Point(366, 203);
            this.textBoxAgentOP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentOP.Name = "textBoxAgentOP";
            this.textBoxAgentOP.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentOP.TabIndex = 28;
            // 
            // textBoxAgentHP
            // 
            this.textBoxAgentHP.Location = new System.Drawing.Point(366, 179);
            this.textBoxAgentHP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentHP.Name = "textBoxAgentHP";
            this.textBoxAgentHP.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentHP.TabIndex = 27;
            // 
            // textBoxAgentZip
            // 
            this.textBoxAgentZip.Location = new System.Drawing.Point(366, 153);
            this.textBoxAgentZip.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentZip.Name = "textBoxAgentZip";
            this.textBoxAgentZip.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentZip.TabIndex = 18;
            // 
            // textBoxAgentAddr
            // 
            this.textBoxAgentAddr.Location = new System.Drawing.Point(366, 124);
            this.textBoxAgentAddr.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentAddr.Name = "textBoxAgentAddr";
            this.textBoxAgentAddr.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentAddr.TabIndex = 17;
            // 
            // textBoxAgentEmail
            // 
            this.textBoxAgentEmail.Location = new System.Drawing.Point(130, 189);
            this.textBoxAgentEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEmail.Name = "textBoxAgentEmail";
            this.textBoxAgentEmail.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEmail.TabIndex = 15;
            // 
            // textBoxAgentLastN
            // 
            this.textBoxAgentLastN.Location = new System.Drawing.Point(130, 161);
            this.textBoxAgentLastN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentLastN.Name = "textBoxAgentLastN";
            this.textBoxAgentLastN.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentLastN.TabIndex = 14;
            // 
            // textBoxAgentFirstN
            // 
            this.textBoxAgentFirstN.Location = new System.Drawing.Point(130, 138);
            this.textBoxAgentFirstN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentFirstN.Name = "textBoxAgentFirstN";
            this.textBoxAgentFirstN.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentFirstN.TabIndex = 13;
            // 
            // textBoxAgentPass
            // 
            this.textBoxAgentPass.Location = new System.Drawing.Point(130, 113);
            this.textBoxAgentPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentPass.Name = "textBoxAgentPass";
            this.textBoxAgentPass.PasswordChar = '*';
            this.textBoxAgentPass.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentPass.TabIndex = 12;
            // 
            // textBoxAgentUser
            // 
            this.textBoxAgentUser.Location = new System.Drawing.Point(130, 87);
            this.textBoxAgentUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentUser.Name = "textBoxAgentUser";
            this.textBoxAgentUser.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentUser.TabIndex = 11;
            // 
            // textBoxAgentNum
            // 
            this.textBoxAgentNum.Location = new System.Drawing.Point(130, 64);
            this.textBoxAgentNum.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentNum.Name = "textBoxAgentNum";
            this.textBoxAgentNum.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentNum.TabIndex = 10;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(276, 155);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 13);
            this.label26.TabIndex = 26;
            this.label26.Text = "Zip Code:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(276, 127);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(48, 13);
            this.label25.TabIndex = 25;
            this.label25.Text = "Address:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(278, 97);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(28, 13);
            this.label24.TabIndex = 24;
            this.label24.Text = "Sex:";
            // 
            // dateTimeAgentJoin
            // 
            this.dateTimeAgentJoin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeAgentJoin.Location = new System.Drawing.Point(130, 213);
            this.dateTimeAgentJoin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimeAgentJoin.Name = "dateTimeAgentJoin";
            this.dateTimeAgentJoin.Size = new System.Drawing.Size(100, 20);
            this.dateTimeAgentJoin.TabIndex = 22;
            // 
            // comboBoxAgentSex
            // 
            this.comboBoxAgentSex.FormattingEnabled = true;
            this.comboBoxAgentSex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxAgentSex.Location = new System.Drawing.Point(366, 93);
            this.comboBoxAgentSex.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentSex.Name = "comboBoxAgentSex";
            this.comboBoxAgentSex.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentSex.TabIndex = 21;
            // 
            // comboBoxAgentLeader
            // 
            this.comboBoxAgentLeader.DataSource = this.agentBindingSource;
            this.comboBoxAgentLeader.DisplayMember = "FullName";
            this.comboBoxAgentLeader.FormattingEnabled = true;
            this.comboBoxAgentLeader.Location = new System.Drawing.Point(130, 258);
            this.comboBoxAgentLeader.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentLeader.Name = "comboBoxAgentLeader";
            this.comboBoxAgentLeader.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentLeader.TabIndex = 20;
            // 
            // comboBoxAgentLevel
            // 
            this.comboBoxAgentLevel.FormattingEnabled = true;
            this.comboBoxAgentLevel.Items.AddRange(new object[] {
            "Agent",
            "AAM",
            "AAD",
            "AD"});
            this.comboBoxAgentLevel.Location = new System.Drawing.Point(130, 235);
            this.comboBoxAgentLevel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentLevel.Name = "comboBoxAgentLevel";
            this.comboBoxAgentLevel.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentLevel.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(40, 258);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 13);
            this.label12.TabIndex = 9;
            this.label12.Text = "Direct Leader:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(40, 236);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Level:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 213);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "Join Date: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(40, 189);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 6;
            this.label9.Text = "Email: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(40, 164);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Last Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(40, 138);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "First Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 113);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Password:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 87);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Username:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 64);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Agent Number: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(38, 30);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Add New Agents";
            // 
            // tabPageEdit
            // 
            this.tabPageEdit.Controls.Add(this.labelUpdateSuccess);
            this.tabPageEdit.Controls.Add(this.label50);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditReligion);
            this.tabPageEdit.Controls.Add(this.buttonAgentEditSearch);
            this.tabPageEdit.Controls.Add(this.comboBoxAgentModify);
            this.tabPageEdit.Controls.Add(this.label48);
            this.tabPageEdit.Controls.Add(this.buttonClearEdit);
            this.tabPageEdit.Controls.Add(this.buttonEditAgents);
            this.tabPageEdit.Controls.Add(this.label3);
            this.tabPageEdit.Controls.Add(this.label31);
            this.tabPageEdit.Controls.Add(this.label32);
            this.tabPageEdit.Controls.Add(this.label33);
            this.tabPageEdit.Controls.Add(this.dateTimeAgentEditDOB);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditPOB);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditOP);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditHP);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditZip);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditAddr);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditEmail);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditLName);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditFName);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditPass);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditUser);
            this.tabPageEdit.Controls.Add(this.textBoxAgentEditNum);
            this.tabPageEdit.Controls.Add(this.label34);
            this.tabPageEdit.Controls.Add(this.label35);
            this.tabPageEdit.Controls.Add(this.label36);
            this.tabPageEdit.Controls.Add(this.dateTimeAgentEditJoin);
            this.tabPageEdit.Controls.Add(this.comboBoxAgentEditSex);
            this.tabPageEdit.Controls.Add(this.comboBoxAgentEditLeader);
            this.tabPageEdit.Controls.Add(this.comboBoxAgentEditLevel);
            this.tabPageEdit.Controls.Add(this.label38);
            this.tabPageEdit.Controls.Add(this.label39);
            this.tabPageEdit.Controls.Add(this.label40);
            this.tabPageEdit.Controls.Add(this.label41);
            this.tabPageEdit.Controls.Add(this.label42);
            this.tabPageEdit.Controls.Add(this.label43);
            this.tabPageEdit.Controls.Add(this.label44);
            this.tabPageEdit.Controls.Add(this.label45);
            this.tabPageEdit.Controls.Add(this.label46);
            this.tabPageEdit.Controls.Add(this.label47);
            this.tabPageEdit.Location = new System.Drawing.Point(4, 22);
            this.tabPageEdit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageEdit.Name = "tabPageEdit";
            this.tabPageEdit.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPageEdit.Size = new System.Drawing.Size(752, 336);
            this.tabPageEdit.TabIndex = 3;
            this.tabPageEdit.Text = "Edit Agents";
            this.tabPageEdit.UseVisualStyleBackColor = true;
            // 
            // labelUpdateSuccess
            // 
            this.labelUpdateSuccess.AutoSize = true;
            this.labelUpdateSuccess.Location = new System.Drawing.Point(548, 302);
            this.labelUpdateSuccess.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelUpdateSuccess.Name = "labelUpdateSuccess";
            this.labelUpdateSuccess.Size = new System.Drawing.Size(137, 13);
            this.labelUpdateSuccess.TabIndex = 43;
            this.labelUpdateSuccess.Text = "Agent successfully updated";
            this.labelUpdateSuccess.Visible = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(278, 64);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(48, 13);
            this.label50.TabIndex = 42;
            this.label50.Text = "Religion:";
            // 
            // textBoxAgentEditReligion
            // 
            this.textBoxAgentEditReligion.Location = new System.Drawing.Point(366, 64);
            this.textBoxAgentEditReligion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditReligion.Name = "textBoxAgentEditReligion";
            this.textBoxAgentEditReligion.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditReligion.TabIndex = 41;
            // 
            // buttonAgentEditSearch
            // 
            this.buttonAgentEditSearch.Location = new System.Drawing.Point(375, 22);
            this.buttonAgentEditSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonAgentEditSearch.Name = "buttonAgentEditSearch";
            this.buttonAgentEditSearch.Size = new System.Drawing.Size(60, 26);
            this.buttonAgentEditSearch.TabIndex = 40;
            this.buttonAgentEditSearch.Text = "Search ";
            this.buttonAgentEditSearch.UseVisualStyleBackColor = true;
            this.buttonAgentEditSearch.Click += new System.EventHandler(this.buttonAgentEditSearch_Click);
            // 
            // comboBoxAgentModify
            // 
            this.comboBoxAgentModify.DataSource = this.agentBindingSource;
            this.comboBoxAgentModify.DisplayMember = "Number";
            this.comboBoxAgentModify.FormattingEnabled = true;
            this.comboBoxAgentModify.Location = new System.Drawing.Point(227, 26);
            this.comboBoxAgentModify.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentModify.Name = "comboBoxAgentModify";
            this.comboBoxAgentModify.Size = new System.Drawing.Size(132, 21);
            this.comboBoxAgentModify.TabIndex = 39;
            this.comboBoxAgentModify.ValueMember = "Number";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(144, 26);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(65, 26);
            this.label48.TabIndex = 38;
            this.label48.Text = "Agent to be \r\nModified:";
            // 
            // buttonClearEdit
            // 
            this.buttonClearEdit.Location = new System.Drawing.Point(42, 295);
            this.buttonClearEdit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonClearEdit.Name = "buttonClearEdit";
            this.buttonClearEdit.Size = new System.Drawing.Size(78, 21);
            this.buttonClearEdit.TabIndex = 36;
            this.buttonClearEdit.Text = "Clear";
            this.buttonClearEdit.UseVisualStyleBackColor = true;
            this.buttonClearEdit.Click += new System.EventHandler(this.buttonClearEdit_Click);
            // 
            // buttonEditAgents
            // 
            this.buttonEditAgents.Location = new System.Drawing.Point(436, 295);
            this.buttonEditAgents.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonEditAgents.Name = "buttonEditAgents";
            this.buttonEditAgents.Size = new System.Drawing.Size(78, 21);
            this.buttonEditAgents.TabIndex = 35;
            this.buttonEditAgents.Text = "Edit";
            this.buttonEditAgents.UseVisualStyleBackColor = true;
            this.buttonEditAgents.Click += new System.EventHandler(this.buttonEditAgents_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(278, 249);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Date of Birth:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(278, 223);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(73, 13);
            this.label31.TabIndex = 33;
            this.label31.Text = "Place of Birth:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(278, 190);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 26);
            this.label32.TabIndex = 32;
            this.label32.Text = "Office Phone \r\nNum:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(278, 161);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(70, 26);
            this.label33.TabIndex = 31;
            this.label33.Text = "Hand Phone \r\nNum:";
            // 
            // dateTimeAgentEditDOB
            // 
            this.dateTimeAgentEditDOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeAgentEditDOB.Location = new System.Drawing.Point(366, 249);
            this.dateTimeAgentEditDOB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimeAgentEditDOB.Name = "dateTimeAgentEditDOB";
            this.dateTimeAgentEditDOB.Size = new System.Drawing.Size(100, 20);
            this.dateTimeAgentEditDOB.TabIndex = 30;
            // 
            // textBoxAgentEditPOB
            // 
            this.textBoxAgentEditPOB.Location = new System.Drawing.Point(366, 223);
            this.textBoxAgentEditPOB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditPOB.Name = "textBoxAgentEditPOB";
            this.textBoxAgentEditPOB.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditPOB.TabIndex = 29;
            // 
            // textBoxAgentEditOP
            // 
            this.textBoxAgentEditOP.Location = new System.Drawing.Point(366, 200);
            this.textBoxAgentEditOP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditOP.Name = "textBoxAgentEditOP";
            this.textBoxAgentEditOP.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditOP.TabIndex = 28;
            // 
            // textBoxAgentEditHP
            // 
            this.textBoxAgentEditHP.Location = new System.Drawing.Point(366, 171);
            this.textBoxAgentEditHP.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditHP.Name = "textBoxAgentEditHP";
            this.textBoxAgentEditHP.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditHP.TabIndex = 27;
            // 
            // textBoxAgentEditZip
            // 
            this.textBoxAgentEditZip.Location = new System.Drawing.Point(366, 141);
            this.textBoxAgentEditZip.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditZip.Name = "textBoxAgentEditZip";
            this.textBoxAgentEditZip.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditZip.TabIndex = 18;
            // 
            // textBoxAgentEditAddr
            // 
            this.textBoxAgentEditAddr.Location = new System.Drawing.Point(366, 116);
            this.textBoxAgentEditAddr.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditAddr.Name = "textBoxAgentEditAddr";
            this.textBoxAgentEditAddr.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditAddr.TabIndex = 17;
            // 
            // textBoxAgentEditEmail
            // 
            this.textBoxAgentEditEmail.Location = new System.Drawing.Point(130, 189);
            this.textBoxAgentEditEmail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditEmail.Name = "textBoxAgentEditEmail";
            this.textBoxAgentEditEmail.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditEmail.TabIndex = 15;
            // 
            // textBoxAgentEditLName
            // 
            this.textBoxAgentEditLName.Location = new System.Drawing.Point(130, 161);
            this.textBoxAgentEditLName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditLName.Name = "textBoxAgentEditLName";
            this.textBoxAgentEditLName.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditLName.TabIndex = 14;
            // 
            // textBoxAgentEditFName
            // 
            this.textBoxAgentEditFName.Location = new System.Drawing.Point(130, 138);
            this.textBoxAgentEditFName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditFName.Name = "textBoxAgentEditFName";
            this.textBoxAgentEditFName.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditFName.TabIndex = 13;
            // 
            // textBoxAgentEditPass
            // 
            this.textBoxAgentEditPass.Location = new System.Drawing.Point(130, 113);
            this.textBoxAgentEditPass.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditPass.Name = "textBoxAgentEditPass";
            this.textBoxAgentEditPass.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditPass.TabIndex = 12;
            // 
            // textBoxAgentEditUser
            // 
            this.textBoxAgentEditUser.Location = new System.Drawing.Point(130, 87);
            this.textBoxAgentEditUser.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditUser.Name = "textBoxAgentEditUser";
            this.textBoxAgentEditUser.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditUser.TabIndex = 11;
            // 
            // textBoxAgentEditNum
            // 
            this.textBoxAgentEditNum.Location = new System.Drawing.Point(130, 64);
            this.textBoxAgentEditNum.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAgentEditNum.Name = "textBoxAgentEditNum";
            this.textBoxAgentEditNum.Size = new System.Drawing.Size(100, 20);
            this.textBoxAgentEditNum.TabIndex = 10;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(278, 139);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 13);
            this.label34.TabIndex = 26;
            this.label34.Text = "Zip Code:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(278, 118);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 13);
            this.label35.TabIndex = 25;
            this.label35.Text = "Address:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(278, 92);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(28, 13);
            this.label36.TabIndex = 24;
            this.label36.Text = "Sex:";
            // 
            // dateTimeAgentEditJoin
            // 
            this.dateTimeAgentEditJoin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeAgentEditJoin.Location = new System.Drawing.Point(130, 213);
            this.dateTimeAgentEditJoin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dateTimeAgentEditJoin.Name = "dateTimeAgentEditJoin";
            this.dateTimeAgentEditJoin.Size = new System.Drawing.Size(100, 20);
            this.dateTimeAgentEditJoin.TabIndex = 22;
            // 
            // comboBoxAgentEditSex
            // 
            this.comboBoxAgentEditSex.FormattingEnabled = true;
            this.comboBoxAgentEditSex.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBoxAgentEditSex.Location = new System.Drawing.Point(366, 90);
            this.comboBoxAgentEditSex.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentEditSex.Name = "comboBoxAgentEditSex";
            this.comboBoxAgentEditSex.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentEditSex.TabIndex = 21;
            // 
            // comboBoxAgentEditLeader
            // 
            this.comboBoxAgentEditLeader.DataSource = this.agentBindingSource;
            this.comboBoxAgentEditLeader.DisplayMember = "FullName";
            this.comboBoxAgentEditLeader.FormattingEnabled = true;
            this.comboBoxAgentEditLeader.Location = new System.Drawing.Point(130, 258);
            this.comboBoxAgentEditLeader.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentEditLeader.Name = "comboBoxAgentEditLeader";
            this.comboBoxAgentEditLeader.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentEditLeader.TabIndex = 20;
            // 
            // comboBoxAgentEditLevel
            // 
            this.comboBoxAgentEditLevel.FormattingEnabled = true;
            this.comboBoxAgentEditLevel.Items.AddRange(new object[] {
            "Agent",
            "AAM",
            "AAD",
            "AD"});
            this.comboBoxAgentEditLevel.Location = new System.Drawing.Point(130, 235);
            this.comboBoxAgentEditLevel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentEditLevel.Name = "comboBoxAgentEditLevel";
            this.comboBoxAgentEditLevel.Size = new System.Drawing.Size(100, 21);
            this.comboBoxAgentEditLevel.TabIndex = 19;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(40, 258);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(74, 13);
            this.label38.TabIndex = 9;
            this.label38.Text = "Direct Leader:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(40, 236);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(36, 13);
            this.label39.TabIndex = 8;
            this.label39.Text = "Level:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(40, 213);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(58, 13);
            this.label40.TabIndex = 7;
            this.label40.Text = "Join Date: ";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(40, 189);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(38, 13);
            this.label41.TabIndex = 6;
            this.label41.Text = "Email: ";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(40, 164);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(61, 13);
            this.label42.TabIndex = 5;
            this.label42.Text = "Last Name:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(40, 138);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(60, 13);
            this.label43.TabIndex = 4;
            this.label43.Text = "First Name:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(40, 113);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(56, 13);
            this.label44.TabIndex = 3;
            this.label44.Text = "Password:";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(40, 87);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(58, 13);
            this.label45.TabIndex = 2;
            this.label45.Text = "Username:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(40, 64);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(81, 13);
            this.label46.TabIndex = 1;
            this.label46.Text = "Agent Number: ";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label47.Location = new System.Drawing.Point(39, 17);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(103, 20);
            this.label47.TabIndex = 0;
            this.label47.Text = "Edit Agents";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonAgentLevelHistory);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.label37);
            this.tabPage1.Controls.Add(this.comboBoxAgentLevelHist);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(752, 336);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Level History";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonAgentLevelHistory
            // 
            this.buttonAgentLevelHistory.Location = new System.Drawing.Point(172, 122);
            this.buttonAgentLevelHistory.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonAgentLevelHistory.Name = "buttonAgentLevelHistory";
            this.buttonAgentLevelHistory.Size = new System.Drawing.Size(70, 28);
            this.buttonAgentLevelHistory.TabIndex = 5;
            this.buttonAgentLevelHistory.Text = "Search";
            this.buttonAgentLevelHistory.UseVisualStyleBackColor = true;
            this.buttonAgentLevelHistory.Click += new System.EventHandler(this.buttonAgentLevelHistory_Click);
            // 
            // dataGridView2
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.Location = new System.Drawing.Point(339, 44);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 33;
            this.dataGridView2.Size = new System.Drawing.Size(380, 269);
            this.dataGridView2.TabIndex = 4;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(50, 79);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(69, 13);
            this.label37.TabIndex = 3;
            this.label37.Text = "Agent Name:";
            // 
            // comboBoxAgentLevelHist
            // 
            this.comboBoxAgentLevelHist.DataSource = this.agentBindingSource;
            this.comboBoxAgentLevelHist.DisplayMember = "FullName";
            this.comboBoxAgentLevelHist.FormattingEnabled = true;
            this.comboBoxAgentLevelHist.Location = new System.Drawing.Point(144, 79);
            this.comboBoxAgentLevelHist.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.comboBoxAgentLevelHist.Name = "comboBoxAgentLevelHist";
            this.comboBoxAgentLevelHist.Size = new System.Drawing.Size(140, 21);
            this.comboBoxAgentLevelHist.TabIndex = 2;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label23.Location = new System.Drawing.Point(38, 25);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(165, 20);
            this.label23.TabIndex = 1;
            this.label23.Text = "Agent Level History";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(276, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Agency Management System";
            // 
            // buttonAgentBackMenu
            // 
            this.buttonAgentBackMenu.Location = new System.Drawing.Point(0, 1);
            this.buttonAgentBackMenu.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonAgentBackMenu.Name = "buttonAgentBackMenu";
            this.buttonAgentBackMenu.Size = new System.Drawing.Size(87, 23);
            this.buttonAgentBackMenu.TabIndex = 11;
            this.buttonAgentBackMenu.Text = "Back to Menu ";
            this.buttonAgentBackMenu.UseVisualStyleBackColor = true;
            this.buttonAgentBackMenu.Click += new System.EventHandler(this.buttonAgentBackMenu_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 401);
            this.Controls.Add(this.buttonAgentBackMenu);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControlAgent);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form3";
            this.Text = "AMS Agent";
            this.tabControlAgent.ResumeLayout(false);
            this.tabPageView.ResumeLayout(false);
            this.tabPageView.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.agentBindingSource)).EndInit();
            this.tabPageAdd.ResumeLayout(false);
            this.tabPageAdd.PerformLayout();
            this.tabPageEdit.ResumeLayout(false);
            this.tabPageEdit.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlAgent;
        private System.Windows.Forms.TabPage tabPageView;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button buttonExportView;
        private System.Windows.Forms.Button buttonClearView;
        private System.Windows.Forms.Button buttonViewAgent;
        private System.Windows.Forms.ComboBox comboBoxViewAgentLeader;
        private System.Windows.Forms.ComboBox comboBoxViewAgentLevel;
        private System.Windows.Forms.TextBox textBoxViewAgentLastN;
        private System.Windows.Forms.TextBox textBoxViewAgentFirstN;
        private System.Windows.Forms.TextBox textBoxViewAgentNum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TabPage tabPageEdit;
        private System.Windows.Forms.Button buttonAgentEditSearch;
        private System.Windows.Forms.ComboBox comboBoxAgentModify;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button buttonClearEdit;
        private System.Windows.Forms.Button buttonEditAgents;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DateTimePicker dateTimeAgentEditDOB;
        private System.Windows.Forms.TextBox textBoxAgentEditPOB;
        private System.Windows.Forms.TextBox textBoxAgentEditOP;
        private System.Windows.Forms.TextBox textBoxAgentEditHP;
        private System.Windows.Forms.TextBox textBoxAgentEditZip;
        private System.Windows.Forms.TextBox textBoxAgentEditAddr;
        private System.Windows.Forms.TextBox textBoxAgentEditEmail;
        private System.Windows.Forms.TextBox textBoxAgentEditLName;
        private System.Windows.Forms.TextBox textBoxAgentEditFName;
        private System.Windows.Forms.TextBox textBoxAgentEditPass;
        private System.Windows.Forms.TextBox textBoxAgentEditUser;
        private System.Windows.Forms.TextBox textBoxAgentEditNum;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.DateTimePicker dateTimeAgentEditJoin;
        private System.Windows.Forms.ComboBox comboBoxAgentEditSex;
        private System.Windows.Forms.ComboBox comboBoxAgentEditLeader;
        private System.Windows.Forms.ComboBox comboBoxAgentEditLevel;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPageAdd;
        private System.Windows.Forms.Button buttonClearAdd;
        private System.Windows.Forms.Button buttonAddAgents;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DateTimePicker dateTimeAgentDOB;
        private System.Windows.Forms.TextBox textBoxAgentPOB;
        private System.Windows.Forms.TextBox textBoxAgentOP;
        private System.Windows.Forms.TextBox textBoxAgentHP;
        private System.Windows.Forms.TextBox textBoxAgentZip;
        private System.Windows.Forms.TextBox textBoxAgentAddr;
        private System.Windows.Forms.TextBox textBoxAgentEmail;
        private System.Windows.Forms.TextBox textBoxAgentLastN;
        private System.Windows.Forms.TextBox textBoxAgentFirstN;
        private System.Windows.Forms.TextBox textBoxAgentPass;
        private System.Windows.Forms.TextBox textBoxAgentUser;
        private System.Windows.Forms.TextBox textBoxAgentNum;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dateTimeAgentJoin;
        private System.Windows.Forms.ComboBox comboBoxAgentSex;
        private System.Windows.Forms.ComboBox comboBoxAgentLeader;
        private System.Windows.Forms.ComboBox comboBoxAgentLevel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAgentBackMenu;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox comboBoxAgentLevelHist;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button buttonAgentLevelHistory;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBoxAgentReligion;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBoxAgentEditReligion;
        private System.Windows.Forms.BindingSource agentBindingSource;
        private System.Windows.Forms.ComboBox comboBoxViewAgentDateYear;
        private System.Windows.Forms.ComboBox comboBoxViewAgentDateDay;
        private System.Windows.Forms.ComboBox comboBoxViewAgentDateMonth;
        private System.Windows.Forms.Label labelAddSuccess;
        private System.Windows.Forms.Label labelUpdateSuccess;
    }
}